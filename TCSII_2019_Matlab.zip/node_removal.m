% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Node Removal Attacks
% including {'rand'; 'target->degree'; 'target->betweenness'}
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 26-01-2018 (by felix.lou@my.cityu.edu.hk)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function res = node_removal(A,N,s)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Output:
%   .y1a = state  controllability
%   .y2u = struct controllability
% Input:
%   A  - net matrix
%   N  - net size
%   s  - {'rand'; 't_deg'; 't_bet'}
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
    drct = 'out';
    nXe  = 'node';  %% this function is about node_removal ...
    res.x = (1:N-1)./(N-1);
    res.y1a = ones(N-1,1);  %% state/exact controllability
    res.y2u = ones(N-1,1);	%% structural controllability
    
    % -----  ----- | RANDOM ATTACK | -----  ----- %
    if strcmp(s.name,'rand')
        A1 = A;  % keep a copy of A
        y1a = zeros(s.rept,N-1);
        y2u = zeros(s.rept,N-1);
        for t = 1:s.rept  %% Repeat
            disp(['  -> Rand Node Removal: ',int2str(t),'/',int2str(s.rept),' attack ..'])
            A = A1;
            for idx = 1:N-1
                j = randi(N-idx);
                % Revove a random node
                A(j,:) = [];
                A(:,j) = [];
                cur_N = size(A,1);                
                m = sum(dmperm(A)~=0);  % Calculate the maximum matching ...
                rk = rank(A);           % Calculate the rank ...
                y1a(t,idx) = max((cur_N-rk),1)/cur_N;
                y2u(t,idx) = max((cur_N-m), 1)/cur_N;
            end
        end
        res.y1a = mean(y1a,1);
        res.y2u = mean(y2u,1);        
    % -----  ----- | RANDOM ATTACK | -----  ----- %
        
    % -----  ----- | TARGETTED ATTACK | -----  ----- %
    else % Targeted Attacks :: 't_deg' - targeted degree based
         %                     't_bet' - targeted betweenness based
        for idx = 1:N-1
            switch s.name
                case 't_deg'  %% targeted degree based
                    pos = max_degree(A,nXe,drct,'rnd');
                case 't_bet'  %% targeted betweenness based
                    pos = max_betweenness(A,nXe);
            end
            A(pos,:) = [];
            A(:,pos) = [];
            cur_N = size(A,1);  % attack on A            
            m = sum(dmperm(A)~=0);  % Calculate the maximum matching ...
            rk = rank(A);           % Calculate the rank ...
            res.y1a(idx,1) = max((cur_N-rk),1)/cur_N;
            res.y2u(idx,1) = max((cur_N-m) ,1)/cur_N;
        end
    end
    % -----  ----- | TARGETTED ATTACK | -----  ----- %
    
end


