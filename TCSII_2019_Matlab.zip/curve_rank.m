% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Compare the Attack Curves Ordinally
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 26-01-2018 (by felix.lou@my.cityu.edu.hk)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function [rk,win] = curve_rank(cv_mat,n,D,L)
% input  n - cut down L into n pieces
%            if n == L, then rank all points
%        D - number of curves (network or algorithm) to compare
%        L - length of each curve
% output rk = rank

    % ----- check size ----- %
    if size(cv_mat,1) ~= D || size(cv_mat,2) ~= L
        if size(cv_mat,1) ~= L && size(cv_mat,2) ~= D
            cv_mat = cv_mat';
        else
            error('error size input matrix ...')
        end
    end
    
    % ----- sample n points for each curve ----- %
    cv = zeros(D,n);
    itv = floor(L/n);
    for idx = itv:itv:L
        jdx = floor(idx/itv);
        cv(:,jdx) = cv_mat(:,idx);
    end
    
    % ----- rank position by position ----- %
    tmp_rk = rktb(cv_mat',D,L);
    rk = mean(tmp_rk,2);
    win = zeros(D,1);
    rk1 = min(tmp_rk,[],1);
    for idx = 1:D  %% how many times each curve wins rank#1
        win(idx) = sum(tmp_rk(idx,:)==rk1);
    end
    
end

