% Generate the Multiplex Congruence Network in Sci Rept
% https://www.nature.com/articles/srep23714

function [A,ak] = mcn(r,N)
% A - the r-th layer only

    A = zeros(N,N);
    for i=1:N
        for j=i+1:N+1
            if mod(j+1,i+1)==r && (j<=N)
                A(i,j) = 1;
            end
        end
    end
    ak = sum(sum(A==1))/(N);
end

