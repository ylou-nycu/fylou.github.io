% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Matlab Code for Paper:
%   G.Chen, Y.Lou, & L.Wang, "A Comparative Study on Controllability
%   Robustness of Complex Networks," IEEE Transactions on Circuits and
%   Systems II: Express Briefs, DOI:10.1109/TCSII.2019.2908435, (2019).
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Programmer: Felix Y. Lou (felix.lou@my.cityu.edu.hk)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 13-04-2019
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

close all;
clear all;
clc

NXE = {'node'; 'edge';};
TXR = {'rand'; 'tar';};
EXT_PARA = {'betweenness';'degree';};
NET = {'er'; 'sf'; 'mcn'; 'qsn'; 'rtn'; 'rrn'};
XLAB = {'P_N'; 'P_E';};

disp('--- Please input the following parameters --- ')
N = input('Number of nodes: ');
%disp('(the average degree in determined by MCN)')
ne_id = input('Attack on: 1) node-removal; 2) edge-removal: ');
at_id = input('Attack by: 1) random; 2) targeted: ');
nXe = NXE{ne_id};
tXr = TXR{at_id};
if at_id == 2
    at_subid = input('  -> choose: 1) betweenness-targeted; 2) degree-targeted: ');
    ext_para = EXT_PARA{at_subid};
elseif at_id == 1
    ext_para = [];
else
    error('wrong attack type input ...')
end
re = [];
net_id = 1:6;

for ndx = net_id
    net = NET{ndx};
    if at_id == 2
        disp([net,', N=',int2str(N),', by ', nXe,', ', tXr,'-',ext_para, ' attack ...'])
    else
        disp([net,', N=',int2str(N),', by ', nXe,', ', tXr, ' attack ...'])
    end
    fname = attack6(net,nXe,tXr,N,ext_para,re);
    load(fname,'c_res')
    cv_mat(ndx,:) = c_res.y2u;  % structrual controllability
    cv_x(ndx,:) = c_res.x;
end
fig_name = [upper(net),', N=',int2str(N),', by ', upper(nXe(1)), nXe(2:end), ...
            ' ', upper(tXr(1)), tXr(2:end), ' Attack'];
fig_plot(cv_x,cv_mat,net_id,fig_name)
xlabel(XLAB(ne_id))
ylabel('n_D')

