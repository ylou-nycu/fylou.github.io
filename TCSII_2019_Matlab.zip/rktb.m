% Rank_Table ver2.0 better than 'rank_table.m'
% Updated: 08-09-2018

function [rk] = rktb(v,N,L)
% V_size: N(Algorithm)-by-L(Length-of-Each)

    [n,len] = size(v);
    if n~=N || len~=L
        if n==L && len==N
            v = v';
        else
            error('Wrong size of input ... ')
        end
    end
    rk = zeros(size(v));
    %vv = v;  % BACKUP
    
    for idx=1:L
        tmpv = v(:,idx);        % a temp vector
        tmprk = zeros(size(tmpv));
        sdk = 1;
        while ~all(tmpv==inf)	% not all values are 'inf'
            min_pos = find(tmpv==min(tmpv));
            len_mp = length(min_pos);
            for jdx = 1:len_mp
                tmprk(min_pos(jdx)) = sum(sdk:(sdk+len_mp-1))/len_mp;
                tmpv(min_pos(jdx)) = inf;  % 'inf' means the position has been ranked
            end
            sdk = sdk+len_mp;
        end
        rk(:,idx) = tmprk;
    end
end

