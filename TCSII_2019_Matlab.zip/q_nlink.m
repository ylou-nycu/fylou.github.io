% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% q <--> #links calculation in q-snapback
% Examples:
%       [1] given total number of links, return q
%           q = q_nlink(2,10000,'e2q',60600)
%       [2] given q, return total number of links
%           e = q_nlink(2,10000,'q2e',0.001)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% updated: 15-09-2018
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

function res = q_nlink(r,N,s,x)
% If s == 'q2e', x is value of q \in[0,1]
% If s == 'e2q', x is number of edges

    switch s
        case 'q2e'
            res = q2nlink(r,N,x);
        case 'e2q'
            res = nlink2q(r,N,x);
    end
    
    % ----- auxiliary functions (1) ----- %
    % given total number of links, return 'q'
    function q_qsn = nlink2q(r,N,nlink)
        PRECISION = 1E5;
        q_qsn = (nlink-N)/sum(((r+1):N-2)/(r-1));
        q_qsn = round(q_qsn*PRECISION)/PRECISION;
    end

    % ----- auxiliary functions (2) ----- %
    % given 'q', return the total number of links it would be
    function total_deg = q2nlink(r,N,q)
        deg = zeros(N,1);
        for i = 1:r
            deg(i) = 1;
        end
        for i = r+1:N
            deg(i) = 1+floor((i-2)/(r-1))*q;
        end
        total_deg = round(sum(deg));
    end

end

