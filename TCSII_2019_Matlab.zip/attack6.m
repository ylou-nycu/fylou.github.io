% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% SIX attack methods
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Attck Methods:
% 1.node-tar-degree;  2.node-tar-between; 3.node-rand
% 4.edge-tar-degree;  5.edge-tar-between; 6.edge-rand;
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 25-01-2018 (by felix.lou@my.cityu.edu.hk)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function fname = attack6(net,nXe,tXr,N,ext_para,re)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Output: Structural and State Controllability
% Input: tXr - target or rand
%        nXe - node or edge
%        net - nettype 
%          N - network size
%	ext_para - if node/edge-targeted] {'degree';'betweenness'}
%         re - number of repeated runs (for targeted) 
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% tXr == {'target'; 'rand'};
% nXe == {'node';   'edge';};
% net == {'er'; 'sf'; 'mcn'; 'qsn'; 'rtn'; 'rrn'};
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

    EDGE_ATTACK_FLAG = 0;
    BACKBONE = 'no_chain';  %% {'chain'; 'tree'; 'no'}
    TRY_DISC = 10;
    % ----- check some input variables ----- %
    if exist('re','var') && ~isempty(re)
        REPT = re;  C_RES = cell(REPT,1);
    else
        REPT = 1;
    end
    r_qs  = 2;	%% r for q-snapback network
    r_mcn = 1;	%% r for multiplex congruence network
    n_link = get_nlink_mcn(N,r_mcn);
    
    for r = 1:REPT
        if REPT > 1;  disp(['Running the ',int2str(r),'-th out of ',int2str(REPT),' attack .. ']);  end
        switch net
            case 'er'
                str = BACKBONE;
                [A,~,disc] = ern(N,n_link,str);
                tmp = 0;
                while disc && (tmp<TRY_DISC)
                    tmp = tmp+1;
                    [A,~,disc] = ern(N,n_link,str);
                end
            case 'sf'
                str = BACKBONE;
                [A,~,disc] = sfn(N,n_link,str);
                tmp = 0;
                while disc && (tmp<TRY_DISC)
                   tmp = tmp+1;
                   [A,~,disc] = sfn(N,n_link,str);
                end
            case 'mcn'
                A = mcn(r_mcn,N);
            case 'qsn'
                itop = 'chain';
                q = q_nlink(r_qs,N,'e2q',n_link);
                A = qsn(r_qs,N,q,n_link,itop);
            case 'rtn'  % Randome Triangle Network
                str = 'loop';  %% str = {'loop','rand'}, where 'loop' = trianle-loop
                A = rtn(N,n_link,str);
            case 'rrn'  % Randome Rectangle Network
                str = 'loop';  %% str = {'loop','rand'}, where 'loop' = trianle-loop
                A = rrn(N,n_link,str);
            otherwise
                error('no such net type ...')
        end
        % -----| above A is constructed |----- %
        % -----| below attack A ...     |----- %
        switch nXe
            % ----- | Node Removal + {1.bet_target; 2.deg_target; 3.rand} | -----  ----- %
            case {'node';'n';}
                switch tXr
                    case {'tar';'target';}
                        if strcmp(ext_para,'betweenness')
                            s.name = 't_bet';
                        elseif strcmp(ext_para,'degree')
                            s.name = 't_deg';
                        end
                    case {'rand';'rnd';}  %% Rand-Node-Attack
                        s.name = 'rand';
                        s.rept = 30;
                    otherwise
                        error('...')
                end
                c_res = node_removal(A,N,s);
            % ----- | Edge Removal + {1.bet_tar; 2.rand} | -----  ----- %
            case {'edge';'e';}
                switch tXr
                    case {'tar';'target';}
                        if strcmp(ext_para,'betweenness')
                            s.name = 'te_bet';
                        elseif strcmp(ext_para,'degree')
                            s.name = 'te_deg';
                        end
                    case {'rand';'rnd'}
                        s.name = 'rand';
                        s.rept = 10;  %% Set as small as possible for Edge-Removal
                    otherwise
                        error('...')
                end
                c_res = edge_removal(A,s);
                EDGE_ATTACK_FLAG = 1;
            otherwise
                error('no such nXe type ...')
        end
        
        if REPT > 1
            C_RES{r} = c_res;
            if r == REPT  %% the last repeat ...
                y1a_ = zeros(REPT,N-1);
                y2u_ = zeros(REPT,N-1);
                if EDGE_ATTACK_FLAG
                    y1a_ = zeros(REPT,n_link-1);
                    y2u_ = zeros(REPT,n_link-1);
                end
                for rdx = 1:REPT
                    y1a_(rdx,:) = C_RES{rdx}.y1a;
                    y2u_(rdx,:) = C_RES{rdx}.y2u;
                end
                c_res.y1a = mean(y1a_,1);
                c_res.y2u = mean(y2u_,1);
            end
        end
        
        if ~exist('ext_para','var')
            ext_para = [];
        end
        fname = ['res\',net,'_',nXe,'_',tXr,ext_para,'_',int2str(N)];
        save(fname);
    end
    
end

% % ----- network names ----- %
% % 'er'  - random graph
% % 'sf'  - generic scale-free
% % 'mcn' - multiplex congruence network
% % 'qsn' - q-snapback network
% % 'rtn' - random triangle network
% % 'rrn' - random rectangle network

