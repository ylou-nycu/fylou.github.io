% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% 'max_degree.m'
% Note: search for max_edge_degree is time-consuming
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 17-09-2018

function pos = max_degree(A,nXe,drct,str)
%    A - adj matrix
%  nXe - 'node' or 'edge'
% drct - direction {'in';'out'}
%  str - when degree value equals

    if ~exist('drct','var') || isempty(drct)
        drct='out';
    end
    if ~exist('str','var') || isempty(str)
        str='rnd';
    end
    
    switch nXe
        case 'node'  %% ---| max node degree |--- %
            switch drct
                case 'out'	%% get out-degree of every node
                    k = sum(A,2);
                case 'in'	%% get in-degree of every node
                    k = sum(A,1);
            end
            pos = find(k==max(k));
            switch str
                case 'min'  %% min index
                    [~,kpos] = min(pos);
                case 'max'	%% max index
                    [~,kpos] = max(pos);
                case {'rand';'rnd'}
                    kpos = randi(length(pos));
            end
            pos = pos(kpos);
        case 'edge'  %% ---| max edge degree |--- %
            M = sum(sum(A));  %% all edges
            N = size(A,1);
            ke = zeros(M,1);
            for i = 1:M
                pos = locate_edge(i);
                [ii,jj] = ind2sub(N,pos);  % (degree[i] => ii->jj =>degree[j])
                ke(i) = sqrt(sum(A(ii,:))*sum(A(jj,:)));  % sqrt(degree[i]*degree[j])
            end
            kMax = max(ke);
            pos_ = find(ke == kMax);
            pos = pos_(randi(length(pos_)));
    end  %% End: node-or-edge
    
    % ----- auxiliary functions ----- %
    % find idx-th non-zero element in A, and return location
    % updated: 06-08-2018
    function pos = locate_edge(idx)
        pos=find(A==1,idx,'first');
        pos=pos(end);
    end

end

