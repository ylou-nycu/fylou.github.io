% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Edge Removal Based Attacks
% including {'rand'; 'target->betweenness'; 'target->degree'}
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 26-01-2018 (by felix.lou@my.cityu.edu.hk)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function res = edge_removal(A,s)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Output:
% y1a = state  controllability
% y2u = struct controllability
% Input:
% A - net matrix
% s - {'rand'; 'te_bet'; 'te_deg'}
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

    nXe = 'edge';
    M = sum(sum(A));        %% total number of edges
    res.x = (1:M)./(M);
    res.y1a = ones(M,1);  %% state/exact controllability
    res.y2u = ones(M,1);	%% structural controllability
    
    % -----  ----- | RANDOM ATTACK | -----  ----- %
    if strcmp(s.name,'rand')
        A1 = A;  %% backup A
        y1a = zeros(s.rept,M);
        y2u = zeros(s.rept,M);
        for t = 1:s.rept  %% Repeat
            disp(['  -> Rand Edge Removal: ',int2str(t),'/',int2str(s.rept),' attack ..'])
            A = A1;  M1 = M; % M = (original) number of edges in A
            i = 1;
            while M1
                %if ~mod(M1,1E3);  disp(['  --> deleting ',int2str(M1),' links ..']);  end
                j = randi(M1);
                pos = locate_edge(j);  if ~A(pos);  error('This is not an edge ... ');  end
                A(pos) = 0;  %% only out-degree cleared
                m = sum(dmperm(A)~=0);  % Calculate the maximum matching ...
                rk = rank(A);  % Calculate the rank ...
                y1a(t,i) = max((size(A,1)-rk),1)/size(A,1);
                y2u(t,i) = max((size(A,1)-m), 1)/size(A,1);
                i = i+1;
                M1 = sum(sum(A));
            end
        end
        res.y1a = mean(y1a,1);
        res.y2u = mean(y2u,1);
	% -----  ----- | RANDOM ATTACK | -----  ----- %
    
    % -----  ----- | TARGETTED ATTACK | -----  ----- %
    elseif strcmp(s.name,'te_bet')
        for i=1:M
            %if ~mod(i,500);  disp(['Tar(degree): Removing ',int2str(i),'th link ...']);  end
            pos = max_betweenness(A,nXe);
            pos = locate_edge(pos);
            if ~A(pos);  error('It is NOT an edge ... ');  end
            A(pos) = 0;
            m = sum(dmperm(A)~=0);  % Calculate the maximum matching ...
            rk = rank(A);  % Calculate the rank ...
            res.y1a(i,1) = max((size(A,1)-rk),1)/size(A,1);
            res.y2u(i,1) = max((size(A,1)-m),1)/size(A,1);
        end
    elseif strcmp(s.name,'te_deg')
        for i=1:M
            %if ~mod(i,500);  disp(['Tar(degree): Removing ',int2str(i),'th link ...']);  end
            pos = max_degree(A,nXe);  % The pos-th (1~M) edge has mx-degree            
            pos = locate_edge(pos);   % allocated pos in the N-x-N matrix
            if ~A(pos);  error('It is NOT an edge ... ');  end
            A(pos) = 0;
            m = sum(dmperm(A)~=0);  % Calculate the maximum matching ...
            rk = rank(A);  % Calculate the rank ...
            res.y1a(i,1) = max((size(A,1)-rk),1)/size(A,1);
            res.y2u(i,1) = max((size(A,1)-m),1)/size(A,1);
        end
    else
        warning('Not a correct ''s.name'' value ...')
    end  %% if-rand-or-targeted

    % -----  ----- | AUXILIARY FUNCTIONS | -----  ----- %
    function pos = locate_edge(idx)
        pos=find(A==1,idx,'first');
        pos=pos(end);
    end

end

