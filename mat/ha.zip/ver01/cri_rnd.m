% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% search for the critical edge/node list in the current network
% random sorted
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% updated: 15-06-2020
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

function [crit,hie] = max_cri_rnd(A,eXn,len)
% Input:     A - adj mat
%          eXn - if: 'node' || then: str - {'bet';'deg';'clo';}
%          eXn - if: 'edge' || then: str - {'bet';'deg';}
%          len - # of max_cri nodes/edges returned     
% -----  -----  -----  -----  -----  -----  ----- 
% Output: crit - critical edge/node list
%          hie - hierarchical level
% hierarchical level (0)critical; (1)sub-critical; (2)normal; (3)rest
% -----  -----  -----  -----  -----  -----  -----
    if nargin<3;  len=1;  end
    crit=[];	% critical edge/node
    subcr=[];	% sub-critical edge/node
    noncr=[];	% non-critical edge/node
    tabu=[]; 	% ban list (isolated nodes)
    N=size(A,1);  M=sum(A,'all');
    n0=max(N-sum(dmperm(A)~=0),1);	% #driver nodes needed
    m0=N-sum(dmperm(A)~=0);         % #unmatched nodes
    if strcmp(eXn,'node')
        N0=N-1;   % always remove one node
        for idx=1:N
            A0=A;
            A0(idx,:)=0;   A0(:,idx)=0;         % remove the node: idx
            if max(N0-sum(dmperm(A0)~=0),1)>n0	% /* #driver_node ++ */
                crit=[crit;idx];                % a critical node                
            elseif max(N0-sum(dmperm(A0)~=0),1) == n0	% /* #driver_node == */
                if N0-sum(dmperm(A0)~=0)>m0     % #unmatched node ++
                    subcr=[subcr;idx];          % a sub-critical node
                else
                    noncr=[noncr;idx];          % a non-critical node 3rd option
                end
            else   % max(N0-sum(dmperm(A0)~=0),1) < n0	% /* #driver_node -- */ % e.g., delete an isolated node
                tabu=[tabu;idx];
            end
        end
    elseif strcmp(eXn,'edge')
        ep=find(A==1);              % edge position
        for idx=1:M
            A0=A;
            A0(ep(idx))=0;          % remove the edge: ep(idx)
            if max(N-sum(dmperm(A0)~=0),1)>n0	% #driver_node ++
                crit=[crit;ep(idx)];            % a critical edge
            elseif max(N-sum(dmperm(A0)~=0),1)==n0	% #driver_node ++
                if N-sum(dmperm(A0)~=0)>m0      % #unmatched node ++
                    subcr=[subcr;ep(idx)];      % a subcritical edge
                else
                    noncr=[noncr;ep(idx)];
                end
            else
                error('   .. should never come here.')
            end
        end
    end
    
    if isempty(crit)
        if isempty(subcr); if isempty(noncr); hie=3; else; hie=2; end; else; hie=1; end
    else
        hie=0;
    end
    crit=crit(randperm(length(crit)));
    lenc=length(crit);
    if lenc<len
        if strcmp(eXn,'node')
            list=randperm(N)';
            for idx=1:lenc;  list(list==crit(idx))=[];  end
        elseif strcmp(eXn,'edge')
            list=ep;
            for idx=1:lenc;  list(list==crit(idx))=[];  end
        end
        add_ele=list(randi(length(list),[len-lenc,1]));
        crit=[crit;add_ele];
    end
    n=min(len,length(crit));
    crit=crit(1:n);
end

