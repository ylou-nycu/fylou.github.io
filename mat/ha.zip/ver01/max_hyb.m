% -----  -----  -----  -----  -----  -----  -----  -----  -----
% more destructive attack of {degree, betweenness}-based attacks
% -----  -----  -----  -----  -----  -----  -----  -----  -----
% updated: 04-08-2020
% -----  -----  -----  -----  -----  -----  -----  -----  -----

function res = max_hyb(A,eXn,bat)

    B=A;
    pos1=max_bet(A,eXn,bat);
    pos2=max_deg(A,eXn,bat);

    switch eXn
        case 'node'
            A(pos1,:)=[];  A(:,pos1)=[];
            B(pos2,:)=[];  B(:,pos2)=[];
            if sum(dmperm(A)>0)<sum(dmperm(B)>0)
                res=pos1;
            else
                res=pos2;
            end
        case 'edge'
            A(pos1)=0;  B(pos2)=0;
            if sum(dmperm(A)>0)<sum(dmperm(B)>0)
                res=pos1;
            else
                res=pos2;
            end
    end
end

