% Source Code for our paper: Y. Lou, L. Wang, and G. Chen,
% "A Framework of Hierarchical Attacks to Network Controllability"
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% updated: 04-August-2020
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

clearvars;  close all; clc
addpath('net')
% NET={'er';'sw';'sf';'qs';'qr';'rt';'rr';'ho';'ol'};

N=200;
AK=5;
eXn='edge';

if strcmp(eXn,'edge')
    ATK={'ebet'; 'ecrib'; 'edeg'; 'ecrid'; 'ernd'; 'ecrir'; 'ehyb'; 'esun';};
elseif strcmp(eXn,'node')
    ATK={'nbet'; 'ncrib'; 'ndeg'; 'ncrid'; 'nclo'; 'ncric'; 'nrnd'; 'ncrir'; 'nhyb';};
end
LaTk = length(ATK);
M=N*AK;

for i=1:LaTk
    aTk=ATK{i};
    attack(N,M,eXn,aTk);
end

