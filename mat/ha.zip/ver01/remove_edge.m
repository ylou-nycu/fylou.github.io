% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% edge-removal attacks:
% 1) 'ebet'  - betweennness
% 2) 'ecrib' - hierarchical-critical-betweenness (E-HB)
% 3) 'edeg'  - degree
% 4) 'ecrid' - hierarchical-critical-degree (E-HD)
% 5) 'ernd'  - random
% 6) 'ecrir' - hierarchical-critical-rand (E-HR)
% 7) 'ehyb'  - hybrid
% 8) 'esun'  - initial critical
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 08-July-2020
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function res = remove_edge(A,N,M,s,bat)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Input:
% s -> s.name
%      s.rept (for 'ernd' only)
% bat - batch removal
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
    L=ceil(M/bat);
    if strcmp(s.name,'ernd')
        A_backup=A;
        M_backup=M;
        y2u=zeros(L,s.rept);        
    else
        res.y2u=ones(L,1);	% structural controllability
    end
    if strcmp(s.name(1:4),'ecri')
        res.hie=Inf(L,1);   % hierarchical level \in[0,5]
    end
    res.bat=bat;
% -----  ----- | RANDOM ATTACK | -----  ----- %
    if strcmp(s.name,'ernd')
        for t=1:s.rept
            disp(['     __ >> ernd: ',int2str(t),'/',int2str(s.rept),' ..']);
            A=A_backup;     M=M_backup;
            i=1;
            y2u(i,t)=max((N-sum(dmperm(A)>0)),1)/N;            
            while M>bat
                j=find(A);  lenj=length(j);	tmpi=randperm(lenj);	
                b=min(bat,lenj);
                if any(~A(j(tmpi(1:b))));   error('    ..not edge(s) ?? ');   end
                A(j(tmpi(1:b)))=0;
                i=i+1;
                y2u(i,t)=max((N-sum(dmperm(A)>0)),1)/N;
                M=sum(A,'all');
            end
            i=i+1;
            y2u(i,t)=1;
        end
        res.y2u=mean(y2u,2);
% -----  ----- | RANDOM ATTACK | -----  ----- %
% -----  ----- | TARGETTED ATTACK | -----  ----- %
    else
        i=1;
        res.y2u(i,1)=max((N-sum(dmperm(A)>0)),1)/N;
        if strcmp(s.name,'esun'); fpos=rnd_cri(A,N,M,'edge'); end  % get a full-list
        while M>bat
            switch s.name
                case'ebet';     pos=max_bet(A,'edge',bat);
                case'edeg';     pos=max_deg(A,'edge',bat);
                case'ecrib';	[pos,hie]=max_cri(A,'edge','bet',bat);
                case'ecrid';	[pos,hie]=max_cri(A,'edge','deg',bat);
                case'ehyb';     pos=max_hyb(A,'edge',bat);
                case'esun';     pos=fpos(1:bat);   fpos(1:bat)=[];
                case'ecrir';    [pos,hie]=cri_rnd(A,'edge',bat);
            end
            if any(~A(pos));   error('    ..not edge(s) ?? ');   end
            A(pos)=0;  % edge-removal
            i=i+1;
            res.y2u(i,1)=max((N-sum(dmperm(A)>0)),1)/N;
            if strcmp(s.name(1:4),'ecri');  res.hie(i,1)=hie;  end
            M=sum(A,'all');
        end
        i=i+1;
        res.y2u(i,1)=1;
    end
end

