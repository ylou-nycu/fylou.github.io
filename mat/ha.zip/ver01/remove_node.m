% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% node-removal attacks:
% 1) 'nbet'  - betweennness
% 2) 'ncrib' - hierarchical-critical-betweenness (N-HB)
% 3) 'ndeg'  - degree
% 4) 'ncrid' - hierarchical-critical-degree (N-HD)
% 5) 'nclo'  - clo
% 6) 'ncric' - hierarchical-critical-clo (N-HC)
% 7) 'nrnd'  - random
% 8) 'ncrir' - hierarchical-critical-random (N-HR)
% 9) 'nhyb'  - hybrid
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 08-July-2020
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function res = remove_node(A,N,s,bat)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Input:
% s -> s.name
%      s.rept=# of repeated runs, for 'nrnd' only
% bat - batch removal
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
    L=ceil(N/bat);
    if strcmp(s.name(1:4),'nrnd')
        A_backup=A;  %% backup A
        y2u=zeros(L,s.rept);
    else
        res.y2u=ones(L,1);	% structural controllability
    end
    if strcmp(s.name(1:4),'ncri')
        res.hie=Inf(L,1);   % hierarchical level \in[0,5]
    end
    res.bat=bat;
% -----  ----- | RANDOM ATTACK | -----  ----- %
    if strcmp(s.name,'nrnd')
        for t=1:s.rept
            A=A_backup;	% get original A
            cur_N=N;	% do not change N, change cur_N
            i=1;
            y2u(i,t)=max((cur_N-sum(dmperm(A)>0)), 1)/cur_N;
            while cur_N>bat
                j=randperm(cur_N);
                n=min(bat,length(j));
                pos=j(1:n);  A(pos,:)=[];  A(:,pos)=[];  % node-removal
                cur_N=size(A,1);
                i=i+1;
                y2u(i,t)=max((cur_N-sum(dmperm(A)>0)),1)/cur_N;
            end
            i=i+1;
            y2u(i,t)=1;
        end
        res.y2u=mean(y2u,2);
        
% -----  ----- | RANDOM ATTACK | -----  ----- %
% -----  ----- | TARGETTED ATTACK | -----  ----- 
    else  %% s.name == 'tn_bet' or 'tn_deg'
        cur_N=N;      %% do not change N, change cur_N
        i=1;
        res.y2u(i,1)=max((cur_N-sum(dmperm(A)>0)),1)/cur_N;
        while cur_N>bat
            switch s.name
                case'nbet';     pos=max_bet(A,'node',bat);
                case'nclo';     pos=max_clo(A,bat);
                case'ndeg';     pos=max_deg(A,'node',bat);
                case'ncrib';	[pos,hie]=max_cri(A,'node','bet',bat);
                case'ncric';	[pos,hie]=max_cri(A,'node','clo',bat);
                case'ncrid';	[pos,hie]=max_cri(A,'node','deg',bat);
                case'nhyb';     pos=max_hyb(A,'node',bat);
                case'ncrir';	[pos,hie]=cri_rnd(A,'node',bat);
            end
            A(pos,:)=[];  A(:,pos)=[];  cur_N=size(A,1);  % node-removal
            i=i+1;
            res.y2u(i,1)=max((cur_N-sum(dmperm(A)>0)),1)/cur_N;
            if strcmp(s.name(1:4),'ncri');  res.hie(i,1)=hie;  end
        end
        i=i+1;
        res.y2u(i,1)=1;
    end
% -----  ----- | TARGETTED ATTACK | -----  ----- %

