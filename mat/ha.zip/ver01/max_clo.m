% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% max node out-closeness
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 04-08-2020
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %


function pos = max_clo(A,len)

    G=digraph(A);
    oc=centrality(G,'outcloseness');
    [~,p]=sort(oc,'descend');
    n=min(len,length(p));
    pos=p(1:n,1);
    tmpval=min(oc(pos));
    tmpidx=find(oc==tmpval);
    pos(oc(pos)==tmpval)=[];
    delta=n-length(pos);
    tmpidx=tmpidx(randperm(length(tmpidx)));
    tmpidx=tmpidx(1:delta);
    pos=[pos;tmpidx];
    
end

