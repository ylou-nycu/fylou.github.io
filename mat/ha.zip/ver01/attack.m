% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% NET={'er';'sw';'sf';'qs';'qr';'rt';'rr';'ho';'ol'};
% eXn='edge';  ATK={'ebet'; 'ecrib'; 'edeg'; 'ecrid'; 'ernd'; 'ecrir'; 'ehyb'; 'esun';};
% eXn='node';  ATK={'nbet'; 'ncrib'; 'ndeg'; 'ncrid'; 'nclo'; 'ncric'; 'nrnd'; 'ncrir'; 'nhyb';};
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 08-July-2020
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
   
function attack(N,M,eXn,aTk)
NET={'er';'sw';'sf';'qs';'qr';'rt';'rr';'ho';'ol'};
LenNET=length(NET);
rng('shuffle')
LenCV=100;  % length of controllability curve obtained
    if~strcmp(eXn(1),aTk(1));  error('    ..check attack method !');  end
    if strcmp(eXn,'node')
        if N>1200;	Rept=20;
        else;       Rept=30;
        end
        bat=floor(N/LenCV);
    elseif strcmp(eXn,'edge')
        if N>1000 || M>=5000;       Rept=5;
        elseif(N==1000)&&(M<5000);	Rept=10;
        else;                       Rept=20;
        end
        bat=floor(M/LenCV);
    end
    res=cell(LenNET,Rept);
    for n=1:LenNET
        net=NET{n};
        disp([' ***** | NETWORK: ',upper(net),' | *****'])
        for r=1:Rept
            disp([' ----- | ',upper(net),' ',upper(aTk),' Attack (N=',int2str(N),' M=',int2str(M),') | ----- '])
            disp(['..  Net id: ',int2str(n),'/',int2str(LenNET)])
            disp(['.. Rept id: ',int2str(r),'/',int2str(Rept)]);
            switch net
                case'er';	A=er(N,M);
                case'sf';	A=sfd(N,M);
                case'sw';	A=sw(N,M);  % default K=2
                case'qs';	A=qs(N,M);
                case'rt';	A=rt(N,M);
                case'rr';	A=rr(N,M);
                case'qr';	A=qs(N,M);	A=pfd(A,0.5);  % with pre=0.5
                case'ho';	A=er(N,M);	A=rtf(A,N,M);  % extremely homogeneous
                case'ol';	A=old(N,M);
                otherwise;  error('  more topologies to be added..')
            end
            if strcmp(eXn,'node')
                if strcmp(aTk(1:4),'nrnd')
                    if N>1200; s.rept=5; else; s.rept=10; end
                end
                s.name=aTk;
                res{n,r}=remove_node(A,N,s,bat);
            else
                if strcmp(aTk,'ernd')
                    if N>1200; s.rept=2; else; s.rept=5; end
                end
                s.name=aTk;
                res{n,r}=remove_edge(A,N,M,s,bat);
            end
        end
    end
    fname=['res\N',int2str(N),'_M',int2str(M),'_',aTk];
    save(fname,'res','eXn','aTk','NET')
end

