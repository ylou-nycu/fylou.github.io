% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% random rectangle network
% updated: 29-05-2020
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

function A = rr(N,M)
Rec=4;
% --- Step(1) Generate a basic RR --- %
    A=zeros(N,N);
    for idx=1:Rec
        A(idx,mod(idx,Rec)+1)=1;
    end
    for idx = Rec+1:2:N   % add 2 links each time
        jdx=randi(idx-1);
        neb=[find(A(jdx,:)==1),find(A(:,jdx)==1)'];
        len_neb=length(neb);
        if length(unique(neb))<len_neb;   error('    .. check !');   end
        kdx=neb(randi(len_neb));
        if A(kdx,jdx)
            tmpv=kdx;  kdx=jdx;  jdx=tmpv;
        end
        A(idx,jdx)=1;	% idx -> jdx	% (jdx -> kdx) already existing in the network
        A(kdx,idx+1)=1;	% kdx -> idx+1
        A(idx+1,idx)=1;	% idx+1 -> idx	% Loop: idx -> jdx -> kdx -> idx+1 -> idx
    end
    if (N-idx)~=0&&(N-idx)~=1;   error('    .. check edge sum !');  end
    if (N-idx)==1  %% add just one more link, and form a triangle
        idx=N;
        jdx=randi(N-1);
        neb=[find(A(jdx,:)==1),find(A(:,jdx)==1)'];
        len_neb=length(neb);
        if length(unique(neb))<len_neb;   error('    .. check !');   end
        kdx=neb(randi(len_neb));
        if A(kdx,jdx)
            tmpv=kdx;  kdx=jdx;  jdx=tmpv;
        end
        A(idx,jdx)=1;	% idx -> jdx -> kdx (-> idx)
        A(kdx,idx)=1;
    end
% --- Step(2) control exact number of edges --- %
    cnt=sum(A,'all');
    deltaE=cnt-M;
    if deltaE>0
        while cnt>M
            delete_alink
            cnt=sum(A,'all');
        end
    elseif deltaE<0
        while deltaE<-3
            add_alink
            cnt=sum(A,'all');
            deltaE=cnt-M;
        end
        if deltaE  %% deltaE <= 3
            while cnt<M
                add_one_alink
                cnt=sum(A,'all');
            end
        end
    end
% --- Step(3) Check again (DELETE when it is not necessary anymore) --- %
    if sum(A,'all')~=M || graphconncomp(sparse(A),'Directed',true,'Weak',true)>1
        error('    .. check! ')
    end
    
% -----| control exact number of links |----- %
% -----| add 3 edges each time         |----- %
% -----| delete 1 edges each time      |----- %
    function add_alink
        r1=randi(N);
        neb1=find(A(r1,:)==0);
        neb1(neb1==r1)=[];
        len_neb1=length(neb1);
        while ~len_neb1
            r1=randi(N);  neb1=find(A(r1,:)==0);  neb1(neb1==r1)=[];
        end
        r2=neb1(randi(len_neb1));
        if ~A(r2,r1)  %% r1 -> r2
            A(r1,r2)=1;
        end
        neb1=find(A(r2,:)==0);
        neb1(neb1==r2)=[];
        len_neb1=length(neb1);
        if length(unique(neb1))<len_neb1;  error('    .. check !');   end
        if ~len_neb1;  return;  end
        r3=neb1(randi(len_neb1));
        if ~A(r3,r2)  %% r2 -> r3
            A(r2,r3)=1;
        end
        neb1=find(A(r3,:)==0);
        neb1(neb1==r3)=[];
        len_neb1=length(neb1);
        if length(unique(neb1))<len_neb1;  error('    .. check !');   end
        if ~len_neb1;  return;  end
        r4=neb1(randi(len_neb1));
        if ~A(r4,r3)  %% r3 -> r4
            A(r3,r4)=1;
        end
        if ~A(r1,r4)  %% r4 -> r1
            A(r4,r1)=1;
        end
    end

    function delete_alink
        r1=randi(N);
        neb1=[find(A(r1,:)==1),find(A(:,r1)==1)'];
        len_neb1=length(neb1);
        if length(unique(neb1))<len_neb1;  error('    .. check !');   end
        r2=neb1(randi(len_neb1));  %% default r2 -> r3
        A(r1,r2)=0;
        A(r2,r1)=0;
    end

    function add_one_alink
        r1=randi(N);
        neb1=find(A(r1,:)==0);
        neb1(neb1==r1)=[];
        len_neb1=length(neb1);
        while ~len_neb1
            r1=randi(N);  neb1=find(A(r1,:)==0);  neb1(neb1==r1)=[];
        end
        r2=neb1(randi(len_neb1));
        if ~A(r2,r1)  %% r1 -> r2
            A(r1,r2)=1;
        end
    end

end

