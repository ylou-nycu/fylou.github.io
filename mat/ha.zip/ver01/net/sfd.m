% -----  -----  -----  -----  -----  -----  -----  -----  -----
% directed generic Scale-Free network
% updated: 29-05-2020
% -----  -----  -----  -----  -----  -----  -----  -----  -----
% does not check if connected or not
% -----  -----  -----  -----  -----  -----  -----  -----  -----

function A = sfd(N,M)
    sfpara.theta=0;
    sfpara.mu=0.999;
    rng('shuffle')
    w=((1:N)+sfpara.theta).^(-sfpara.mu);
    ransec=cumsum(w);
% --- Step(1) Generate an SF --- %
    A=zeros(N,N);	cnt=0;
    while cnt<M
        r=rand*ransec(end);
        for i=1:N;  if r<=ransec(i);  break;  end;  end
        r=rand*ransec(end);
        for j=1:N;  if r<=ransec(j);  break;  end;  end
        if (i~=j)&&(~A(i,j));  A(i,j)=1;  cnt=cnt+1;  end
    end
% --- Step(2) If disconnected, try 10 times regeneration --- %
    A=zeros(N,N);       cnt=0;
    while cnt<M
        r=rand*ransec(end);
        for i=1:N;  if r<=ransec(i);  break;  end;  end
        r=rand*ransec(end);
        for j=1:N;  if r<=ransec(j);  break;  end;  end
        if (i~=j)&&(~A(i,j));  A(i,j)=1;  cnt=cnt+1;  end
    end
% --- Step(3) If STILL disconnected, add a backbone chain --- %
%     if graphconncomp(sparse(A),'Directed',true,'Weak',true)>1
%         disp('    .. can''t generate connected SF, a Chain added .. ')
%         A=diag(ones(1,N-1),1);  cnt=N-1;
%         while cnt<M
%             r=rand*ransec(end);
%             for i=1:N;  if r<=ransec(i);  break;  end;  end
%             r=rand*ransec(end);
%             for j=1:N;  if r<=ransec(j);  break;  end;  end
%             if (i~=j)&&(~A(i,j));  A(i,j)=1;  cnt=cnt+1;  end
%         end
%     end
% --- Step(4) Check again (DELETE when it is not necessary anymore) --- %
    if sum(A,'all')~=M
        error('    .. check! ')
    end
    if graphconncomp(sparse(A),'Directed',true,'Weak',true)>1
        disp('    ..disconnected ER generated')
    end
    
end


        