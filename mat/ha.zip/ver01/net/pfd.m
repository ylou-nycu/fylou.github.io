% p-forward (pfd) strategy for q-snapback network (qsn)
% #1. new version suitable for any topology
% #2. NOTE: (p) probability of reverse edge
%           p=#reverse_edge / (#total_edge - #chain_edge)
% -----  -----  -----  -----  -----  -----  -----  -----  -----
% updated 29-05-2020
% -----  -----  -----  -----  -----  -----  -----  -----  -----

function A = pfd(A,p,str)
% -----  -----  -----  -----  -----  -----  -----  -----  -----
% Input: A - adjacency matrix
%        p - probability of forward edge
%      str - strategy={'in_chain'; 'ex_chain'}  %% {in/ex}clude chain
% -----  -----  -----  -----  -----  -----  -----  -----  -----

    if nargin==2;  str='ex_chain';  end  %% default: do not reverse the chain
    N=size(A,1);
    A0=A;	% backup A
    if strcmp(str,'ex_chain')	% excluding backbone chain
        B=diag(ones(N-1,1),1);	% mask of backbone
        C=not(B);               % mask to EXCLUDE backbone
        A=A.*C;                 % 'A' without a backbone chain
    end
    E=sum(A,'all');
    revE=round(E*p);	% total number of reverse edges
    pos=find(A==1);
    rvd=0;              % number of reverse edges
    while rvd<revE
        Len=length(pos);
        if ~Len;   warning('    ..not enough edge to reverse ! ');  break;  end
        idx=randi(Len);
        A(pos(idx))=0;	% -> A(ii,jj)=0; // below for check only
        [ii,jj]=ind2sub(N,pos(idx));
        if A(jj,ii);   error('    ..double edges, check !');  end
        A(jj,ii)=1;
        pos(idx)=[];	% should NOT reverse again
        rvd=rvd+1;
    end
    A=A0.*B+A;	% add back backbone chain (if any)
end

