% -----  -----  -----  -----  -----  -----  -----  -----  -----
% directed Small-World network
% updated: 29-05-2020
% -----  -----  -----  -----  -----  -----  -----  -----  -----

function A = sw(N,M,K)
% Input: N,M - numbers of nodes and edges
%          K - number of connected neighbours

    if nargin<3;  K=2;  end     % K(2)->3node-small-world // K(1)->no-small-world
% --- Step(1) Generate a global LOOP --- %
    A=zeros(N,N);
    for i=1:N
        for j=(i+1):(i+K)
            jj=j;
            if j>N;  jj=mod(j,N);  end
            A(i,jj)=1;
        end
    end
% --- Step(2) Rewiring by adding or removing edges --- %
    cur_N = sum(A,'all');
    while cur_N>M
        warning('   .. deleting from initial SW structure ')
        deltaE=abs(cur_N-M);
        for i=1:deltaE
            delete_alink
        end
        cur_N=sum(A,'all');
    end
    while cur_N<M
        deltaE=abs(cur_N-M);
        for i=1:deltaE
            add_alink
        end
        cur_N=sum(A,'all');
    end
    if sum(A,'all')~=M || graphconncomp(sparse(A),'Directed',true,'Weak',true)>1
        error('    .. check! ')
    end   
    
% ----- Auxiliary Functions ----- %
    function add_alink
        idx=randi(N);
        list=find(~A(idx,:));
        list(list==idx)=[];
        while isempty(list)
            idx=randi(N);
            list=find(~A(idx,:));
            list(list==idx)=[];
        end
        jdx=list(randi(length(list)));
        A(idx,jdx)=1;
    end

    function delete_alink
        idx=randi(N);
        list=find(A(idx,:));
        while isempty(list)
            idx = randi(N);
            list=find(A(idx,:));
        end
        jdx = list(randi(length(list)));
        A(idx,jdx) = 0;
    end

end

