% -----  -----  -----  -----  -----  -----  -----  -----  -----
% directed q-Snapback network
% updated: 29-05-2020
% -----  -----  -----  -----  -----  -----  -----  -----  -----

function A = qs(N,M)
% Input:  N,M - numbers of nodes and edges
    r=2;
    itop='chain';
    q=q_nlink(r,N,'e2q',M);	% estimate 'q', according to (r,N,M)
% --- Step(1) Generate a QSN --- %
    A=zeros(N,N);
    for rdx=1:r
        if rdx==1
            switch itop
                case 'chain';	A=diag(ones(1,N-1),1);
                case 'ring';    A=diag(ones(1,N-1),1);  A(N,1) = 1;
                case 'tree';	for i=1:N-1;  A(i,i+randi(N-i))=1;  end;   A(N,1)=1;
            end
        else  % for node(i), perform q-snapback
            for i=rdx+1:N
                for j=(i-rdx):-(rdx-1):(rdx-1) %% (i-rdx):-1:(rdx-1)
                    if rand<=q;  A(i,j)=1;  end
                end
            end
        end
    end
% --- Step(2) control exact number of edges --- %
    cnt=sum(A,'all');
    deltaE=cnt-M;
    if deltaE>0
        for i=1:deltaE;  delete_alink;  end
    elseif deltaE<0
        deltaE=abs(deltaE);
        for i=1:deltaE;  add_alink;  end
    end
% --- Step(3) Check again (DELETE when it is not necessary anymore) --- %
    if sum(A,'all')~=M || graphconncomp(sparse(A),'Directed',true,'Weak',true)>1
        error('    .. check! ')
    end
    
    
% ----- Auxiliary Functions ----- %
    function add_alink
        idx=randi(N);
        list=find(A(idx,1:idx-2)==0);
        while isempty(list)
            idx=randi(N);
            list=find(A(idx,1:(idx-2))==0);
        end
        jdx=list(randi(length(list)));
        A(idx,jdx)=1;
    end

    function delete_alink
        idx=randi(N);
        list=find(A(idx,1:idx-2)==1);
        while isempty(list)
            idx=randi(N);
            list=find(A(idx,1:idx-2)==1);
        end
        jdx=list(randi(length(list)));
        A(idx,jdx)=0;
    end

end


% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% q <--> #links calculation in q-snapback
% Examples:
%       [1] given total number of links, return q
%           q = q_nlink(2,10000,'e2q',60600)
%       [2] given q, return total number of links
%           e = q_nlink(2,10000,'q2e',0.001)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% updated: 15-09-2018
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
function res = q_nlink(r,N,s,x)
% If s == 'q2e', x is value of q \in[0,1]
% If s == 'e2q', x is number of edges
    switch s
        case 'q2e';  res=q2nlink(r,N,x);
        case 'e2q';  res=nlink2q(r,N,x);
    end
    % ----- auxiliary functions (1) ----- %
    % given total number of links, return 'q'
    function q_qsn = nlink2q(r,N,nlink)
        PRECISION=1E5;
        q_qsn=(nlink-N)/sum(((r+1):N-2)/(r-1));
        q_qsn=round(q_qsn*PRECISION)/PRECISION;
    end
    % ----- auxiliary functions (2) ----- %
    % given 'q', return the total number of links it would be
    function total_deg = q2nlink(r,N,q)
        deg=zeros(N,1);
        for i=1:r;  deg(i)=1;  end
        for i=r+1:N
            deg(i)=1+floor((i-2)/(r-1))*q;
        end
        total_deg=round(sum(deg));
    end
end



