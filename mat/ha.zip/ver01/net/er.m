% -----  -----  -----  -----  -----  -----  -----  -----  -----
% directed ER network
% updated: 29-05-2020
% -----  -----  -----  -----  -----  -----  -----  -----  -----

function A = er(N,M)
% Input:  N,M - numbers of nodes and edges

% --- Step(1) Generate an ER --- %
    A=zeros(N,N);       cnt=0; 
    while cnt<M
        i=randi(N);     j=randi(N);
        while (j==i)||A(i,j)
            i=randi(N);	j=randi(N);
        end
        A(i,j)=1;
        cnt = cnt+1;
    end
% --- Step(2) If disconnected, try 10 times regeneration --- %
    idx=1;
    while (idx<10)&&(graphconncomp(sparse(A),'Directed',true,'Weak',true)>1)
        idx=idx+1;
        A=zeros(N,N);       cnt=0;
        while cnt<M
            i=randi(N);     j=randi(N);
            while (j==i)||A(i,j)
                i=randi(N);	j=randi(N);
            end
            A(i,j)=1;
            cnt = cnt+1;
        end
    end
% % --- Step(3) If STILL disconnected, add a backbone chain --- %
%     if graphconncomp(sparse(A),'Directed',true,'Weak',true)>1
%         disp('    .. can''t generate connected ER, a Chain added .. ')
%         A=diag(ones(1,N-1),1);
%         cnt=N-1;
%         while cnt<M
%             i=randi(N);     j=randi(N);
%             while (j==i)||A(i,j)
%                 i=randi(N);	j=randi(N);
%             end
%             A(i,j)=1;
%             cnt = cnt+1;
%         end
%     end
% --- Step(4) Check again (DELETE when it is not necessary anymore) --- %
    if sum(A,'all')~=M
        error('    .. check! ')
    end
    if graphconncomp(sparse(A),'Directed',true,'Weak',true)>1
        disp('    ..disconnected ER generated')
    end
end


