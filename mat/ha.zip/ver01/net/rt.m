% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% random triangle network
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% updated: 29-05-2020
% -----  -----  -----  -----  -----  -----  -----  -----  -----

function A = rt(N,M)
Tri=3;
% --- Step(1) Generate a basic RT --- %
    A=zeros(N,N);
    for idx = 1:Tri
        A(idx,mod(idx,Tri)+1)=1;  %% form a Loop
    end
    for idx = Tri+1:1:N
        jdx=randi(idx-1);
        neb=[find(A(jdx,:)==1),find(A(:,jdx)==1)'];
        len_neb=length(neb);
        if length(unique(neb))<len_neb;   error('    .. check !');   end
        kdx=neb(randi(len_neb));
        if A(kdx,jdx)
            tmpv=kdx;  kdx=jdx;  jdx=tmpv;
        end
        A(idx,jdx)=1;  %% idx -> jdx -> kdx (-> idx)
        A(kdx,idx)=1;
    end
% --- Step(2) control exact number of edges --- %
    cnt=sum(A,'all');
    deltaE=cnt-M;
    if deltaE>0
        while cnt>M
            delete_alink
            cnt=sum(A,'all');
        end
    elseif deltaE<0
        while cnt<M
            add_alink
            cnt=sum(A,'all');
        end
        while cnt>M
            delete_alink
            cnt=sum(A,'all');
        end
    end
% --- Step(3) Check again (DELETE when it is not necessary anymore) --- %
    if sum(A,'all')~=M || graphconncomp(sparse(A),'Directed',true,'Weak',true)>1
        error('    .. check! ')
    end
    
% -----| control exact number of links |----- %
% -----| add 2 edges each time         |----- %
% -----| delete 1 edges each time      |----- %
    function add_alink
        r=randperm(N,2);
        r1=r(1);  r2=r(2);
        while A(r1,r2) || A(r2,r1);  r=randperm(N,2);  r1=r(1);  r2=r(2);  end
        neb1=[find(A(r2,:)==1),find(A(:,r2)==1)'];
        len_neb1=length(neb1);
        if length(unique(neb1))<len_neb1   error('    .. check !');   end
        r3=neb1(randi(len_neb1));
        if A(r3,r2)	%% r3 -> r2
            A(r2,r1)=1;
            if ~A(r1,r3) && ~A(r3,r1);  A(r1,r3)=1;  end
        else        %% default r2 -> r3
            A(r1,r2)=1;
            if ~A(r1,r3) && ~A(r3,r1);  A(r3,r1)=1;  end
        end
    end

    function delete_alink
        r1=randi(N);
        neb1=[find(A(r1,:)==1),find(A(:,r1)==1)'];
        len_neb1=length(neb1);
        if length(unique(neb1))<len_neb1;   error('    .. check !');   end
        r2=neb1(randi(len_neb1));  %% default r2 -> r3
        A(r1,r2)=0;
        A(r2,r1)=0;
    end

end

