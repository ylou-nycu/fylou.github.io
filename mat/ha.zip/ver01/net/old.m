% -----  -----  -----  -----  -----  -----  -----  -----  -----
% directed Onion-Like Scale-Free network
% updated: 06-06-2020
% -----  -----  -----  -----  -----  -----  -----  -----  -----

function A = old(N,M)
str='rand';
    A = sfd(N,M);	% initialization of a generic scale-free network
    if N>1000;                  bat=20;
    elseif(N>500)&&(N<=1000);	bat=10;
    else;                       bat=5;
    end
    stag=0;  max_stag=round(M/10);
    fmax=rscore(A,str,bat);
    for iter=1:N
        e=find(A==1);
        tmpi=randperm(length(e));
        e1=tmpi(1);
        e2=tmpi(2);
        [ro1,co1] = ind2sub([N,N],e1);
        [ro2,co2] = ind2sub([N,N],e2);
        B=A;
        B(ro1,co1)=0;
        B(ro1,co2)=1;
        B(ro2,co2)=0;
        B(ro2,co1)=1;
        f=rscore(B,str,bat);
        if f>fmax
            fmax=f;  A=B;  stag=0;
        else
            stag=stag+1;
            if stag>max_stag;  break;  end
        end
    end
end


function lcc = rscore(A,str,len)
    lcc=0;
    N=size(A,1);
    for i=1:N-1
        cur_N=size(A,1);
        switch str
            case'rand'; j=randperm(cur_N); n=min(len,length(j)); pos=j(1:n);
            case'nbet'; pos=max_bet(A,'node',len);
            case'ndeg'; pos=max_deg(A,'node',len);
        end
        A(pos,:)=[];
        A(:,pos)=[];
        [~,cls]=graphconncomp(sparse(A),'Directed',true,'Weak',true);
        tmpi=max(cls);  tmps=zeros(tmpi,1);
        for ii=1:tmpi;  tmps(ii)=sum(cls==ii);  end
        lcc=lcc+max(tmps);
    end
end
