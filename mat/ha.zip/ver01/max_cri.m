% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% search for the critical edge/node list in the current network
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% updated: 04-08-2020
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

function [crit,hie] = max_cri(A,eXn,str,len)
% Input:     A - adj mat
%          eXn - if: 'node' || then: str - {'bet';'deg';'clo';}
%          eXn - if: 'edge' || then: str - {'bet';'deg';}
%          len - # of max_cri nodes/edges returned     
% -----  -----  -----  -----  -----  -----  ----- 
% Output: crit - critical edge/node list
%          hie - hierarchical level
% hierarchical level (0)critical; (1)sub-critical; (2)normal; (3)rest
% -----  -----  -----  -----  -----  -----  -----
    if nargin<4; len=1; end
    crit=[];	meas=[];  % critical edge/node      and  measure='betweenness' or 'degree'
    subcr=[];	subms=[]; % sub-critical edge/node	and  sub-measure
    noncr=[];	nonms=[]; % non-critical edge/node	and  non-measure
    tabu=[]; 	% banned list (isolated nodes etc.)
    N=size(A,1);  M=sum(A,'all');
    n0=max(N-sum(dmperm(A)~=0),1);	% #driver nodes needed
    m0=N-sum(dmperm(A)~=0);         % #unmatched nodes
    if strcmp(eXn,'node')
        if strcmp(str,'bet')        % measure=betweenness for sorting
            B=sparse(A);
            [val,~]=betweenness_centrality_mex(B,'matrix');
            clear B
        elseif strcmp(str,'deg')	% measure=degree for sorting
            val=sum(A,2);           % out-degree only
        elseif strcmp(str,'clo')
            G=digraph(A);
            val=centrality(G,'outcloseness');            
        end
        N0=N-1;   % always remove one node
        for idx=1:N
            A0=A;
            A0(idx,:)=0;   A0(:,idx)=0;         % remove the node: idx
            if max(N0-sum(dmperm(A0)~=0),1)>n0	% /* #driver_node ++ */
                crit=[crit;idx];                % a critical node
                meas=[meas;val(idx)];           % either 'betweenness' or 'out-degree'
            elseif max(N0-sum(dmperm(A0)~=0),1) == n0	% /* #driver_node == */
                if N0-sum(dmperm(A0)~=0)>m0     % #unmatched node ++
                    subcr=[subcr;idx];          % a sub-critical node
                    subms=[subms;val(idx)];     % either 'betweenness' or 'out-degree'
                else
                    noncr=[noncr;idx];          % a non-critical node 3rd option
                    nonms=[nonms;val(idx)];     % either 'betweenness' or 'out-degree'
                end
            else   % max(N0-sum(dmperm(A0)~=0),1) < n0	% /* #driver_node -- */ % e.g., delete an isolated node
                tabu=[tabu;idx];
            end
        end
    elseif strcmp(eXn,'edge')
        ep=find(A==1);              % edge position
        if strcmp(str,'bet')        % measure=betweenness for sorting
            B=sparse(A);
            [~,val]=betweenness_centrality_mex(B,'matrix');
            clear B
        elseif strcmp(str,'deg')	% measure=degree for sorting
            ko=sum(A,2);            % out-degree
            ki=sum(A,1)';           % in-degree
            [row,col]=ind2sub([N,N],ep);
            val=ko(row)+ki(col);	% edge-degree=source_node(k_out)+target_node(k_in)
        elseif strcmp(str,'clo')
            error('    ..no closeness centrality for edges!')
        end
        for idx=1:M
            A0=A;
            A0(ep(idx))=0;          % remove the edge: ep(idx)
            if max(N-sum(dmperm(A0)~=0),1)>n0	% #driver_node ++
                crit=[crit;ep(idx)];            % a critical edge
                meas=[meas;val(idx)];           % either 'betweenness' or 'edge-degree'
            elseif max(N-sum(dmperm(A0)~=0),1)==n0	% #driver_node ++
                if N-sum(dmperm(A0)~=0)>m0      % #unmatched node ++
                    subcr=[subcr;ep(idx)];      % a subcritical edge
                    subms=[subms;val(idx)];     % either 'betweenness' or 'edge-degree'
                else
                    noncr=[noncr;ep(idx)];
                    nonms=[nonms;val(idx)];
                end
            else   % max(N-sum(dmperm(A0)~=0),1)<n0	% /* #driver_node -- */ % e.g., delete an isolated node
                % tabu=[tabu;idx];
                error('   .. why come here ?')
            end
        end
    end
    if isempty(crit)
        if isempty(subcr); if isempty(noncr); hie=3; else; hie=2; end; else; hie=1; end
    else
        hie=0;  % cri
    end    
    [~,pos]=sort(meas,'descend');	crit=crit(pos);
    [~,pos]=sort(subms,'descend');	subcr=subcr(pos);
    [~,pos]=sort(nonms,'descend');  noncr=noncr(pos);
    crit=[crit;subcr;noncr;tabu];
    n=min(len,length(crit));
    crit=crit(1:n);
end

