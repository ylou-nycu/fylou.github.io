% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% The function 'betweenness_centrality_mex' is from MatlabBGL
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% MatlabBGL is a Matlab package for working with graphs.
% It uses the Boost Graph Library to efficiently implement
% the graph algorithms.  MatlabBGL is designed to work with
% large sparse graphs with hundreds of thousands of nodes.
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% For more information, please visit:
% https://www.cs.purdue.edu/homes/dgleich/packages/matlab_bgl/
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function pos = max_bet(A,type,len)
    if ~issparse(A);  A=sparse(A);	end
    if nargin<3;      len=1;        end
    switch type
        case 'node'  % Get the betweenness of every node
            [vc,~]=betweenness_centrality_mex(A,'matrix');
            [~,p]=sort(vc,'descend');
            n=min(len,length(p));
            pos=p(1:n);
        case 'edge'  % Get the betweenness of every edge
            [~,ec]=betweenness_centrality_mex(A,'matrix');
            [~,p]=sort(ec,'descend');
            n=min(len,length(p));
            e=find(A);
            pos=e(p(1:n));
    end
end

