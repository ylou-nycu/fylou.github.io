% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% search for the critical edge/node list in the current network
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% updated: 08-July-2020
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

function [list,crit] = rnd_cri(A,N,M,eXn)
% Input:  eXn - {'edge';'node'}
%       A,N,M - adj_mat, #nodes, and #edges
% -----  -----  -----  -----  -----  -----  ----- 
% Output:  crit - critical edge/node list
% -----  -----  -----  -----  -----  -----  -----
    crit=[];	% critical edge/node
    n0=max(N-sum(dmperm(A)~=0),1);	% #driver nodes needed
    if strcmp(eXn,'node')
        N0=N-1;   % always remove one node
        for idx=1:N
            A0=A;
            A0(idx,:)=0;   A0(:,idx)=0;         % remove the node: idx
            if max(N0-sum(dmperm(A0)~=0),1)>n0	% /* #driver_node ++ */
                crit=[crit;idx];                % a critical node
            end
        end
        list=randperm(N)';
        if ~isempty(crit)
            for idx=1:length(crit);  list(list==crit(idx))=[];  end
        end
        list=[crit;list];
    elseif strcmp(eXn,'edge')
        ep=find(A==1);              % edge position
        for idx=1:M
            A0=A;
            A0(ep(idx))=0;          % remove the edge: ep(idx)
            if max(N-sum(dmperm(A0)~=0),1)>n0	% #driver_node ++
                crit=[crit;ep(idx)];            % a critical edge
            end
        end
        list=ep;
        if ~isempty(crit)
            for idx=1:length(crit);  list(list==crit(idx))=[];  end
        end
        list=list(randperm(length(list)));
        list=[crit;list];
    end
end

