% -----  -----  -----  -----  -----  -----  -----  -----  -----
% return the max_edge_degree node/edge
% -----  -----  -----  -----  -----  -----  -----  -----  -----
% updated: 29-05-2020
% -----  -----  -----  -----  -----  -----  -----  -----  -----

function pos = max_deg(A,eXn,len)
%    A - adj matrix
%  eXn - 'node' or 'edge'
%  str - when (max)degree value equals
    if nargin<3;  len=1;  end
    switch eXn
        case 'node'
            k=sum(A,2);   % consider 'out-degree'
            [~,p]=sort(k,'descend');
            n=min(len,length(p));
            pos=p(1:n,1);
            tmpval=min(k(pos));
            tmpidx=find(k==tmpval);
            pos(k(pos)==tmpval)=[];
            delta=n-length(pos);
            tmpidx=tmpidx(randperm(length(tmpidx)));
            tmpidx=tmpidx(1:delta);
            pos=[pos;tmpidx];
        case 'edge'
            ko=sum(A,2);	% out-degree
            ki=sum(A,1)';	% in-degree
            ep=find(A==1);	% edge position
            [row,col]=ind2sub(size(A),ep);
            val=ko(row)+ki(col);
            [~,p]=sort(val,'descend');
            n=min(len,length(p));
            pos=ep(p(1:n));
    end
end

