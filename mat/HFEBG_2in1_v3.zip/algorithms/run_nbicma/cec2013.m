
function [fmin] = cec2013()
% Added Twe Output Paras by Felix

global mystat; 
global settings;
mystat.Probset = 'cec2013';

    fn = settings.funs;
    mystat.func_num = fn;
    j = settings.instances;
    rand('state',sum((100+j)*clock));
    mystat.D = settings.dims;
    mystat.Fbest = 1e+30;
    mystat.nevals = 0;
    mystat.iinst = j;
    
    func_target = -1500 + fn*100;
    if (fn >= 15)
        func_target = func_target + 100;
    end
    %%func_target = -Inf;
    mystat.func_target = func_target;

    %[fmin,cv] = Adapter();
    Adapter();
    fmin = mystat.Fbest;

end