%%>> CMA-ES
%%>> NBIPOPaCMA
%%>> 
%%>> 
%%>> 


function [fmin] = run_nbicma(ProbSet,fn,d,ps,lbin,ubin,maxfes,fgb)
global Prob;
global settings;
%%cv = [];
% -----  ----- Global Variable  -----  ----- %
Prob.setName = ProbSet;  %% {'cec2013'; 'glg06'}
if strcmp(ProbSet,'glg06')
    Prob.fn = fn;
    Prob.d = d;
    Prob.bd_u = ubin;
    Prob.bd_l = lbin;
    Prob.maxfes = maxfes;
end
% -----  ----- Global Variable  -----  ----- %
%%addpath('non_essential');

    settings.dims = d;	%% Dimension Set Here
    settings.funs = fn;	%% Function ID, for CEC 2013 only
    settings.instances = 1;
    settings.pathname = 'd1';
    settings.algname = '';
    settings.ntarray = [1];
    %%settings.savfile = 'r1';

    settings.newRestartRules = 0; 
    settings.noisy = 0;
    settings.CMAactive = 1;
    settings.withFileDisp = 0;
    settings.withSurr = 0;
    settings.modelType = 1;
    settings.withModelEnsembles = 0;
    settings.withModelOptimization = 1;
    settings.hyper_lambda = 20;
    settings.iSTEPminForHyperOptimization = 1;
    settings.MaxEvals = maxfes;  %% String to Double
    settings.MaxEvalsWithSurrogate = '0';
    settings.lambdaMult = 1;
    settings.muMult = 1;
    settings.largeLambdaMinIter = 1;

    settings.withDisp = 0;
    settings.maxStepts = 20;
    settings.maxerr = 0.45;
    settings.alpha = 0.20;
    settings.iterstart = 10;
    
    settings.BIPOP = 1;
    settings.newRestartRules = 1;
    settings.CMAactive = 1;
    switch ProbSet
        case 'cec2013'
            fmin = cec2013();
        case 'glg06'
            fmin = glg2006(fgb);
    end
    
end
