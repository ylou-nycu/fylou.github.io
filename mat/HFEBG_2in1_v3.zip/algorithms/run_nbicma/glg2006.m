
function [fmin] = glg2006(fgb)
%function [fmin] = glg2006(ProbSet,fn,d,ps,lbin,ubin,maxfes)  << For Test Only
global Prob;
global mystat; 
%global settings;

mystat.Probset = 'glg2006';
% -----  -----  -----  Construct GLG (For Test Only)  -----  -----  ----- %
% % % %mystat.Probset = Probset;
% % % fn = 1;  %% Whatever it is in GLG2006 Set
% % % nGauss	= 1;
% % % ub = ubin;
% % % lb = lbin;
% % % gbf = 1;  %% Global Best Fitness Value -1
% % % 
% % % % The Maximum Var = 1/36, and thus Sigma = 1/6
% % % sig	= ones(nGauss,1);  %% 1/36*ones(nGauss,1);
% % % rot	= rand(nGauss,1);  %% rot = zeros(nGauss,1);
% % % sqz = ones(nGauss,d);
% % % rat	= ones(nGauss-1,1);
% % % 
% % % for idx = 1:nGauss
% % %     sig(idx,1) = rand/36;
% % %     while ~sig(idx,1)  %% Sigma Should be Non-Zero
% % %         sig(idx,1) = rand/36;
% % %     end
% % %     rot(idx,1) = rand;
% % %     for jdx = 1:d
% % %         sqz(idx,jdx) = rand*0.9 + 0.1;
% % %     end    
% % %     rat(idx,1) = 1 - (idx-1)*(1/nGauss);
% % % end
% % % 
% % % sig(1,1) = 1/2;
% % % rat(1,1) = 1;% Must be One %
% % % 
% % % [fgb,~] = glg06_init(d,nGauss,ub,lb,gbf,sig,rot,sqz,rat);
% % % % Return Fitness of Global Best %
% -----  -----  -----  Construct GLG (For Test Only)  -----  -----  ----- %

    mystat.func_num = Prob.fn ;
    mystat.D = Prob.d;
    mystat.Fbest = 1e+30;
    mystat.nevals = 0;
    mystat.func_target = fgb;
    
    Adapter();
    fmin = mystat.Fbest;

end