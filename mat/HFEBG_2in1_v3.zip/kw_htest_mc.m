% kw_htest_mc.m
% Multiple Comparison Using KW H-test
% Updated: 15-04-2018

function f = kw_htest_mc(v1,v2)
% v1 - target EA
% v2 - other EAs

    % check size
    [l1,w1] = size(v1);
    [l2,w2] = size(v2);
    if w1~=1 || l1~=l2;  error('check here ...');  end

    v = [v1,v2];
    [~,~,s] = kruskalwallis(v,[],'off');
    c = multcompare(s,'display','off');
    tmpv = c(1:w2,6);
    [f,~] = max(tmpv);

end

