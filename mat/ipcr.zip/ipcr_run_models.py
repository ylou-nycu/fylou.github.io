# for ipcr prediction
import numpy as np
import os
import scipy.io as sio
import timeit

start = timeit.default_timer()
os.system('python ipcr_classification.py')  # classification
model_names=['ba','er','qs','sw','any']
prob=np.loadtxt('prob_result.txt')
pred=np.loadtxt('pred_result.txt')
list_any=[]
list_ba=[]
list_er=[]
list_qs=[]
list_sw=[]
for i in range(len(prob)):
    if float(prob[i])<0.8:
        list_any.append(i)
    else:
        if int(pred[i])==0:
            list_ba.append(i)
        elif int(pred[i])==1:
            list_er.append(i)
        elif int(pred[i])==2:
            list_qs.append(i)
        else:
            list_sw.append(i)
np.savetxt('list_any.txt',list_any,'%d')
np.savetxt('list_ba.txt',list_ba,'%d')
np.savetxt('list_er.txt',list_er,'%d')
np.savetxt('list_qs.txt',list_qs,'%d')
np.savetxt('list_sw.txt',list_sw,'%d')
# run prediction (after classification)
os.system('python ipcr_pred.py any')
os.system('python ipcr_pred.py ba')
os.system('python ipcr_pred.py er')
os.system('python ipcr_pred.py qs')
os.system('python ipcr_pred.py sw')
stop = timeit.default_timer()
print('Time: ', stop - start)
# to save all data in 'pred_result.mat' file
any_res=np.loadtxt('pred_any.txt')
ba_res=np.loadtxt('pred_ba.txt')
er_res=np.loadtxt('pred_er.txt')
qs_res=np.loadtxt('pred_qs.txt')
sw_res=np.loadtxt('pred_sw.txt')
iany=-1
iba=-1
ier=-1
iqs=-1
isw=-1
pred_result=[]
for i in range(len(prob)):
    if float(prob[i])<0.8:
        iany=iany+1;
        pred_result.append(any_res[iany])
    else:
        if int(pred[i])==0:
            iba=iba+1;
            pred_result.append(ba_res[iba])
        elif int(pred[i])==1:
            ier=ier+1
            pred_result.append(er_res[ier])
        elif int(pred[i])==2:
            iqs=iqs+1
            pred_result.append(qs_res[iqs])
        else:
            isw=isw+1
            pred_result.append(sw_res[isw])
sio.savemat('pred_result.mat', {'pred_result': pred_result, 'pred_class': pred, 'prob_class': prob})
print('iPCR results [pred_result.mat] saved!')


# total run time = 304s for 240 instances
# average run time = 1.27s
# Intel(R) Core(TM) i7-9750H CPU @ 2.60GHz 2.59GHz
# Installed memory (RAM): 16.0GB (15.8 usable)
# Windows 10 Home 64-bit Operating System