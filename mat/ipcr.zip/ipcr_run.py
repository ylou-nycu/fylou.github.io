# for ipcr prediction
import numpy as np
import os
import scipy.io as sio
import timeit

start = timeit.default_timer()
os.system('python ipcr_classification.py')  # classification
model_names=['ba','er','qs','sw','any']     # label['any'] == label['all'] in the paper
cp=np.loadtxt('class_probability.txt')
cl=np.loadtxt('classified_label.txt')
list_any=[]
list_ba=[]
list_er=[]
list_qs=[]
list_sw=[]
for i in range(len(cp)):
    if float(cp[i])<0.8:
        list_any.append(i)
    else:
        if int(cl[i])==0:
            list_ba.append(i)
        elif int(cl[i])==1:
            list_er.append(i)
        elif int(cl[i])==2:
            list_qs.append(i)
        else:
            list_sw.append(i)
np.savetxt('list_any.txt',list_any,'%d')
np.savetxt('list_ba.txt',list_ba,'%d')
np.savetxt('list_er.txt',list_er,'%d')
np.savetxt('list_qs.txt',list_qs,'%d')
np.savetxt('list_sw.txt',list_sw,'%d')
# run prediction (after classification)
os.system('python ipcr_prediction.py any')
os.system('python ipcr_prediction.py ba')
os.system('python ipcr_prediction.py er')
os.system('python ipcr_prediction.py qs')
os.system('python ipcr_prediction.py sw')
stop = timeit.default_timer()
print('Time: ', stop - start)
# to save all data in 'classified_label.mat' file
any_res=np.loadtxt('pv_any.txt')
ba_res=np.loadtxt('pv_ba.txt')
er_res=np.loadtxt('pv_er.txt')
qs_res=np.loadtxt('pv_qs.txt')
sw_res=np.loadtxt('pv_sw.txt')
iany=-1
iba=-1
ier=-1
iqs=-1
isw=-1
res=[]
for i in range(len(cp)):
    if float(cp[i])<0.8:
        iany=iany+1
        res.append(any_res[iany])
    else:
        if int(cl[i])==0:
            iba=iba+1
            res.append(ba_res[iba])
        elif int(cl[i])==1:
            ier=ier+1
            res.append(er_res[ier])
        elif int(cl[i])==2:
            iqs=iqs+1
            res.append(qs_res[iqs])
        else:
            isw=isw+1
            res.append(sw_res[isw])
sio.savemat('ipcr_result.mat', {'ipcr_result': res, 'classified_label': cl, 'class_probability': cp})
print('iPCR results saved in [ipcr_result.mat] !')


# total run time = 292.5 for 240 instances
# average run time = 1.22s
# Intel(R) Core(TM) i7-9750H CPU @ 2.60GHz 2.59GHz
# Installed memory (RAM): 16.0GB (15.8 usable)
# Windows 10 Home 64-bit Operating System