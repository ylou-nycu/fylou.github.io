# for controllability curve prediction

import tensorflow as tf
import numpy as np
import os
import scipy.io as sio
import sys
from statistics import *
#import timeit
#start = timeit.default_timer()

name=sys.argv[1]
#name='ba'
list_flt=np.loadtxt('list_'+name+'.txt')
list_id=np.array(list_flt, dtype=int)
print(list_id)
dt_name='trn_'+name
mat=sio.loadmat('test.mat')
num_of_test_instances=len(mat['test'])
cur_path=os.getcwd() # Get current path

# load testing instances
def load_mat(idx):
    A=[]
    tmpA = mat['test'][idx,0]['A'][0,0].todense()
    A.append(np.expand_dims(tmpA, axis=2))
    return A


# define functions
def Weight_variable(shape):
    initial = tf.random.truncated_normal(shape, stddev=0.005)
    return tf.Variable(initial)

def Bais_variable(shape):
    initial = tf.constant(0.005, shape=shape)
    return tf.Variable(initial)

def max_pool_2(x):
    return tf.nn.max_pool2d(x,[1,2,2,1],[1,2,2,1],'SAME')

def conv2d_stride1(x,W):
    return tf.nn.conv2d(x, W, strides=[1, 1, 1, 1], padding='SAME')

def sig_filter(y):
    lnb=4
    #row,col=y.shape
    row=len(y)
    col=len(y[0])
    n=col+1
    for i in range(row):
        k0=max(round(float(y[i][0]))*col,1)
        for j in range(col):
            ub=min(k0+j+1,n-j-1)/(n-j-1)
            y[i][j] = min(abs(y[i][j]),ub)      # less than upper bound
            y[i][j] = max(y[i][j], 1/(n-j-1))   # greater than lower bound
            if j<lnb or j>=(col-lnb):
                tmpy=[y[i][j],y[i][j]]
            else:
                tmpy = y[i][[range(j-lnb,j+lnb)]]
            y[i][j]=median(tmpy)
    return y


class cnn_for_robustness():
    def __init__(self):
        # layer1
        self.w_conv1_1=Weight_variable([7,7,1,64])
        self.b_conv1_1=Bais_variable([64])
        # layer2
        self.w_conv2_1 = Weight_variable([5,5,64,64])
        self.b_conv2_1 = Bais_variable([64])
        # layer3
        self.w_conv3_1 = Weight_variable([3,3,64,128])
        self.b_conv3_1 = Bais_variable([128])
        # layer4
        self.w_conv4_1 = Weight_variable([3,3,128,128])
        self.b_conv4_1 = Bais_variable([128])
        # layer5
        self.w_conv5_1 = Weight_variable([3,3,128,256])
        self.b_conv5_1 = Bais_variable([256])
        # layer6
        self.w_conv6_1 = Weight_variable([3,3,256,256])
        self.b_conv6_1 = Bais_variable([256])
        # layer7
        self.w_conv7_1 = Weight_variable([3,3,256,512])
        self.b_conv7_1 = Bais_variable([512])
        self.w_conv7_2 = Weight_variable([3,3,512,512])
        self.b_conv7_2 = Bais_variable([512])
    def compu_conv(self, input_ma):
        # layer1
        h_conv1_1 = tf.nn.relu(conv2d_stride1(input_ma, self.w_conv1_1) + self.b_conv1_1)
        out_layer1 = max_pool_2(h_conv1_1)
        # layer2
        h_conv2_1 = tf.nn.relu(conv2d_stride1(out_layer1, self.w_conv2_1) + self.b_conv2_1)
        out_layer2 = max_pool_2(h_conv2_1)
        # layer3
        h_conv3_1 = tf.nn.relu(conv2d_stride1(out_layer2, self.w_conv3_1) + self.b_conv3_1)
        out_layer3 = max_pool_2(h_conv3_1)
        # layer4
        h_conv4_1 = tf.nn.relu(conv2d_stride1(out_layer3, self.w_conv4_1) + self.b_conv4_1)
        out_layer4 = max_pool_2(h_conv4_1)
        # layer5
        h_conv5_1 = tf.nn.relu(conv2d_stride1(out_layer4, self.w_conv5_1) + self.b_conv5_1)
        out_layer5 = max_pool_2(h_conv5_1)
        # layer6
        h_conv6_1 = tf.nn.relu(conv2d_stride1(out_layer5, self.w_conv6_1) + self.b_conv6_1)
        out_layer6 = max_pool_2(h_conv6_1)
        # layer7
        h_conv7_1 = tf.nn.relu(conv2d_stride1(out_layer6, self.w_conv7_1) + self.b_conv7_1)
        h_conv7_2 = tf.nn.relu(conv2d_stride1(h_conv7_1, self.w_conv7_2) + self.b_conv7_2)
        out_layer7 = max_pool_2(h_conv7_2)
        return out_layer7


in_matrix = tf.compat.v1.placeholder(tf.float32)
input_matrix=tf.reshape(in_matrix, [-1, 1000, 1000,1])
score=tf.compat.v1.placeholder(tf.float32)
network=cnn_for_robustness()
out_matr=network.compu_conv(input_matrix)

shape=out_matr.get_shape()
length=shape[1].value*shape[2].value*shape[3].value
out_o=tf.reshape(out_matr,[-1,length])

# fc1
w_fc_1 = Weight_variable([length,4096])
b_fc_1 = Bais_variable([4096])
h_fc_1 = tf.nn.relu(tf.matmul(out_o, w_fc_1) + b_fc_1)

# fc2
w_fc_2 = Weight_variable([4096,999])
b_fc_2 = Bais_variable([999])
h_fc_2 = tf.matmul(h_fc_1, w_fc_2) + b_fc_2
h_fc_2=tf.maximum(h_fc_2,0)
h_fc_2=tf.minimum(h_fc_2,1)

# loss value
mse_loss=tf.reduce_sum(tf.square(h_fc_2 - score), 1)
loss = tf.reduce_mean(mse_loss)
train_step = tf.compat.v1.train.AdamOptimizer(learning_rate=5e-5,beta1=0.9,beta2=0.999,epsilon=1e-08).minimize(loss)
saver = tf.compat.v1.train.Saver()


#  ----- Main Session -----  #
with tf.compat.v1.Session() as sess:
    batch_size=1
    r_mat=[]
    foldname = '/folder_' + dt_name
    saver.restore(sess, cur_path + foldname + "/model.ckpt")
    res_mat = []
    for iter_t in range(len(list_id)):
        id=list_id[iter_t]
        print(id)
        in_ma = load_mat(id)
        pre_vec = sess.run(h_fc_2, feed_dict={input_matrix: in_ma })
        res_mat.append(pre_vec[0])
    np.savetxt('pred_'+name+'.txt',res_mat)
    print ('pred_'+name+'.txt'+' is saved')



