# for network controllability robustness prediction training

import tensorflow as tf
import numpy as np
import os
import random
import scipy.io as sio
import sys


dic={'ba':0,'er':1,'qs':2,'sw':3}  # classification labels, unclassifiable -> 'any' (aka 'all' in the paper)

mat=sio.loadmat('matdata/net_and_label.mat')
num_train_ins=len(mat['train'])
num_valid_ins=len(mat['test'])
cur_path=os.getcwd()
sf_list=random.sample(range(0,num_train_ins),num_train_ins)

def load_batch(batch_size,begin_index):
    A=[]
    y=[]
    for i in range(batch_size):
        tmpA=mat['train'][sf_list[i+begin_index],0]['A'][0,0].todense()
        tmpy=mat['train'][sf_list[i+begin_index],0]['net'][0]
        t_score=4*[0]
        t_score[dic[tmpy[0][0]]]=1
        A.append(np.expand_dims(tmpA,axis=2))
        y.append(t_score)
    return A,y

def load_batch_test(batch_size,begin_index):
    A=[]
    y=[]
    for i in range(batch_size):
        tmpA=mat['test'][i+begin_index,0]['A'][0,0].todense()
        tmpy=mat['test'][i+begin_index,0]['net'][0]
        t_score=4*[0]
        t_score[dic[tmpy[0][0]]]=1
        A.append(np.expand_dims(tmpA,axis=2))
        y.append(t_score)
    return A,y

# define functions
def Weight_variable(shape):
    initial=tf.random.truncated_normal(shape,stddev=0.05)
    return tf.Variable(initial)


def Bais_variable(shape):
    initial=tf.constant(0.0,shape=shape)
    return tf.Variable(initial)


def max_pool_2(x):
    return tf.nn.max_pool2d(x,[1,2,2,1],[1,2,2,1],'SAME')


def conv2d_stride1(x,W):
    return tf.nn.conv2d(x,W,strides=[1,1,1,1],padding='SAME')


# define CNN
class cnn_for_robustness():
    def __init__(self):
        # layer1
        self.w_conv1_1=Weight_variable([7,7,1,64])
        self.b_conv1_1=Bais_variable([64])
        # layer2
        self.w_conv2_1=Weight_variable([5,5,64,64])
        self.b_conv2_1=Bais_variable([64])
        # layer3
        self.w_conv3_1=Weight_variable([3,3,64,128])
        self.b_conv3_1=Bais_variable([128])
        # layer4
        self.w_conv4_1=Weight_variable([3,3,128,128])
        self.b_conv4_1=Bais_variable([128])
        # layer5
        self.w_conv5_1=Weight_variable([3,3,128,256])
        self.b_conv5_1=Bais_variable([256])
        # layer6
        self.w_conv6_1=Weight_variable([3,3,256,256])
        self.b_conv6_1=Bais_variable([256])
        # layer7
        self.w_conv7_1=Weight_variable([3,3,256,512])
        self.b_conv7_1=Bais_variable([512])
        self.w_conv7_2=Weight_variable([3,3,512,512])
        self.b_conv7_2=Bais_variable([512])
    def compu_conv(self,input_ma):
        # layer1
        h_conv1_1=tf.nn.relu(conv2d_stride1(input_ma,self.w_conv1_1)+self.b_conv1_1)
        out_layer1=max_pool_2(h_conv1_1)
        # layer2
        h_conv2_1=tf.nn.relu(conv2d_stride1(out_layer1,self.w_conv2_1)+self.b_conv2_1)
        out_layer2=max_pool_2(h_conv2_1)
        # layer3
        h_conv3_1=tf.nn.relu(conv2d_stride1(out_layer2,self.w_conv3_1)+self.b_conv3_1)
        out_layer3=max_pool_2(h_conv3_1)
        # layer4
        h_conv4_1=tf.nn.relu(conv2d_stride1(out_layer3,self.w_conv4_1)+self.b_conv4_1)
        out_layer4=max_pool_2(h_conv4_1)
        # layer5
        h_conv5_1=tf.nn.relu(conv2d_stride1(out_layer4,self.w_conv5_1)+self.b_conv5_1)
        out_layer5=max_pool_2(h_conv5_1)
        # layer6
        h_conv6_1=tf.nn.relu(conv2d_stride1(out_layer5,self.w_conv6_1)+self.b_conv6_1)
        out_layer6=max_pool_2(h_conv6_1)
        # layer7
        h_conv7_1=tf.nn.relu(conv2d_stride1(out_layer6,self.w_conv7_1)+self.b_conv7_1)
        h_conv7_2=tf.nn.relu(conv2d_stride1(h_conv7_1,self.w_conv7_2)+self.b_conv7_2)
        out_layer7=max_pool_2(h_conv7_2)
        return out_layer7

# construct CNN
in_matrix=tf.compat.v1.placeholder(tf.float32)
input_matrix=tf.reshape(in_matrix,[-1,1000,1000,1])
score=tf.compat.v1.placeholder(tf.int32)
network=cnn_for_robustness()
out_matr=network.compu_conv(input_matrix)

# get shape of output
shape=out_matr.get_shape()
length=shape[1].value*shape[2].value*shape[3].value
out_o=tf.reshape(out_matr,[-1,length])

# fc1  (fc=fully connected layers)
w_fc_1=Weight_variable([length,4096])
b_fc_1=Bais_variable([4096])
h_fc_1=tf.nn.relu(tf.matmul(out_o,w_fc_1)+b_fc_1)

# fc2
w_fc_2=Weight_variable([4096,999])
b_fc_2=Bais_variable([999])
h_fc_2=tf.nn.relu(tf.matmul(h_fc_1,w_fc_2)+b_fc_2)

#fc3
w_fc_3=Weight_variable([999,4])
b_fc_3=Bais_variable([4])
h_fc_3=tf.matmul(h_fc_2,w_fc_3)+b_fc_3

predictions=tf.argmax(h_fc_3,1)
actuals=tf.argmax(score,1)
accuracy=tf.reduce_mean(tf.cast(tf.equal(predictions,actuals),tf.float32))
# cross-entropy loss
loss=tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(labels=score,logits=h_fc_3))

# training setting
train_step=tf.compat.v1.train.AdamOptimizer(learning_rate=1e-4,beta1=0.9,beta2=0.999,epsilon=1e-08).minimize(loss)
saver=tf.compat.v1.train.Saver()


#  ----- Main Session -----  #
with tf.compat.v1.Session() as sess:
    sess.run(tf.compat.v1.global_variables_initializer()) # Initialization
    fdname='/class'
    batch_size=3
    epoch_val=10
    global_test_loss=float('inf')
    # train the CNN network. Record the parameters of the trained CNN models at the end of each epoch.
    training_loss=[]
    global_acc=0
    for epoc in range(epoch_val):
        for iter in range(num_train_ins//batch_size):
            inA,iny=load_batch(batch_size,iter*batch_size)
            train_step.run(feed_dict={input_matrix: inA,score: iny})
            if iter%100==0:
                loss_val=sess.run(loss,feed_dict={input_matrix: inA,score: iny})
                acc=sess.run(accuracy,feed_dict={input_matrix: inA,score: iny})
                print(' ..Epoch:('+str(epoc+1)+'),Iter:('+str(iter)+'),Loss Value:('+str(loss_val)+'),Accuracy:('+str(acc)+')')
        total_acc=[]
        for iter in range(num_valid_ins//batch_size):
            inA,iny=load_batch_test(batch_size,iter*batch_size)
            acc=sess.run(accuracy,feed_dict={input_matrix: inA,score: iny})
            total_acc.append(acc)
        mean_val=np.mean(total_acc)
        print(mean_val)
        if global_acc<mean_val:
            save_path=saver.save(sess,cur_path+fdname+'/model.ckpt')
            global_acc=mean_val
            print('Model Saved: '+str(save_path))





