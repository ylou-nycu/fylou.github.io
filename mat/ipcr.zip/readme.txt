-----  -----  -----  -----  -----  -----  -----  -----  -----  ----- 
Source Code for the paper: 
Y. Lou, Y. He, L. Wang, K.F. Tsang, and G. Chen,
"Knowledge-Based Prediction of Network Controllability Robustness,"
arXiv: 2003.08563
https://arxiv.org/abs/2003.08563
-----  -----  -----  -----  -----  -----  -----  -----  -----  -----

-----  -----  -----  -----  -----  -----  -----  -----  -----  ----- 
updated: 15 July 2020
programmer: Y. He (yaodonghe2-c@my.cityu.edu.hk) and Y. Lou (felix.lou@my.cityu.edu.hk)
-----  -----  -----  -----  -----  -----  -----  -----  -----  ----- 

-----  -----  -----  -----  -----  -----  -----  -----  -----  -----

1. Run "python ipcr_train_class.py" to train the classification model (CNNc).
   The trained model is saved in 'class'.

2. Run "python ipcr_train.py epoch_val batch_size model_name" to train the prediction (regression) models (CNNi).
   Default settings: epoch_val=10;  batch_size=3; default model_name=['any', 'ba', 'er', 'qs', 'sw']

3. Run "python run_models.py" to obtain testing results; the input data is in 'test.mat' file

-----  -----  -----  -----  -----  -----  -----  -----  -----  ----- 
[data]:
The training samples and the trained CNN models are available upon request by emailing to Y.Lou (felix.lou@my.cityu.edu.hk).

More network topologies and attack strategies are available in: https://fylou.github.io/sourcecode.html
-----  -----  -----  -----  -----  -----  -----  -----  -----  ----- 







