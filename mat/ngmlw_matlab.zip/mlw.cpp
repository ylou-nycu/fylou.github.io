// ===== * ===== * ===== * ===== * ===== * ===== * =====
// Source Code for the Article:
// Y.Lou, G.Chen, Z.Fan, and L.Xiang, "Local Communities Obstruct Global
// Consensus: Naming Game on Multi-local-world Networks", Physica A: 
// Statistical Mechanics and its Applications, 492: 1741�1752;
// doi:10.1016/j.physa.2017.11.094 (2018) 
// Programmer: Zhengping Fan (fanzhp@mail.sysu.edu.cn)
//           & Yang Lou      (felix.lou@my.cityu.edu.hk)
// ===== * ===== * ===== * ===== * ===== * ===== * =====
// mex mlw.cpp -DWINDOWS
// Use:  AdjacentMat = mlw(NetSize, #of_LWs, #Nodes_per_LW);
// E.g., A = mlw(200, 80, 2);
// ===== * ===== * ===== * ===== * ===== * ===== * =====
# include <cmath>
# include <cstdlib>
# include <cstdio>
# include <iomanip>
# include <ctime>
# include <mex.h>

unsigned long Seed = 10000000; 
unsigned long A = 48271L;           
unsigned long M = 2147483647L;
unsigned int  Q = 44488;
unsigned int  R = 3399;

const int ADD = 0;  /* IF ADD == 1, CONNET ALL LOCALS     */
                    /* ELSE ADD == 0, NO EXTRA CONNECTION */

double random_num_generator(void);
void mlw(int MAXVERT, int NLWs, int NpLW, int**AM);
            /* NetSize,  NLWs,  NpLW,  AdjacentMat */
            /* NOTE:  NetSize >= NLWs * NpLW   */

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    int NetSize;        /* The total number of nodes       	*/
    int NofLWs;         /* Number of Local Worlds           */
    int NofNode_pLW;    /* Number of nodes per Local World  */
    int **AM;           /* Result Adjacent Matrix           */
    double *outBuff;

    if ((nrhs != 3) || (nlhs < 1))
		mexErrMsgTxt ("Input 3 paras, e.g., A = mlw(NetSize, NLWs, NpLW); ...");
    NetSize = (int)*mxGetPr(prhs[0]);       /* Input Size of Network	*/
    NofLWs  = (int)*mxGetPr(prhs[1]);       /* Input # of Local Worlds  */
    NofNode_pLW = (int)*mxGetPr(prhs[2]);   /* Input # of initial Nodes per Local World */
    // OUTPUT MATRIX
    plhs[0] = mxCreateDoubleMatrix(NetSize, NetSize, mxREAL);   /* Output N*N Network */
    outBuff = mxGetPr(plhs[0]);
    AM = (int **)calloc(NetSize, sizeof(int *));
    for(int idx = 0; idx < NetSize; ++ idx)
        AM[idx] = (int*)calloc(NetSize, sizeof(int));
    // THE MLW FUNCTION FOR WULTI-LOCAL-WORLD NETWORK GENERATION
    mlw(NetSize, NofLWs, NofNode_pLW, AM);
    
    for(int idx = 1; idx <= NetSize; ++ idx)
        for(int jdx = 1; jdx <= NetSize; ++ jdx)
            outBuff[(idx-1)*NetSize + jdx-1] = double(AM[idx-1][jdx-1]);
// // ///////////////////////////////////////////////////////////////////////
// //     /* BELOW LINES ARE FOR TEST IF OUTBUFF == AM */
// //         ofstream f1;
// //         char s[3];
// // 		string s1 = "mat", s2 = ".txt", filename; 
// //         itoa(0, s, 10);
// //         filename = s1 + s + s2;
// // 		f1.open(filename.c_str());
// // 		if (!f1)
// // 		{
// // 			exit(1);
// // 		}
// // 		for (int idx = 0; idx < NetSize; ++ idx)
// // 		{
// // 		    for (int jdx = 0; jdx < NetSize; ++ jdx)
// // 		        f1 << *(*(AM + idx) + jdx) << ' ';
// // 		        f1 << '\n';
// // 		}
// //         printf("Matrix [%s] saved ... \n", filename.c_str());
// // 		f1.close();
// // ///////////////////////////////////////////////////////////////////////      
    for(int idx=0; idx<NetSize; ++idx)
        free(AM[idx]);
    free(AM);    
}   /* END OF MEXFUNCTION */


// THE CODE BELOW IS COMPOSED BY DR. Z.P. FAN (fanzhp@mail.sysu.edu.cn)
// FELIX MADE A FEW MODIFICATION, BUT DID NOT CHANGE THE ALGORITHM
void mlw(int MAXVERT, int NLWs, int NpLW, int**AM)
{
    int **edge; // adjacent matrix
    int *degree;
    int **Node;       
    int totlink=0;  
    int numvert;
    int numbwor;
    int *neigh;
    double *prob1, *prob2, *prob3, *prob4;            
    int **LW; 
    int **links_LW;
    double *prob5, *prob6;
    edge = (int**)calloc(MAXVERT, sizeof(int*));    
 //   for(int idx=0; idx<MAXVERT; ++idx)
 //       *(edge + idx) = (int*)calloc(MAXVERT, sizeof(int));
    degree = (int*)calloc(MAXVERT, sizeof(int));
    Node = (int**)calloc(MAXVERT, sizeof(int*));
    for(int idx=0; idx<MAXVERT; ++idx)
        *(Node + idx) = (int*)calloc(2, sizeof(int));
    neigh = (int*)calloc(MAXVERT, sizeof(int));
    prob1 = (double*)calloc(MAXVERT, sizeof(int));
    prob2 = (double*)calloc(MAXVERT, sizeof(int));
    prob3 = (double*)calloc(MAXVERT, sizeof(int));
    prob4 = (double*)calloc(MAXVERT, sizeof(int));
    prob5 = (double*)calloc(MAXVERT, sizeof(int));  
    prob6 = (double*)calloc(MAXVERT, sizeof(int));              
    LW = (int**)calloc(NLWs, sizeof(int*));
    links_LW =  (int**)calloc(NLWs, sizeof(int*));
    for(int idx=0; idx<NLWs; ++idx)
        *(links_LW + idx) = (int*)calloc(NLWs+1, sizeof(int));
    int m,m0,e0,i,j,k,l,n,nod1,nod2,node_label,temp_node,seltworld,seltnode,seltwor1,seltwor2;
	double pcw, pan,pal,pdl, pawl,Prob_Rand,sum,totconn;
    int link_label,allowed_link,counter_link,number_nodes,delink,coundelink,counter,numworlink,flag_node,positwor,added_number;

    // PARAMTERS IN: 
    // Z.Fan, G.Chen, and Y.Zhang. "A comprehensive multi-local-world model for complex networks."
    // Physics Letters A, 373(18): 1601-1605, 2009.
    double a,p,q,r,s,u;
    int m1=2, m2=2, m3=2, m4=2;
    a=0;
    p = 0;      //pcw;      //0
    q = 0.28;   //p + pan;	//0.19
    r = 0.11;   //q + pal;	//0.35
    s = 0.04;   //r + pdl;	//0.36
    u = 0.57;   //s + pawl;	//1.0
    // PARAMTERS AS IN THE MULTI-LOCAL-WORLD PAPER

    m = NLWs;
	m0 = NpLW;
	e0=m0*(m0-1)/2;
    
	for (i=0;i<NLWs;i++)
		links_LW[i][NLWs]=0;

	for (i=0;i<m;i++)
	{
		LW[i]=(int*)malloc(sizeof(int)*3);
	    for (j=0;j<3;j++)
			LW[i][j]=0; 
	}

	for (i=0;i<m;i++)
	{
		for (j=0;j<m0;j++) 
		{
			nod1=i*m0+j;  
			for(k=0;k<m0;k++)
			{
				nod2=i*m0+k; 
				if (nod1!=nod2) 
				{
					node_label=0;
					for (n=0;n<degree[nod1];n++)
					{
						temp_node=edge[nod1][n];
						if (temp_node==nod2)
						{
							node_label=1;
							break;
						}
					}
					if (node_label==0)
					{
						degree[nod1]++;
						degree[nod2]++;
					    if (degree[nod1]==1)
			                edge[nod1]=(int *)malloc(sizeof(int));
                        else
			                edge[nod1]=(int *) realloc(edge[nod1], sizeof(int) *degree[nod1]);
			    
			            edge[nod1][degree[nod1]-1]=nod2;

				        if (degree[nod2]==1)
			                edge[nod2]=(int *)malloc(sizeof(int));
                        else
			                edge[nod2]=(int *) realloc(edge[nod2], sizeof(int) *degree[nod2]);
			    
			            edge[nod2][degree[nod2]-1]=nod1;
					} 
				} 
			}
            
			LW[i][1]++; 
			LW[i]=(int *) realloc(LW[i], sizeof(int) *(LW[i][1]+3));
			LW[i][3+LW[i][1]-1]=nod1;
		}
		
		LW[i][0]=m0*(m0-1);
	}

	totlink=e0*m;
	numvert=m0*m;
	numbwor=m;

   //main loop
	while (numvert<MAXVERT) 
	{
		Prob_Rand=random_num_generator();

		if ((Prob_Rand<=p)&&(numvert<MAXVERT-m0))
		{	
	        LW[numbwor]=(int*)malloc(sizeof(int)*3);
        	for (j=0;j<3;j++)
		         LW[numbwor][j]=0; 

	        for (j=0;j<m0;j++)
			{
				nod1=numvert+j; 
		        for(k=0;k<m0;k++)
				{
					nod2=numvert+k; 
			        if (nod1<nod2) 
					{
						node_label=0;
				        for (n=0;n<degree[nod1];n++)
						{
							temp_node=edge[nod1][n];
					        if (temp_node==nod2)
							{
								node_label=1;						       
							}
						}
				        if (node_label==0)
						{
							degree[nod1]++;
					        degree[nod2]++;
					        if (degree[nod1]==1)
			                   edge[nod1]=(int *)malloc(sizeof(int));
                            else
								edge[nod1]=(int *) realloc(edge[nod1], sizeof(int) *degree[nod1]);
			    
			                edge[nod1][degree[nod1]-1]=nod2;

				            if (degree[nod2]==1)
			                    edge[nod2]=(int *)malloc(sizeof(int));
                            else
								edge[nod2]=(int *) realloc(edge[nod2], sizeof(int) *degree[nod2]);
			    
			                edge[nod2][degree[nod2]-1]=nod1;
						} 
					}
				} 
		
		        LW[numbwor][1]++;
		        LW[numbwor]=(int *) realloc(LW[numbwor], sizeof(int) *(LW[numbwor][1]+3));
		        LW[numbwor][3+LW[numbwor][1]-1]=nod1;
			}
		
	        //after all nodes have been counted. 
	        LW[numbwor][0]=m0*(m0-1);
	        numbwor++;
	        numvert+=m0;
	        totlink+=(m0*(m0-1)/2);
		}  
		 
	     if ((Prob_Rand>p)&(Prob_Rand<=q))
		 {
	         sum=0.0;
	         for(i=0;i<numbwor;i++)
			 {
				 prob3[i]=1.0/numbwor;
                 sum+=prob3[i];
	             prob2[i]=sum;
			 }
		         
	         if (numbwor==1)
		        seltworld=0;
	         else
			 {
				 Prob_Rand=random_num_generator();
		         if (Prob_Rand<=prob2[0])
			        seltworld=0;
		         else 
				 {
					 for (i=0;i<numbwor-1;i++) 
					 {
						 if ((Prob_Rand>prob2[i])&&(Prob_Rand<=prob2[i+1]))
						 {
							 seltworld=i+1;
						 }
					 }
				 }
			 }
	       
	         totconn=LW[seltworld][0]+a*LW[seltworld][1];
    
	         sum=0.0;
             for(i=0;i<LW[seltworld][1];i++)
			 {
				 node_label=LW[seltworld][4+i-1];
		         prob6[i]=(degree[node_label]+a)/totconn;
		         sum+=prob6[i];
		         prob5[i]=sum;
			 }
	
	         int added_node_number=0;
	         while(added_node_number<m1)
			 {
				 Prob_Rand=random_num_generator();
		         if ((Prob_Rand<=prob5[0])&&(Node[LW[seltworld][3]][1]==0))
			        seltnode=LW[seltworld][3];
		         else
				 {
					 for (i=0;i<LW[seltworld][1]-1;i++) 
					 {
						 if ((Prob_Rand>prob5[i])&&(Prob_Rand<=prob5[i+1])&&(Node[LW[seltworld][3+i+1]][1]==0)) // if the new i-th node links to node j+1.
						 {
							 seltnode=LW[seltworld][3+i+1];						
						 }
					 }
				 }

	             if (Node[seltnode][1]==0)
				 {
					 Node[seltnode][1]=1;
		             degree[seltnode]++;
		             degree[numvert]++; 
		             added_node_number++;
	             	
	            	if (degree[seltnode]==1)
		                edge[seltnode]=(int *)malloc(sizeof(int));
                     else
						 edge[seltnode]=(int *) realloc(edge[seltnode], sizeof(int) *degree[seltnode]);
			    
		             edge[seltnode][degree[seltnode]-1]=numvert;
            
		            if (degree[numvert]==1)
		               edge[numvert]=(int *)malloc(sizeof(int));
                    else
						edge[numvert]=(int *) realloc(edge[numvert], sizeof(int) *degree[numvert]);
			    
		            edge[numvert][degree[numvert]-1]=seltnode;
				 } 

			 } 		
	        
	        totlink+=m1;
	        LW[seltworld][0]+=(2*m1);
	        LW[seltworld][1]++;
	        LW[seltworld]=(int *)realloc(LW[seltworld],sizeof(int)*(LW[seltworld][1]+3));
            LW[seltworld][3+LW[seltworld][1]-1]=numvert;
	        numvert++;
	        for (i=0;i<LW[seltworld][1]-1;i++)
			{
				node_label=LW[seltworld][4+i-1];
		        if (Node[node_label][1]==1)
		            Node[node_label][1]=0;
			}
        }	
	
		if ((Prob_Rand>q)&(Prob_Rand<=r))
		{
        	sum=0.0;
	        for(i=0;i<numbwor;i++)
			{
				prob3[i]=1.0/numbwor;
                sum+=prob3[i];
	            prob2[i]=sum;
			}			
			
	        if (numbwor==1)
		       seltworld=0;
	        else
			{
		        Prob_Rand=random_num_generator();
		        if (Prob_Rand<=prob2[0])
			       seltworld=0;
		        else 
				{
					for (i=0;i<numbwor-1;i++) 
					{
						if ((Prob_Rand>prob2[i])&&(Prob_Rand<=prob2[i+1]))
						{
							seltworld=i+1;					
						}
					}
				}
			}
			
			number_nodes=LW[seltworld][1];
	
	        allowed_link=number_nodes*(number_nodes-1)/2-(LW[seltworld][0]-links_LW[seltworld][NLWs])/2; 
		 
	        if (allowed_link==m2) 
			{
				counter_link=0;
		        for (i=0;i<number_nodes-1;i++)
				{
					nod1=LW[seltworld][4+i-1];
					for (j=i+1;j<number_nodes;j++)
					{
						link_label=0;
				        nod2=LW[seltworld][4+j-1];
				        for (k=0;k<degree[nod1];k++)
						{
							temp_node=edge[nod1][k]; 

					        if (temp_node==nod2)
							{
								link_label=1; 		
							}
						}
				        if (link_label==0) 
						{                 
					        counter_link++;					
				        	degree[nod1]++;
				            degree[nod2]++;
				            totlink++;
					        LW[seltworld][0]+=2;

				            if (degree[nod1]==1)
			                    edge[nod1]=(int *)malloc(sizeof(int));
                            else
			                    edge[nod1]=(int *) realloc(edge[nod1], sizeof(int) *degree[nod1]);
			    
			                edge[nod1][degree[nod1]-1]=nod2;

				             if (degree[nod2]==1)
			                     edge[nod2]=(int *)malloc(sizeof(int));
                             else
			                     edge[nod2]=(int *) realloc(edge[nod2], sizeof(int) *degree[nod2]);
			    
			                  edge[nod2][degree[nod2]-1]=nod1;
						}
					} 
				} 
			} 

           if (allowed_link>m2)	
		   {			 
	           sum=0.0;
	           for(i=0;i<number_nodes;i++)
			   {
				   prob3[i]=1.0/number_nodes;
                   sum=sum+prob3[i];
	               prob2[i]=sum;
			   }

 	          totconn=LW[seltworld][0]+number_nodes*a;
	           sum=0.0;
               for(i=0;i<number_nodes;i++)
			   {
				   nod1=LW[seltworld][4+i-1];
		           prob6[i]=(degree[nod1]+a)/totconn;
		           sum+=prob6[i];
		           prob5[i]=sum;
			   }
    
	          int added_link_number=0;
	          while (added_link_number<m2)
			  {	  				  
		          link_label=0;
		          Prob_Rand=random_num_generator();
		          if (Prob_Rand<=prob2[0])
			         nod1=LW[seltworld][3];
		          else 
				  {
					  for (i=0;i<number_nodes-1;i++) 
					  {
				          if ((Prob_Rand>prob2[i])&&(Prob_Rand<=prob2[i+1]))
						  {
							  nod1=LW[seltworld][3+i+1];					
						  }
					  }
				  }
		         Prob_Rand=random_num_generator();
		         if (Prob_Rand<=prob5[0])
			        nod2=LW[seltworld][3];
		         else 
				 {
					 for (i=0;i<number_nodes-1;i++)
					 {
						 if ((Prob_Rand>prob5[i])&&(Prob_Rand<=prob5[i+1]))
						 {
							 nod2=LW[seltworld][3+i+1];
						 }
					 }
				 }		
		        
	        	if (nod1!=nod2) //different nodes
				{					
		        	for (i=0;i<degree[nod2];i++)
					{
						temp_node=edge[nod2][i];
				        if (temp_node==nod1) 
						{
							link_label=1;					
						}
					}
			   
			        if (link_label==0) 
					{
						degree[nod1]++;
				        degree[nod2]++;
				        totlink++;
				        LW[seltworld][0]+=2;
				        if (degree[nod1]==1)
			               edge[nod1]=(int *)malloc(sizeof(int));
                        else
							edge[nod1]=(int *) realloc(edge[nod1], sizeof(int) *degree[nod1]);
			    
			            edge[nod1][degree[nod1]-1]=nod2;

				        if (degree[nod2]==1)
			               edge[nod2]=(int *)malloc(sizeof(int));
                        else
			               edge[nod2]=(int *) realloc(edge[nod2], sizeof(int) *degree[nod2]);
			    
			             edge[nod2][degree[nod2]-1]=nod1;

				        added_link_number++;
					}
				}       
		
			  } 

            }
		}
        
		if ((Prob_Rand>r)&(Prob_Rand<=s))
		{
	        sum=0.0;
	        for(i=0;i<numbwor;i++)
			{
				prob3[i]=1.0/numbwor;
                sum=sum+prob3[i];
	            prob2[i]=sum;
			}
	
            if (numbwor==1)
		      seltworld=0;
	        else
			{
			   Prob_Rand=random_num_generator();
		       if (Prob_Rand<=prob2[0])
			      seltworld=0;
		       else 
			   {
				   for (i=0;i<numbwor-1;i++) 
				   {
					   if ((Prob_Rand>prob2[i])&(Prob_Rand<=prob2[i+1]))
					   {
						   seltworld=i+1;					
					   }
				   }
			   }
			}
            
            number_nodes=LW[seltworld][1];
            counter=0;
		    for (i=0;i<number_nodes-1;i++)
			{
				nod1=LW[seltworld][4+i-1];
			    for (j=i+1;j<number_nodes;j++)
				{
					nod2=LW[seltworld][4+j-1];
			    	for (k=0;k<degree[nod1];k++)
					{
						temp_node=edge[nod1][k]; 

					if (temp_node==nod2)
					{
						counter++;
						break;
					}
				}
			}
		 }
         delink=counter; 
            
	    if (delink==m3)  
		{
			coundelink=0;

		    for (i=0;i<number_nodes-1;i++)
			{
				nod1=LW[seltworld][4+i-1];
			    for (j=i+1;j<number_nodes;j++)
				{
					nod2=LW[seltworld][4+j-1];
				    for (k=0;k<degree[nod1];k++)
					{
						temp_node=edge[nod1][k]; 

					    if (temp_node==nod2)
						{
							LW[seltworld][0]=LW[seltworld][0]-2;
					    	totlink--;
						    if (degree[nod1]==1)
							{
								degree[nod1]--; 
					            free (edge[nod1]);
							}

				             if(degree[nod1]>1) 
							 {					       
					             counter=0;
					             for (l=0;l<degree[nod1];l++)
								 {
									 temp_node=edge[nod1][l];
						             if (temp_node!=nod2)
									 {
										 neigh[counter]=temp_node;
							             counter++;
									 }
								 }
					 
					             degree[nod1]--;

					             free (edge[nod1]);
					             edge[nod1]=(int *)malloc(sizeof(int)*degree[nod1]);

					              for (l=0;l<degree[nod1];l++)
						              edge[nod1][l]=neigh[l];
							 } 
			    	    
						     if (degree[nod2]==1)
							 {
								 degree[nod2]--; 
					             free (edge[nod2]);
							 }

				             if(degree[nod2]>1) 
							 {					      
					             counter=0;
					             for (l=0;l<degree[nod2];l++)
								 {
									 temp_node=edge[nod2][l];
						             if (temp_node!=nod1)
									 {
										 neigh[counter]=temp_node;
							             counter++;
									 }
								 }
					 
					             degree[nod2]--;

					             free (edge[nod2]);
					             edge[nod2]=(int *)malloc(sizeof(int)*degree[nod2]);

					
					             for (l=0;l<degree[nod2];l++)
						             edge[nod2][l]=neigh[l];
							 } 

						     coundelink++;						 
						     break;
					
						} 
					} 
				}   
			} 
		}   
	
       if (delink>m3)
	   {		   
	       sum=0.0;
	       for(i=0;i<number_nodes;i++)
		   {
			   prob3[i]=1.0/number_nodes;
               sum=sum+prob3[i];
	           prob2[i]=sum;
		   }
	       
	       totconn=LW[seltworld][0]+number_nodes*a;

	       sum=0.0;
           for(i=0;i<number_nodes;i++)
		   {
			   nod1=LW[seltworld][4+i-1];
		       prob6[i]=1.0/(number_nodes-1)*(1-(degree[nod1]+a)/totconn);
		       sum+=prob6[i];
		       prob5[i]=sum;
		   }

	       coundelink=0;
	       while(coundelink<m3)
		   {
		       Prob_Rand=random_num_generator();
		       if (Prob_Rand<=prob2[0])
			       nod1=LW[seltworld][3];
		       else 
			   {
				   for (i=0;i<number_nodes-1;i++) 
				   {
					   if ((Prob_Rand>prob2[i])&&(Prob_Rand<=prob2[i+1]))
					   {
						   nod1=LW[seltworld][3+i+1];					
					   }
				   }
			   }		
    		   
	    	    Prob_Rand=random_num_generator();
		        if (Prob_Rand<=prob5[0])
			       nod2=LW[seltworld][3];
		        else 
				{
					for (i=0;i<number_nodes-1;i++)
					{
						if ((Prob_Rand>prob5[i])&&(Prob_Rand<=prob5[i+1]))
						{
							nod2=LW[seltworld][3+i+1];
						}
					}
				}
                
			    if (nod1!=nod2)
				{	
					for (i=0;i<degree[nod2];i++)
					{
						temp_node=edge[nod2][i];

				    	if (temp_node==nod1) 
						{
							coundelink++;
						    totlink--;
						    LW[seltworld][0]= LW[seltworld][0]-2;
						    if (degree[nod1]==1)
							{
								degree[nod1]--; 
					            free (edge[nod1]);
							}

				            if(degree[nod1]>1) 
							{					 
					            counter=0;
					            for (l=0;l<degree[nod1];l++)
								{
									temp_node=edge[nod1][l];
						            if (temp_node!=nod2)
									{
										neigh[counter]=temp_node;
							            counter++;
									}
								}
					 
					            degree[nod1]--;

					            free (edge[nod1]);
					            edge[nod1]=(int *)malloc(sizeof(int)*degree[nod1]);

					
					            for (l=0;l<degree[nod1];l++)
						            edge[nod1][l]=neigh[l];
							} 						 

						    if (degree[nod2]==1)
							{
								degree[nod2]--; 
					            free (edge[nod2]);
							}

				            if(degree[nod2]>1)
							{					       
					            counter=0;
					            for (l=0;l<degree[nod2];l++)
								{
									temp_node=edge[nod2][l];
						            if (temp_node!=nod1)
									{
										neigh[counter]=temp_node;
							            counter++;
									}
								}
					 
					            degree[nod2]--;

					            free (edge[nod2]);
					            edge[nod2]=(int *)malloc(sizeof(int)*degree[nod2]);

					
					             for (l=0;l<degree[nod2];l++)
						             edge[nod2][l]=neigh[l];
							} 
						} 
					}
				}

			  }   
    

			} 
		}
        
		if ((Prob_Rand>s)&(Prob_Rand<=u))
		{
	        sum=0.0;
	        for(i=0;i<numbwor;i++)
			{
				prob3[i]=1.0/numbwor;
                sum=sum+prob3[i];
	            prob2[i]=sum;
			}
			
			if (numbwor==2) 
			{
				numworlink=0;

		        seltwor1=0;
		        seltwor2=1;

                while (numworlink<m4)
				{							
			       if (seltwor1!=seltwor2)
				   {
					   number_nodes=LW[seltwor1][1];
		               totconn=LW[seltwor1][0]+number_nodes*a;

	                    sum=0.0;
                        for(i=0;i<number_nodes;i++)
						{
							nod1=LW[seltwor1][4+i-1];
		                    prob6[i]=(degree[nod1]+a)/totconn;
		                    sum+=prob6[i];
		                    prob5[i]=sum;
						}
       
		                Prob_Rand=random_num_generator();
		                if (Prob_Rand<=prob5[0])
			                nod1=LW[seltwor1][3];
		                else 
						{
							for (i=0;i<number_nodes-1;i++)
							{
								if ((Prob_Rand>prob5[i])&&(Prob_Rand<=prob5[i+1]))
								{
									nod1=LW[seltwor1][3+i+1];
								}
							}
						}

				       number_nodes=LW[seltwor2][1];
		                totconn=LW[seltwor2][0]+number_nodes*a;

	                    sum=0.0;
                        for(i=0;i<number_nodes;i++)
						{
							nod2=LW[seltwor2][4+i-1];
		                    prob6[i]=(degree[nod2]+a)/totconn;
		                    sum+=prob6[i];
		                    prob5[i]=sum;
						}
       
						Prob_Rand=random_num_generator();
		                if (Prob_Rand<=prob5[0])
			               nod2=LW[seltwor2][3];
		                else 
						{
							for (i=0;i<number_nodes-1;i++)
							{
								if ((Prob_Rand>prob5[i])&&(Prob_Rand<=prob5[i+1]))
								{
									nod2=LW[seltwor2][3+i+1];
								}
							}
						}

				      link_label=0;
				 
		              for (i=0;i<degree[nod2];i++)
					 {
							  temp_node=edge[nod2][i];
				              if (temp_node==nod1)
							  {
								  link_label=1;
							  }
					  }
			              
			              if (link_label==0) 
						  {
							  degree[nod1]++;
				              degree[nod2]++;
				              totlink++;
				              LW[seltwor1][0]++;
					          LW[seltwor2][0]++;
					        
					          links_LW[seltwor1][NLWs]++; 
					  
					          links_LW[seltwor2][NLWs]++;
					          links_LW[seltwor1][seltwor2]++; 
					          links_LW[seltwor2][seltwor1]++;


				               if (degree[nod1]==1)
			                       edge[nod1]=(int *)malloc(sizeof(int));
                               else
			                       edge[nod1]=(int *) realloc(edge[nod1], sizeof(int) *degree[nod1]);
			    
			                    edge[nod1][degree[nod1]-1]=nod2;

				                if (degree[nod2]==1)
			                        edge[nod2]=(int *)malloc(sizeof(int));
                                else
			                        edge[nod2]=(int *) realloc(edge[nod2], sizeof(int) *degree[nod2]);
			    
			                    edge[nod2][degree[nod2]-1]=nod1;

				                numworlink++;
						  }					  
	        
				   } 
				}
			 } 
            
            if (numbwor>2)
			 {
				 numworlink=0;
                 while (numworlink<m4)
				 {
					 	   
	 	             Prob_Rand=random_num_generator();
		             if (Prob_Rand<=prob2[0])
		    	        seltwor1=0;
		             else 
					 {
						 for (i=0;i<numbwor-1;i++)
						 {
							 if ((Prob_Rand>prob2[i])&&(Prob_Rand<=prob2[i+1]))
							 {
								 seltwor1=i+1;
							 }
						 }
					 }
			
			         Prob_Rand=random_num_generator();
	             	 if (Prob_Rand<=prob2[0])
			             seltwor2=0;
		             else 
					 {
						 for (i=0;i<numbwor-1;i++) 
						 {
							 if ((Prob_Rand>prob2[i])&&(Prob_Rand<=prob2[i+1]))
							 {
								 seltwor2=i+1;
							 }
						 }
					 }

			        if (seltwor1!=seltwor2)
					{						
						number_nodes=LW[seltwor1][1];
		                totconn=LW[seltwor1][0]+number_nodes*a;

	                    sum=0.0;
                        for(i=0;i<number_nodes;i++)
						{
							nod1=LW[seltwor1][4+i-1];
		                    prob6[i]=(degree[nod1]+a)/totconn;
		                    sum+=prob6[i];
		                    prob5[i]=sum;
						}
       		               
		                Prob_Rand=random_num_generator();
		                if (Prob_Rand<=prob5[0])
			               nod1=LW[seltwor1][3];
		                else 
						{
							for (i=0;i<number_nodes-1;i++)
							{
								if ((Prob_Rand>prob5[i])&&(Prob_Rand<=prob5[i+1]))
								{
									nod1=LW[seltwor1][3+i+1];
								}
							}
						}

	                    number_nodes=LW[seltwor2][1];
		                totconn=LW[seltwor2][0]+number_nodes*a;

	                    sum=0.0;
                        for(i=0;i<number_nodes;i++)
						{
							nod2=LW[seltwor2][4+i-1];
		                    prob6[i]=(degree[nod2]+a)/totconn;
		                    sum+=prob6[i];
		                    prob5[i]=sum;
						}
       
		               Prob_Rand=random_num_generator();
		               if (Prob_Rand<=prob5[0])
			              nod2=LW[seltwor2][3];
		               else 
					   {
						   for (i=0;i<number_nodes-1;i++)
						   {
							   if ((Prob_Rand>prob5[i])&&(Prob_Rand<=prob5[i+1]))
							   {
								   nod2=LW[seltwor2][3+i+1];
							   }
						   }
					   }
                       
                       link_label=0;
					   for (i=0;i<degree[nod2];i++)
					   {
						   temp_node=edge[nod2][i];
				           if (temp_node==nod1) 	  
							   link_label=1;						   
					   }
			        
			           if (link_label==0) 
					   {
						   degree[nod1]++;
				           degree[nod2]++;
				           totlink++;
				           LW[seltwor1][0]++;
					       LW[seltwor2][0]++;

					        links_LW[seltwor1][NLWs]++;
					        links_LW[seltwor2][NLWs]++;
					        links_LW[seltwor1][seltwor2]++;
					        links_LW[seltwor2][seltwor1]++;


				            if (degree[nod1]==1)
			                   edge[nod1]=(int *)malloc(sizeof(int));
                            else
			                   edge[nod1]=(int *) realloc(edge[nod1], sizeof(int) *degree[nod1]);
			    
			                 edge[nod1][degree[nod1]-1]=nod2;

				             if (degree[nod2]==1)
			                    edge[nod2]=(int *)malloc(sizeof(int));
                             else
			                    edge[nod2]=(int *) realloc(edge[nod2], sizeof(int) *degree[nod2]);
			    
			                 edge[nod2][degree[nod2]-1]=nod1;

				             numworlink++;
					   }
			
					 } 
				}
			 } 	
		}		
	}

    for (i=0;i<MAXVERT;i++)
	{		
		if (degree[i]==0)
		{
			flag_node=0;
			for (j=0;j<numbwor;j++)
			{
				number_nodes=LW[j][1];
				for (k=0;k<number_nodes;k++)
				{
					nod1=LW[j][3+k];
					if (nod1==i)
					{
						flag_node=1;
						positwor=j;
					}
				}
			}
		
            number_nodes=LW[positwor][1];
        	sum=0.0;
	        for(j=0;j<number_nodes;j++)
			{
				prob1[j]=1.0/number_nodes;
                sum=sum+prob1[j];
	            prob4[j]=sum;
			}

            added_number=0;
			while(added_number<1) 
			{
				Prob_Rand=random_num_generator();
				if ((Prob_Rand<=prob4[0])&&(i!=LW[positwor][3]))
				{
					seltnode=LW[positwor][3];
					added_number++;
				}
	    	    else
				{
					for (j=0;j<LW[positwor][1]-1;j++) 
					{
						if ((Prob_Rand>prob4[j])&&(Prob_Rand<=prob4[j+1])&&(i!=LW[positwor][3+j+1])) // if the new i-th node links to node j+1.
						{
							seltnode=LW[positwor][3+j+1];
							added_number++;
						}
					}
				}
			}

		   degree[seltnode]++;
	       degree[i]++; 
	       totlink++;
		   LW[positwor][0]+=2;

		   if (degree[seltnode]==1)
		      edge[seltnode]=(int *)malloc(sizeof(int));
           else
			  edge[seltnode]=(int *) realloc(edge[seltnode], sizeof(int) *degree[seltnode]);
			    
		   edge[seltnode][degree[seltnode]-1]=i;            
		 
		   edge[i]=(int *)malloc(sizeof(int));
           edge[i][degree[i]-1]=seltnode;
		} 

	}

// ==== ==== To record the adjacent matrix in 0-1 form (Felix's Modification) ==== ==== //

    for (int idx = 0; idx < MAXVERT; ++ idx)
		{
		    for (int jdx = 0; jdx < degree[idx]; ++ jdx)
		        *(*(AM + idx) + (*(*(edge + idx) + jdx))) = 1;
	    }
	    
	    if (ADD == 1)
	    {
	        for (int idx = 1; idx < NLWs; ++ idx)
	        {
	            *(*(AM + NpLW * idx - 1) + NpLW * idx) = 1;
	            *(*(AM + NpLW* idx) + NpLW * idx - 1) = 1;
	        }
	    }
/////////////////////////////////////////////////////////////////////////
//////		ofstream f1;
////////		f1.open("mlw\\adj_mat.txt");
//////        char s[3];
//////		string s1 = "mlw\\mat", s2 = ".txt", filename;
//////        itoa(rept, s, 10);
//////        filename = s1 + s + s2;   
//////		f1.open(filename.c_str());
//////		if (!f1)
//////		{
//////			exit(1);
//////		}
//////		for (int idx = 0; idx < MAXVERT; ++ idx)
//////		{
//////		    for (int jdx = 0; jdx < MAXVERT; ++ jdx)
//////		        f1 << *(*(AM + idx) + jdx) << ' ';
//////		        f1 << '\n';
//////		}
//////        printf("Matrix [%s] saved ... \n", filename.c_str());
//////		f1.close();
/////////////////////////////////////////////////////////////////////////

    for(int idx=0; idx<MAXVERT; ++idx)
    {
        free(edge[idx]);
        free(Node[idx]);
        //free(AM[idx]);
    }
    for(int idx=0; idx<NLWs; ++idx)
    {
        free(LW[idx]);
        free(links_LW[idx]);
    }

    free(Node);
    free(degree);
    free(edge);
    free(neigh);
    free(prob1);
    free(prob2);
    free(prob3);
    free(prob4);
    free(prob5);  
    free(prob6);

    free(LW);
    free(links_LW);
    //free(AM);

}

double random_num_generator(void)
{
	long TmpSeed;
//	TmpSeed=A*(Seed % Q)-R*(Seed /Q);
	TmpSeed=A*(Seed % Q)-R*(Seed /Q) + rand();

	if (TmpSeed>=0)
		Seed=TmpSeed;
	else
		Seed=TmpSeed+M;

	return (double)Seed/M;

}