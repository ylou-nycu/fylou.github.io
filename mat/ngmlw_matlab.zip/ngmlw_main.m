% ===== * ===== * ===== * ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====
% Source Code for the Article:
%   Y.Lou, G.Chen, Z.Fan, and L.Xiang, "Local Communities Obstruct Global
%   Consensus: Naming Game on Multi-local-world Networks", Physica A: 
%   Statistical Mechanics and its Applications, 492: 1741�1752;
%   doi:10.1016/j.physa.2017.11.094 (2018) 
% https://doi.org/10.1016/j.physa.2017.11.094
% Programmer:	Felix Y.Lou 
% Webpage:      http://www.ee.cityu.edu.hk/~ylou/
% Email:        felix.lou@my.cityu.edu.hk
% ===== * ===== * ===== * ===== * ===== * ===== * =====
% Code Last Updated: 06/08/2018
% ===== * ===== * ===== * ===== * ===== * ===== * =====
% GENERAL NAMING GAME VERSION:
%	1. USING CELL TO STORE WORDS, SLOW AND ACCURATE
%   2. 1-3{RG}, 4-9{SW}, 10-12{SF}, 20{MLW}, 100{Fully-Connected}
%   3. LOOPS DESIGNED FOR MLW PARAS
% ===== * ===== * ===== * ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====
% % Copyright (c) 2018 Yang Lou, Guanrong Chen, Zhengping Fan, and Luna Xiang. 
% % All rights reserved.
% % 
% % Redistribution and use in source and binary forms, with or without
% % modification, are permitted provided that the following conditions
% % are met: 
% % 
% % 1. Redistributions of source code must retain the above copyright
% %    notice, this list of conditions and the following disclaimer. 
% % 2. Redistributions in binary form must reproduce the above copyright
% %    notice, this list of conditions and the following disclaimer in
% %    the documentation and/or other materials provided with the 
% %    distribution.
% % 
% % This software is provided by the copyright holders and contributors
% % "as is" and any express or implied warranties, including, but not 
% % limited to, the implied warranties of merchantability and fitness
% % for a particular purpose are disclaimed. In no event shall the
% % copyright owner or contributors be liable for any direct, indirect,
% % incidental, special, exemplary, or consequential damages (including,
% % but not limited to, procurement of substitute goods or services;
% % loss of use, data, or profits; or business interruption) however
% % caused and on any theory of liability, whether in contract, strict
% % liability, or tort (including negligence or otherwise) arising in
% % any way out of the use of this software, even if advised of the
% % possibility of such damage.
% ===== * ===== * ===== * ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====

clear all;
close all;

global A;  % ADJACENCY MATRIX OF NETWORKS %

disp('Naming Game on Multi-Local-World ...');
disp('Input the following data: ')
REPT  = input('Number of Repeated Runs (eg 20): ');
N     = input('Population Size (eg 500): ');
npLW  = input(['Number of Nodes per Local-World (in [3,',int2str(N/10),'] eg 6): ']);
Nrate = input('Percentage of Nodes Initially Allocated in Local-Worlds (eg 0.7): ');
SaveA = input('Save Adjacent Matrix (Y/N)? ', 's');
disp('Default Speaker-Hearer Selection Strategy is ''Direct''.');

if(N < 1200), MAX_ITER = 1E6;
else MAX_ITER = 1E7;
end

% if strcmp(SaveA,'Y') || strcmp(SaveA,'y')
%     AdjMat = cell(REPT,1);
% end
INTERVAL = 100;
mlw_para.N  = N;
mlw_para.LN = npLW;
mlw_para.LW = floor(N*Nrate / mlw_para.LN);  % #of Local Worlds %

NET_TYPE = 20;  % ALL THE NETWORKS IN THE TEST %
% 1~3.RG/; 4~6.SW/; 7~9.SW/; 10~12.SF/; 20.MLW; 100.Fully-Connected.

SELECT_STR = 'direct';  %% {'direct', 'inverse'} THE SPEAKER-HEARER PSELECTING STRATEGIES %
TEN = 10;
MAXN = N*10;  %% MAX # OF VOCABULARY, LARGE ENOUGH %
STORE_LENGTH = MAX_ITER / INTERVAL;

addpath('networks');

% INITIALIZING ... %
totalW	 = zeros(REPT,STORE_LENGTH);  %% #OF TOTAL NAMES
diffW    = zeros(REPT,STORE_LENGTH);  %% #OF DIFFERENT NAMES
sucRate	 = zeros(REPT,STORE_LENGTH);  %% #OF SUCCESS RATE
maxDiffW = zeros(REPT,1);              %% THE PEAK OF DIFFERENT_NAME CURVE
convTime = zeros(REPT,1);              %% #OF ITERATIONS TO REACH CONVERGENCE

for r = 1:REPT
    avg_degree      = 0;
    avg_path_length = 0;
    avg_cc          = 0;
    disp('-- -- -- -- -- -- -- -- -- -- ');
    [avg_degree, avg_path_length, avg_cc] = generating_network(NET_TYPE, avg_degree, avg_path_length, avg_cc, mlw_para);
    % SETTING INFORMATIONS SHOWN IN THE SCREEN %
    disp('-- -- -- -- -- -- -- -- -- -- ');
    disp('NAMING GAME ON MLW RUNNING ... ');
    disp(['REPEATED RUN TIME: ',  num2str(r), '/', num2str(REPT)]);
    disp(['POPULATION SIZE: ',    num2str(N)]);
    disp(['MAXIMUM ITERATION: ',  num2str(MAX_ITER)]);
    disp('-- -- -- -- -- -- -- -- -- -- ');

    node         = cell(N,1);   	% NODES IN THE NETWORK, INDIVIDUALS %
    lenW         = zeros(N,1);     % LENGTH OF (STORED) MEMORY PER NODE %
    is_consensus = zeros(N,1);     % FLAG TO INTICATE CONSENSUS %
    suc_cnt      = zeros(TEN,1);	% SUCCESS TIME COUNTER %

    %% NAMING GAME PROCESSING ... %
    cnt = 1;        % COUNTER FOR (REAL) ITERATION %
    smp_cnt = 0;    % COUNTER FOR (SAMPLED) ITERATION, IMAGE = REAL_ITER / INTERVAL %
    
    while cnt < MAX_ITER
        switch SELECT_STR
            case 'direct'  %% DEFAULT OPTION
                idx = randi(N);     % RANDOMLY SELECT A SPEAKER %
                neb_arr = find(A(idx,:) == 1);  	% NEB_ARR = "NEIGHTBOR_ARRAY", ONE ROW (IDX-TH ROW) AND N COLUMNS %
                if ~ isempty(neb_arr)
                    jdx = neb_arr(1,randi(length(neb_arr)));       % SELECT ONE HEARER FROM NEIGHBORS %
                else
                    error('Graph Not Connected ...');	% THIS IS IMPOSSIBLE, ONLY IF A BUG %
                end
            case 'inverse'
                jdx = randi(N);     % RANDOMLY SELECT A HEARER %
                neb_arr = find(A(jdx,:) == 1);  	% NEB_ARR = "NEIGHTBOR_ARRAY", ONE ROW (IDX-TH ROW) AND N COLUMNS %
                if ~ isempty(neb_arr)
                    idx = neb_arr(1,randi(length(neb_arr)));       % SELECT ONE SPEAKER FROM NEIGHBORS %
                else
                    error('Graph Not Connected ...');	% THIS IS IMPOSSIBLE, ONLY IF A BUG %
                end
        end
        % --- SPEAKER SENDS THE MESSAGE --- %
        if isempty(node{idx,1})         % IF SPEAKER HAS NOTHING IN MEMORY %
            message = randi(MAXN);
            node{idx,1} = message;
        else  % SPEAKER HAS MEMORY ALREADY %
            pos = randi(length(node{idx,1}));
            message = node{idx,1}(pos);
            lenW(idx,1) = 1;
        end % NODE(IDX) WILL SEND THE MESSAGE} %

        % --- HEARER RECEIVE THE MESSAGE --- %
        suc_cnt(2:TEN,1) = suc_cnt(1:(TEN-1),1);
        if isempty(node{jdx,1})	% IF HEARER HAS NOTHING IN MEMORY %
            % RECEIVED INFORMATION = {RULE_ID, MESSAGE} %
            node{jdx,1} = [message];	% LEARN THE FIRST MESSAGE %
            suc_cnt(1,1) = 0;
            lenW(jdx,1) = 1;
        else
            if isempty(find(node{jdx,1} == message,1))
                node{jdx,1} = [node{jdx,1},message];
                is_consensus(jdx,1) = 0;
                suc_cnt(1,1) = 0;
                lenW(jdx,1) = lenW(jdx,1) + 1;
            else  % CONSENSUS %
                is_consensus(idx,1) = 1;
                is_consensus(jdx,1) = 1;
                node{idx,1} = message;
                node{jdx,1} = message;
                suc_cnt(1,1) = 1;
                lenW(idx,1) = 1;
                lenW(jdx,1) = 1;
            end
        end
        
        %% == CALCULATE FEATURES == %
        if ~ mod(cnt - 1,INTERVAL)
            smp_cnt = smp_cnt + 1;      % THE SUBSCRIPT FOR RECORD %
            totalW(r,smp_cnt) = sum(lenW);
            diff_arr = [];
            for idx = 1:N
                diff_arr = [diff_arr,node{idx,1}];
            end
            diffW(r,smp_cnt) = length(unique(diff_arr));
            sucRate(r,smp_cnt) = sum(suc_cnt) / TEN;
            clear diff_arr;
        end
        % == END of CALCULATE FEATURES == %

        %% == TEST CONVERGENCE == %
        conv_flag = 1;
        if sum(is_consensus) ~= N   % IF NOT ALL CONSENSUS, NOT CONSENSUS %
            conv_flag = 0;
        else                        % "SUM(IS_CONSENSUS) == N", ALL CONSENSUS, BUT MAY BE DIFFERENT WORDS %
            for idx = 2:N
                if node{idx-1,1} ~= node{idx,1}
                    conv_flag = 0;
                    break;  % IF ALL %
                end
            end
        end
        if conv_flag == 1  % CONSENSUS OR CONVERGED %
            maxDiffW(r) = max(diffW(r,:));
            convTime(r) = cnt;
            totalW(r,smp_cnt+1:end)  = totalW(r,smp_cnt);
            diffW(r,smp_cnt+1:end)	 = diffW(r,smp_cnt);
            sucRate(r,smp_cnt+1:end) = sucRate(r,smp_cnt);
            break;  % END NAMING GAME %
        end
        % == END of TEST CONVERGENCE == %

        cnt = cnt + 1;
        if mod(cnt,10000) == 0
            disp(['Iteration No.: ',num2str(cnt)]);
        end
    end     % END 'while cnt <= MAX_ITER' %
    if conv_flag
        disp(['Converged Time: ',num2str(cnt)])
    else
        disp(['Not Converged within ',num2str(cnt),' Interarions ...'])
    end
    if strcmp(SaveA,'Y') || strcmp(SaveA,'y')
        filename = ['AdjMat_Run',int2str(r),'.mat'];
        save(filename,'A');
    end
    disp([' ']);

end     % END of REPEAT %

% == SAVE DATA == %
% Convergence Curves can be ploted by the data saved above %
filename = ['Pop',int2str(N),'_NpLW',num2str(npLW),'.mat'];
save (filename,'totalW','diffW','sucRate','maxDiffW','convTime','node',...  %% For Convergence Curves Plot
    'avg_degree','avg_path_length','avg_cc',...                                  %% Statistics of Networks
    'mlw_para','INTERVAL','SELECT_STR');
% rmpath('iteration');
% rmpath('networks');
