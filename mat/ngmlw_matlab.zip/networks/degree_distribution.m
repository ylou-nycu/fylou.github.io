function aver_DeD = degree_distribution (A)
% Input     A - adjacent matrix         %
% Output    DeD - degree distribution   %

N = size(A, 2);
DeD = zeros(1, N);
for i = 1 : N
   DeD(1, i) = sum(A(i,:));
end
aver_DeD = mean(DeD);

end



