function [SFNet, avg_deg, avg_pl, avg_cc, disc] = scale_free(Nodes, n_initial, m_link)

seed = ones(n_initial, n_initial);
pos = length(seed);
d_seed = diag(ones(1,pos),0);

seed = seed - d_seed;

rand('state',sum(100*clock));

Net = zeros(Nodes, Nodes, 'single');
Net(1:pos,1:pos) = seed;
sumlinks = sum(sum(Net));

while pos < Nodes
    pos = pos + 1;
    linkage = 0;
    while linkage ~= m_link
        rnode = ceil(rand * (pos-1));
        deg = sum(Net(:,rnode)) * 2;
        rlink = rand * 1;
        if rlink < deg / sumlinks && Net(pos,rnode) ~= 1 && Net(rnode,pos) ~= 1
            Net(pos,rnode) = 1;
            Net(rnode,pos) = 1;
            linkage = linkage + 1;
            sumlinks = sumlinks + 2;
        end
    end
end

SFNet = Net;

    disc = 0;
    for i = 1 : Nodes
        if sum(SFNet(i, :)) == 0
            disc = 1;
            break;
        end
    end    
    
    avg_deg = degree_distribution (SFNet);
    avg_pl = average_path_length (SFNet);
    avg_cc = clustering_coefficient (SFNet);
    
    
clear Nodes deg linkage pos rlink rnode sumlinks m_link