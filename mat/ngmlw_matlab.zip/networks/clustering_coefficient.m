function  aver_C = clustering_coefficient (A)

N = size(A, 2);
C = zeros(1, N);

for i = 1 : N
    neb = find (A(i, :)==1);     % find neighbors %
    % A is ensured being connected outside this function %
    % thus, size(neb) ~= 0 %
    m = length (neb); 
    
    if m == 1
        C(1, i) = 0;
    else
        B = A(neb, neb);
        C(1, i) = length(find(B == 1))/(m*(m-1));
    end
end
aver_C = mean(C);