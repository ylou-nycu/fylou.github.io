function [A, avg_deg, avg_pl, avg_cc, disc] = random_graph (number_of_node, connecting_probability, fig_or_not)

if nargin == 2
    fig_or_not = 0;     % default: do not draw the figure op network %
end    

% srtg_3. Compared with Uniformly-distributed Random Number, not requiring generating N*(N-1)/2*alph
N = number_of_node;
p = connecting_probability;
A = zeros(N, N);
disc = 0;

    if fig_or_not
        randData = rand(2, N) * 1000;
        x = randData(1, :);     % size_x = 1-by-N %
        y = randData(2, :);     % size_y = 1-by-N %
    end

    for i = 1 : (N-1)
        for j = (i+1) : N   % this is a bi-direction operation (?) was it Nchoose2 (?) %
            if rand <= p & A(i, j) == 0
                A(i, j) = 1; 
                A(j, i) = 1;
            end
        end
    end

    for i = 1 : N
        if sum(A(i, :)) == 0
            disc = 1;
            break;
        end
    end

     if fig_or_not
        plot(x, y, 'r.', 'Markersize', 18);
        hold on;
        for i = 1 : N 
            for j = i+1 : N
                if A(i,j) ~= 0
                    plot ([x(i),x(j)], [y(i),y(j)], 'linewidth', 1);        % connet x and y with line of linewidth 1 %
                    hold on;
                end
            end
        end
        hold off;
     end
     
     avg_deg	= degree_distribution (A);
     avg_pl     = average_path_length (A);
     avg_cc     = clustering_coefficient (A);

end

