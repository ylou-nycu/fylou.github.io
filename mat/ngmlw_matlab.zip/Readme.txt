% ===   ***** ***** ***** ***** ***** ***** ***** ***** ***** *****	  === %
% ===   Source Code for the Article:                                  === %
% ===   Y.Lou, G.Chen, Z.Fan, and L.Xiang, "Local Communities         === %
% ===   Obstruct Global Consensus: Naming Game on Multi-local-world   === %
% ===   Networks", Physica A: Statistical Mechanics and its           === %
% ===   Applications, 492: 1741�1752;                                 === %
% ===   doi:10.1016/j.physa.2017.11.094 (2018)                        === %
% ===   ***** ***** ***** ***** ***** ***** ***** ***** ***** *****	  === %
% ===   Programmer:	Felix Y.Lou (Felix.lou@my.cityu.edu.hk)           === %
% ===             & Z.Fan (Fanzhp@mail.sysu.edu.cn)                   === %
% ===   ***** ***** ***** ***** ***** ***** ***** ***** ***** *****	  === %
% Code Last Updated: 06/08/2018
% ===   ***** ***** ***** ***** ***** ***** ***** ***** ***** *****	  === %
% Copyright (c) 2018 Yang Lou, Guanrong Chen, Zhengping Fan,          === %
%                    and Luna Xiang.                                  === %
% All rights reserved.                                                === %
% ===   ***** ***** ***** ***** ***** ***** ***** ***** ***** *****	  === %
% Redistribution and use in source and binary forms, with or without  === %
% modification, are permitted provided that the following conditions  === %
% are met:                                                            === %
%                                                                     === %
% 1. Redistributions of source code must retain the above copyright   === %
%    notice, this list of conditions and the following disclaimer.    === %
% 2. Redistributions in binary form must reproduce the above copyright=== %
%    notice, this list of conditions and the following disclaimer in  === %
%    the documentation and/or other materials provided with the       === %
%    distribution.                                                    === %
%                                                                     === %
% This software is provided by the copyright holders and contributors === %
% "as is" and any express or implied warranties, including, but not   === %
% limited to, the implied warranties of merchantability and fitness   === %
% for a particular purpose are disclaimed. In no event shall the      === %
% copyright owner or contributors be liable for any direct, indirect, === %
% incidental, special, exemplary, or consequential damages (including,=== %
% but not limited to, procurement of substitute goods or services;    === %
% loss of use, data, or profits; or business interruption) however    === %
% caused and on any theory of liability, whether in contract, strict  === %
% liability, or tort (including negligence or otherwise) arising in   === %
% any way out of the use of this software, even if advised of the     === %
% possibility of such damage.                                         === %
% ===   ***** ***** ***** ***** ***** ***** ***** ***** ***** *****	  === %

RUN = 'ngmlw_main'

[AN EXAMPLE:]

--

>> ngmlw_main
Naming Game on Multi-Local-World ...
Input the following data: 
Number of Repeated Runs (eg 20):                                    2
Population Size (eg 500):                                           500
Number of Nodes per Local-World (in [3,PopSize) eg 6):              6
Percentage of Nodes Initially Allocated in Local-Worlds (eg 0.7):   0.3
Save Adjacent Matrix (Y/N)?                                         Y

Default Speaker-Hearer Selection Strategy is 'Direct'.

--

THEN, THE SCREEN WILL DISPLAY:

--

-- -- -- -- -- -- -- -- -- -- 
~ Multi-Local-World Network
# of Total Nodes = 500
# of Local-Worlds = 25
# of Nodes per Local-Worlds = 6
Graph Construced ...
-- -- -- -- -- -- -- -- -- -- 
NAMING GAME ON MLW RUNNING ... 
REPEATED RUN TIME: 1/2
POPULATION SIZE: 500
MAXIMUM ITERATION: 1000000
-- -- -- -- -- -- -- -- -- -- 
Iteration No.: 10000
Iteration No.: 20000
Iteration No.: 30000
Iteration No.: 40000
Iteration No.: 50000
Iteration No.: 60000
Iteration No.: 70000
Iteration No.: 80000
Iteration No.: 90000
Iteration No.: 100000
Iteration No.: 110000
Iteration No.: 120000
Iteration No.: 130000
Iteration No.: 140000
Iteration No.: 150000
Iteration No.: 160000
Iteration No.: 170000
Iteration No.: 180000
Converged Time: 187120
 
-- -- -- -- -- -- -- -- -- -- 
~ Multi-Local-World Network
# of Total Nodes = 500
# of Local-Worlds = 25
# of Nodes per Local-Worlds = 6
Graph Construced ...
-- -- -- -- -- -- -- -- -- -- 
NAMING GAME ON MLW RUNNING ... 
REPEATED RUN TIME: 2/2
POPULATION SIZE: 500
MAXIMUM ITERATION: 1000000
-- -- -- -- -- -- -- -- -- -- 
Iteration No.: 10000
Iteration No.: 20000
Iteration No.: 30000
Iteration No.: 40000
Iteration No.: 50000
Iteration No.: 60000
Iteration No.: 70000
Iteration No.: 80000
Iteration No.: 90000
Iteration No.: 100000
Iteration No.: 110000
Iteration No.: 120000
Iteration No.: 130000
Iteration No.: 140000
Iteration No.: 150000
Iteration No.: 160000
Converged Time: 169299

>>
--

AFTER EXECUTION, THE DATA WILL BE SAVED.

IN THIS EXAMPLE,

    1. "AdjMat_Run1.mat" - ADJACENT MATRIX OF THE 1ST RUN
    2. "AdjMat_Run2.mat" - ADJACENT MATRIX OF THE 2ND RUN
    ... (MORE IF ANY)

    3. "Pop500_NpLW6.mat" - DATA OF CONVERGENCE PROCESS

IF INPUT 'N' OR 'n' WHEN IT DISPLAYS "Save Adjacent Matrix (Y/N)?",
THE DATA "AdjMat_RunK.mat" (K = 1,2,...) WILL NOT BE SAVED.

