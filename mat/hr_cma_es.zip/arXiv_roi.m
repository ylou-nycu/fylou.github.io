% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% get solutions from a sub-tree (region of interest ROI)
% form a population and get the mean (seed) for CMA-ES
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% updated: 09-03-2019
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

function [xmean,subpop,pdx] = arXiv_roi(pos)
% input:    pos - the leaf node that reached the depth threshold
% output: xmean - the mean (seed) for CMA-ES
%        subpop - all leaf nodes unber [pdx]
%           pdx - root for the sub-tree
global arXiv;
global depth;

    subpop = [];
    s = [];
    idx = pos;
    for i=1:depth.k
        pdx = arXiv.px(1,idx);  idx = pdx;
    end  % idx == root of sub-tree
    idx = pdx;  % start from root of sub-tree
    while (arXiv.lx(1,idx)~= depth.leafmark) || (~isempty(s))  % (arXiv.rx(1,idx)>0) 
        while arXiv.lx(1,idx)~= depth.leafmark
            s = [s,idx];
            idx = arXiv.lx(1,idx);
            if arXiv.lx(1,idx)== depth.leafmark
                subpop = [subpop,idx];
            end
        end
        if ~isempty(s)
            idx = s(end);
            s(end) = [];
            idx = arXiv.rx(1,idx);
            if arXiv.lx(1,idx)== depth.leafmark
                subpop = [subpop,idx];
            end
        end
    end    
    if isempty(subpop);  error('none node found, check ... ');  end
    subpop = unique(subpop);
    % get the xmean of ROI (region of interest)
    xmean = mean(arXiv.x(:,subpop),2);
    arXiv.blk(1,pdx) = 1;  % the ENTIRE subtree below 'pdx' is blocked
    % Later (after running CMA-ES)
    % the info of node 'pdx' will change to: 
    % x  - best soution by CMA-ES
    % f  - best fitness by CMA-ES
    % d  - 0
    % min,max - do not change
    % px - do not change
    % lx - max_size+1
    % rx - max_size+1
    % blk == 1
    % dp  == dp_max
end

