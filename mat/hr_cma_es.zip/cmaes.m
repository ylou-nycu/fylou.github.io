% downloaded from http://cma.gforge.inria.fr/cmaes.m (02-10-2018)
%  1) a simplified version from '3.33.integer', removing the '.integer'
%  2) Running Mode:
%       2.1 flg_run_one_iter
%       2.2 flg_run_until_stop
%       2.3 flg_run_nfes
%  3) must input 'cma.iter'; 'cma.xmean'; 'cma.mode'.
%  4) clear 'out'
% update 09-03-2019
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

function [fmin,cma,flgstop] = cmaes(pSet,fn,N,bound,cma)
flgdisp = false;
flgresume = true;  %^--> flgresume = cma.flgresume;
    % ----- Parameters & Options -----  ----- %
    if(flgdisp);  disp(['CMA-ES solving Prob(',pSet,')-fn',int2str(fn),' ... ']);  end
    max_fes = min(cma.fes_remain,cma.fes_cmaes);
    xstart = cma.xmean;  
    lb = bound.lb;
    ub = bound.ub;
    STOP_CMA = false;
    flg_run_one_iter = strcmp(cma.mode,'one');  % 1)flg_run_one_iter; 2)flg_run_until_stop; 3)flg_run_nfes.
    DiffMaxChange = inf;	%'Inf  % maximal variable change(s), can be Nx1-vector
    DiffMinChange = 0;      %'0    % minimal variable change(s), can be Nx1-vector
    RecombinationWeights = 'sl';   % sl=superlinear; li=linear; eq=equal.
    nRestarts = 0;          % number of restarts
    IncPopSize = 2;         % multiplier for population size before each restart
    if exist('cma.lambda','var')
        PopSize = cma.lambda;
    else
        PopSize = 4+floor(3*log(N));
    end
    if exist('cma.sigma','var')
        insigma = cma.sigma;
    else
        insigma = 0.3*(max(ub-lb));
    end
    fes=0; fesNaN=0; irun=0;
    while irun <= nRestarts
        irun = irun+1;
        % ----- Initialization -----  ----- %
        lambda = floor(PopSize*IncPopSize^(irun-1));
        % ----- Evaluate Options -----  ----- %
        stopMaxFunEvals = max_fes;  % maximal number of fevals
        stopTolX   = 1e-11*max(insigma); % stop if x-change smaller TolX
        stopTolUpX = 1e3*max(insigma);	 % stop if x-changes larger TolUpX
        stopTolFun = 1e-12;         % stop if fun-changes smaller TolFun
        stopTolHistFun  = 1e-13;	% stop if back fun-changes smaller TolHistFun
        stopOnStagnation = true;	% stop when fitness stagnates for a long time
        stopOnWarnings   = true;	% ''no''==''off''==0, ''on''==''yes''==1
        flgWarnOnEqualFunctionValues = true; % ''no''==''off''==0, ''on''==''yes''==1
        flgEvalParallel  = true;    % objective function FUN accepts NxM matrix, with M>1?
        maxdx = DiffMaxChange;  % maximal sensible variable change
        mindx = DiffMinChange;  % minimal sensible variable change
        sigma = max(insigma);	% overall standard deviation
        xmean = mean(xstart,2);
        if flgresume && cma.iter % Resume From Former Run [!!!] TODO: from variable, NOT from file
            B = cma.B;              % (b)
            BD = cma.BD;            % (b1)
            bnd = cma.bnd;          % (b2)
            C = cma.C;              % (c)
            chiN = cma.chiN;        % (c1)
            diagC = cma.diagC;      % (d)
            diagD = cma.diagD;      % (d1)
            fitness = cma.fitness;  % (f)
            iter = cma.iter;        % (i)
            maxdx = cma.maxdx;      % (m)
            ps = cma.ps;            % (p1)
            pc = cma.pc;            % (p2)
            sigma = cma.sigma;      % (s)
            xmean = cma.xmean;      % (x1)
            xold = cma.xold;        % (x2)
        else  %% [NEW] NOT flgresume
            cma.fmin = inf;
            cma.reset = false;
            pc=zeros(N,1);  ps=zeros(N,1);	% evolution paths for C and sigma
            if length(insigma)==1;  insigma=insigma*ones(N,1);  end
            diagD = insigma/max(insigma);	% diagonal matrix D defines the scaling
            diagC = diagD.^2;
            B = eye(N,N);                   % B defines the coordinate system
            BD = B.*repmat(diagD',N,1);     % B*D for speed up only
            C = diag(diagC);                % covariance matrix == BD*(BD)'
            fitness.hist     =NaN*ones(1,10+ceil(3*10*N/lambda)); % history of fitness values
            fitness.histsel  =NaN*ones(1,10+ceil(3*10*N/lambda)); % history of fitness values
            fitness.histbest =[]; % history of fitness values
            bnd.isactive = any(lb>-Inf)||any(ub<Inf);  %% basically, always TRUE
            if bnd.isactive
                bnd.weights = zeros(N,1);  % weights for bound penalty
                idx = (lb>-Inf)|(ub<Inf);
                if length(idx)==1;  idx=idx*ones(N,1);  end
                bnd.isbounded = zeros(N,1);
                bnd.isbounded(idx) = 1;
                maxdx = min(maxdx,(ub-lb)/2);
                if any(sigma*sqrt(diagC)>maxdx)
                    fac = min(maxdx./sqrt(diagC))/sigma;
                    sigma = min(maxdx./sqrt(diagC));
                    warning(['Too large SIGMA, multiplied by ',num2str(fac)]);
                end
                idx = (lb>-Inf)&(ub<Inf);
                dd = diagC;
                if any(5*sigma*sqrt(dd(idx))<ub(idx)-lb(idx))
                    warning('See [checkpoint#25] (in older versions) ...');
                end
                bnd.dfithist = 1;       % delta fit for setting weights
                bnd.validfitval = 0;
                bnd.iniphase = 1;
            end
            fitness.hist(1)=NaN;
            fitness.histsel(1)=NaN;
            randn('state', sum(100*clock)); % rng('default');  rng('shuffle');
            chiN = N^0.5*(1-1/(4*N)+1/(21*N^2));  % expectation of ||N(0,I)|| == norm(randn(N,1))
            iter = 0;
        end %% else flgresume
        if cma.reset  % Resume from previous run: NO initialization, RESET only ...
            cma.reset = false;
            pc=zeros(N,1);  ps=zeros(N,1);	% evolution paths for C and sigma
            if length(insigma)==1;  insigma=insigma*ones(N,1);  end
            diagD = insigma/max(insigma);	% diagonal matrix D defines the scaling
            diagC = diagD.^2;
            B = eye(N,N);                   % B defines the coordinate system
            BD = B.*repmat(diagD',N,1);     % B*D for speed up only
            C = diag(diagC);                % covariance matrix == BD*(BD)'
            fitness.hist=NaN*ones(1,10+ceil(3*10*N/lambda)); % history of fitness values
            fitness.histsel=NaN*ones(1,10+ceil(3*10*N/lambda)); % history of fitness values
            fitness.histbest=[]; % history of fitness values
            fitness.hist(1)=NaN;
            fitness.histsel(1)=NaN;            
            chiN = N^0.5*(1-1/(4*N)+1/(21*N^2));  % expectation of ||N(0,I)|| == norm(randn(N,1))
        end
        % -----  -----  -----  -----  -----  -----  -----  -----  -----
        % ------------   Generation Loop     --------------------------
        % -----  -----  -----  -----  -----  -----  -----  -----  -----
        flgstop = {};
        while ~STOP_CMA
            %if ~iter
                % --- Strategy internal parameter setting: Selection ---
                mu = floor(lambda/2);
                switch RecombinationWeights
                    case {'equal';'eq'}
                        weights = ones(mu,1);  %% (mu_I,lambda)-CMA-ES
                    case {'linear';'li'}
                        weights = mu+0.5-(1:mu)';
                    case {'superlinear';'sl'}  %% use (lambda+1)/2 as fixed reference
                        weights = log(max(mu, lambda/2)+1/2)-log(1:mu)';  %% muXone array for weighted recombination
                    otherwise
                        error('Recombination weights error ... ');
                end
                mueff = sum(weights)^2/sum(weights.^2);  %% variance-effective size of mu % [constant]
                weights = weights/sum(weights);  %% normalize recombination weights array % [constant]
                if mueff==lambda
                    error('Combination of values for Lambda, Mu and RecombinationWeights is not reasonable ...')
                end
                cc = (4+mueff/N)/(N+4+2*mueff/N);   % time constant for cumulation for covariance matrix
                cs = (mueff+2)/(N+mueff+3);         % or cs = (mueff^0.5)/(N^0.5+mueff^0.5) % t-const for cumulation for step size control
                ccov1 = 2/((N+1.3)^2+mueff); % [constant]
                ccovmu = min(1-ccov1,2*(mueff-2+1/mueff)/((N+2)^2+2*mueff/2));  % [constant]
                if N>98 && iter==0
                    disp('Consider option DiagonalOnly for high-dimensional problems');
                end
                damps = 1+2*max(0,sqrt((mueff-1)/(N+1))-1)+cs;  % [constant]
            %end
            iter = iter+1;
            % Generate and evaluate lambda offspring
            arz = randn(N,lambda);
            if lambda<5
                l = floor(lambda/2);  % differentiate '1'(one) and 'l'(el)
                arz(:,1:l) = -arz(:,lambda:-1:lambda-l+1);
            end
            arint = zeros(N,lambda);  %% compute integer_mutation all at once
            if flgEvalParallel  %% Parallel Evaluation
                arx = repmat(xmean,1,lambda)+sigma*(BD*arz);  % Eq.(1)
                arx = arx+arint;
                arxvalid = arx;
                if bnd.isactive  %% check is out-of-boundaries
                    arxvalid = xintobounds(arxvalid,lb,ub);
                end
                fitness.raw = fit_eval(arxvalid,fn,pSet);
                fesNaN = fesNaN+sum(isnan(fitness.raw));
                fes = fes+sum(~isnan(fitness.raw));
            end
            % Following Probably NOT Happen ...
            fitness.raw(lambda+find(isnan(fitness.raw(1:0)))) = NaN;
            for k=find(isnan(fitness.raw))
                tries = flgEvalParallel;
                while isnan(fitness.raw(k))
                    if k<=lambda
                        if tries>0  % need to resample
                            arz(:,k)=randn(N,1);  % resample
                        end  % resample random vectors
                        arx(:,k)=xmean+sigma*(BD*arz(:,k))+arint(:,k);  % Eq.(1)
                    else  %% re-evaluation solution with index > lambda
                        arx(:,k)=arx(:,k-lambda)+(noiseEpsilon*sigma)*(BD*randn(N,1));
                    end
                    arxvalid(:,k) = arx(:,k);
                    if bnd.isactive
                        arxvalid(:,k)=xintobounds(arxvalid(:,k),lb,ub);
                    end
                    fitness.raw(k)=fit_eval(arxvalid(:,k),fn,pSet);
                    tries = tries+1;
                    if isnan(fitness.raw(k));  fesNaN = fesNaN+1;  end
                    if ~mod(tries,100);  warning([num2str(tries),' NaN fitness values at eval.',num2str(fes)]);  end
                end
                fes=fes+1;
            end
            fitness.sel = fitness.raw;
            if bnd.isactive  % ----- Handle Boundaries -----
                val = myprctile(fitness.raw,[25,75]);  %% Get delta fitness values
                val = (val(2)-val(1))/N/mean(diagC)/sigma^2;  %% more precise would be exp(mean(log(diagC)))
                if ~isfinite(val)
                    warning('Non-finite fitness range');
                    val = max(bnd.dfithist);
                elseif val==0  % happens if all points are out of bounds
                    val = min(bnd.dfithist(bnd.dfithist>0));  % seems not to make sense, given all solutions are out of bounds
                elseif bnd.validfitval==0  %% flag that first sensible val was found
                    bnd.dfithist=[];  bnd.validfitval=1;
                end
                % Store delta fitness values
                if length(bnd.dfithist) < 20+(3*N)/lambda
                    bnd.dfithist = [bnd.dfithist,val];
                else
                    bnd.dfithist = [bnd.dfithist(2:end),val];
                end
                [tx,ti] = xintobounds(xmean,lb,ub);
                if bnd.iniphase  %% Set initial weights
                    if any(ti)
                        bnd.weights(find(bnd.isbounded)) = 2.0002*median(bnd.dfithist);
                        dd = diagC;
                        idx = find(bnd.isbounded);
                        dd = dd(idx)/mean(dd); %  remove mean scaling
                        bnd.weights(idx) = bnd.weights(idx)./dd;
                        if (bnd.validfitval&&iter>2);  bnd.iniphase=0;  end
                    end
                end  %% Increase weights:
                if any(ti)  %% any coordinate of xmean out of bounds
                    tx = xmean-tx;  %% judge distance of xmean to boundary
                    idx = (ti~=0 & abs(tx)>3*max(1,sqrt(N)/mueff)*sigma*sqrt(diagC));
                    idx = idx&(sign(tx)==sign(xmean-xold));  %% only increase if xmean is moving away
                    if ~isempty(idx)  % increase: the factor became 1.2 instead of 1.1, because changed from max to min in version 3.33.integer
                        bnd.weights(idx) = 1.2^(min(1,mueff/10/N))*bnd.weights(idx);
                    end
                end  %% Assigned Penalized Fitness:
                bnd.arpenalty = bnd.weights'*(arxvalid-arx).^2;
                fitness.sel = fitness.raw + bnd.arpenalty;
            end  % End: Handle Boundaries
            % Sort by fitness
            [fitness.raw,fitness.idx] = sort(fitness.raw);
            [fitness.sel,fitness.idxsel] = sort(fitness.sel);
            fitness.hist(2:end) = fitness.hist(1:end-1);  % record short history of
            fitness.hist(1) = fitness.raw(1);             % best fitness values
            if length(fitness.histbest)<120+ceil(30*N/lambda)||(mod(iter,5)==0&&length(fitness.histbest)<2e4)  % 20 percent of 1e5 gen.
                fitness.histbest=[fitness.raw(1),fitness.histbest];  % best fitness values               
            else
                fitness.histbest(2:end)=fitness.histbest(1:end-1);
                fitness.histbest(1)=fitness.raw(1);  % best fitness values
            end
            fitness.histsel(2:end) = fitness.histsel(1:end-1); % record short history of
            fitness.histsel(1) = fitness.sel(1);               % best sel fitness values
            % Calculate new xmean, this is selection and recombination
            xold = xmean; % for speed up of Eq. (2) and (3)
            cmean = 1; % = 1/min(max((lambda-1*N)/2,1),N);  % == 1/kappa
            xmean = (1-cmean)*xold+cmean*arx(:,fitness.idxsel(1:mu))*weights;
            zmean = arz(:,fitness.idxsel(1:mu))*weights;  %==D^-1*B'*(xmean-xold)/sigma
            fmean = (mu==1)*fitness.sel(1)+(mu~=1)*NaN;
            % Cumulation: update evolution paths
            ps = (1-cs)*ps+sqrt(cs*(2-cs)*mueff)*(B*zmean);  % Eq. (4)
            hsig = sum(ps.^2)/(1-(1-cs)^(2*iter))/N < 2+4/(N+1);  % just simplified
            pc = (1-cc)*pc + hsig*(sqrt(cc*(2-cc)*mueff))*BD*zmean;  % Eq. (2)
            if ccov1+ccovmu > 0  % Eq.(3)  % original code, fastest alternative
                artmp = arx(:,fitness.idxsel(1:mu))-repmat(xold,1,mu);
                C = (1-ccov1-ccovmu+(1-hsig)*ccov1*cc*(2-cc))*C ... % regard old matrix
                     +ccov1*pc*pc'	...     % plus rank one update
                     +ccovmu        ...     % plus rank mu update
                     *sigma^-2*artmp*(repmat(weights,1,N).*artmp');  % see [Alternative Methods #1 & #2]
                diagC = diag(C);
            end
            sigma = sigma*exp(min(1,(norm(ps)/chiN-1)*cs/damps));  % Eq. (5)
            if (ccov1+ccovmu)>0 && mod(iter,1/(ccov1+ccovmu)/N/10)<1  %% Decomposition of C into B*diag(diagD.^2)*B'
                C=triu(C)+triu(C,1)'; % enforce symmetry to prevent complex numbers
                [B,tmp] = eig(C);     % eigen decomposition, B==normalized eigenvectors
                diagD = diag(tmp);
                if any(~isfinite(diagD))
                    clear idx; % prevents error under octave
                    error(['eig returns NON-FINITE eigenvalues, cond(C)=',num2str(cond(C))]);
                end
                if any(any(~isfinite(B)))
                    clear idx; % prevents error under octave
                    error(['eig returns NON-FINITE eigenvectors, cond(C)=',num2str(cond(C))]);
                end
                if min(diagD)<=0  % limit condition of C to 1e14 + 1
                    if stopOnWarnings
                        flgstop(end+1) = {'warnconditioncov'};
                    else
                        warning(['Iteration ',num2str(iter),': Eigenvalue (smaller) zero.']);
                        diagD(diagD<0)=0;
                        tmp = max(diagD)/1e14;
                        C = C+tmp*eye(N,N);
                        diagD = diagD+tmp*ones(N,1);
                    end
                end
                if max(diagD)>1e14*min(diagD)
                    if stopOnWarnings
                        flgstop(end+1) = {'warnconditioncov'};
                    else
                        warning(['Iteration ',num2str(iter),': condition of C at upper limit.']);
                        tmp = max(diagD)/1e14-min(diagD);
                        C = C + tmp*eye(N,N); diagD = diagD + tmp*ones(N,1);
                    end
                end
                diagD = sqrt(diagD);  % D contains standard deviations now
                BD = B.*repmat(diagD',N,1);  % O(n^2)
            end % if mod
            % Align/rescale order of magnitude of scales of sigma and C for nicer output not a very usual case
            if sigma>1e10*max(diagD) && sigma>8e14*max(insigma)
                fac = sigma;  % / max(diagD);
                sigma = sigma/fac;
                pc = fac*pc;
                diagD = fac*diagD;
                C = fac^2 *C;
                BD = B.*repmat(diagD',N,1); % O(n^2), but repmat might be inefficient todo?
                diagC = fac^2 *diagC;
            end
            % ----- Numerical Error Management -----
            if any(sigma*sqrt(diagC)>maxdx)  % Adjust maximal coordinate axis deviations
                sigma = min(maxdx./sqrt(diagC));
            end
            if any(sigma*sqrt(diagC)<mindx)  % Adjust minimal coordinate axis deviations
                sigma = max(mindx./sqrt(diagC))*exp(0.05+cs/damps);
            end
            if any(xmean==xmean+0.2*sigma*sqrt(diagC))  % Adjust too low coordinate axis deviations
                if stopOnWarnings
                    flgstop(end+1) = {'warnnoeffectcoord'};
                else
                    warning(['Iteration ',num2str(iter),': coordinate axis std deviation too low.'])
                    C = C+(ccov1+ccovmu)*diag(diagC.*(xmean==xmean+0.2*sigma*sqrt(diagC)));
                    sigma = sigma*exp(0.05+cs/damps);
                end
            end
            % Adjust step size in case of (numerical) precision problem
            flg = all(xmean==xmean+0.1*sigma*BD(:,1+floor(mod(iter,N))));
            if flg
                i = 1+floor(mod(iter,N));
                if stopOnWarnings
                    flgstop(end+1) = {'warnnoeffectaxis'};
                else
                    warning(['Iteration ',num2str(iter),': main axis standard deviation ',num2str(sigma*diagD(i)),' has no effect.']);
                    sigma = sigma*exp(0.2+cs/damps);
                end
            end
            % Adjust step size in case of equal function values (flat fitness)
            if fitness.sel(1) == fitness.sel(ceil(min(lambda,1.1+lambda*0.25)))  % just a hack
                if flgWarnOnEqualFunctionValues && stopOnWarnings
                    flgstop(end+1) = {'warnequalfunvals'};
                else
                    if flgWarnOnEqualFunctionValues
                        warning(['Iteration ' num2str(iter),': equal function values f=', ...
                                 num2str(fitness.sel(1)),' at maximal main axis sigma ',num2str(sigma*max(diagD))]);
                    end
                    sigma = sigma*exp(0.2+cs/damps);
                end
            end
            % Adjust step size in case of equal function values
            if iter>2 && myrange([fitness.hist fitness.sel(1)])==0
                if stopOnWarnings
                    flgstop(end+1)={'warnequalfunvalhist'};
                else
                    warning(['Iteration ',num2str(iter),': equal futness values in history at maximal main ',...
                             'axis sigma ',num2str(sigma*max(diagD))]);
                    sigma = sigma*exp(0.2+cs/damps);
                end
            end
            % ----- end numerical error management -----
            if fes>=stopMaxFunEvals;  flgstop(end+1)={'maxfunevals'};	end
            if all(sigma*(max(abs(pc),sqrt(diagC)))<stopTolX)
                flgstop(end+1)={'tolx'};
            end
            if any(sigma*sqrt(diagC)>stopTolUpX)
                flgstop(end+1)={'tolupx'};
            end
            if sigma*max(diagD)==0  % should never happen
                flgstop(end+1)={'bug'};
            end
            if iter>2 && myrange([fitness.sel fitness.hist])<=stopTolFun
                flgstop(end+1)={'tolfun'};
            end
            if iter>=length(fitness.hist) && myrange(fitness.hist)<=stopTolHistFun
                flgstop(end+1)={'tolhistfun'};
            end
            l=floor(length(fitness.histbest)/3);
            if stopOnStagnation && iter>N*(5+100/lambda)&& length(fitness.histbest)>100 && median(fitness.histbest(1:l))>=median(fitness.histbest(end-l:end))
                flgstop(end+1)={'stagnation'};
            end
            if flg_run_one_iter;  flgstop(end+1)={'run_one_iter'};  end
            cma.B = B;              % (b)
            cma.BD = BD;            % (b1)
            cma.bnd = bnd;          % (b2)
            cma.C = C;              % (c)
            cma.chiN = chiN;        % (c1)
            cma.diagC = diagC;      % (d)
            cma.diagD = diagD;      % (d1)
            cma.fitness = fitness;  % (f1)
            cma.iter = cma.iter+1;  % (i)
            cma.maxdx = maxdx;      % (m)
            cma.ps = ps;            % (p)
            cma.pc = pc;            % (p1)
            cma.sigma = sigma;      % (s)
            cma.xmean = xmean;      % (x)
            cma.xold = xold;        % (x1)
            switch cma.mode
                case 'one'  % flg_run_one_iter = 1;
                    STOP_CMA = true;
                case 'stop' % flg_run_until_stop = 1;
                    STOP_CMA = ~isempty(flgstop);
                case 'nfes' % flg_run_nfes = 1;
                    STOP_CMA = (fes>=cma.nfes);
            end
        end %% while, end generation loop
        cma.fes = cma.fes+fes;
        % -----  ----- Final Procedures -----  -----  -----  ----- %
        % Evaluate xmean and return best recent point in xmin
        fmin = fitness.raw(1);
        xmin = arxvalid(:,fitness.idx(1)); % Return best point of last generation.
        if any(strcmp(flgstop,'maxfunevals'))
            break;
        end
    end  % while irun <= Restarts

    if fmin<cma.fmin
        cma.fmin = fmin;
        cma.xmin = xmin;
    end
    if(flgdisp)
        disp(['Prob(',pSet,')-fn',int2str(fn),' result: ',num2str(cma.fmin),' (with fes.',num2str(fes),').'])
        disp(' ')
    end
    %disp('... Terminated due to: ')
    %StopFlag = flgstop;  ii = 1;
    %while ~isempty(StopFlag)
    %    disp(['... ',int2str(ii),'. ',StopFlag{1}])
    %    StopFlag(1)=[];  ii=ii+1;
    %end
% ---------------------------------------------------------------  
% ---------------------------------------------------------------  
% -----| auxiliary function |------------------------------------
% ---------------------------------------------------------------  
% ---------------------------------------------------------------  
function [x,idx] = xintobounds(x,lb,ub)
% x can be a column vector or a matrix consisting of column vectors
    if ~isempty(lb)
        if length(lb)==1
            idx = x<lb;  x(idx)=lb;
        else
            arbounds = repmat(lb,1,size(x,2));
            idx=x<arbounds;  x(idx)=arbounds(idx);
        end
    else
        idx=0;
    end
    if ~isempty(ub)
        if length(ub)==1
            idx2 = x>ub;  x(idx2)=ub;
        else
            arbounds = repmat(ub,1,size(x,2));
            idx2=x>arbounds;  x(idx2)=arbounds(idx2);
        end
    else
        idx2=0;
    end
    idx = idx2-idx;

% ---------------------------------------------------------------  
% ---------------------------------------------------------------  
% ----- replacements for statistic toolbox functions ------------
function res = myrange(x)
    res = max(x)-min(x);

% ---------------------------------------------------------------  
% ---------------------------------------------------------------  
function res = myprctile(inar,perc,idx)
% Computes the percentiles in vector perc from vector inar
% returns vector with length(res)==length(perc)
% idx: optional index-array indicating sorted order
    N = length(inar);
    flgtranspose = 0;
    if size(perc,1)>1
        perc = perc';
        flgtranspose = 1;
        if size(perc,1)>1
            error('perc must not be a matrix');
        end
    end
    if size(inar,1)>1 && size(inar,2)>1
        error('data inar must not be a matrix');
    end
    % sort inar
    if nargin<3||isempty(idx)
        [sar,idx] = sort(inar);
    else
        sar = inar(idx);
    end
    res=[];
    for p=perc
        if p<=100*(0.5/N)
            res(end+1)=sar(1);
        elseif p>=100*((N-0.5)/N)
            res(end+1)=sar(N);
        else  % find largest index smaller than required percentile
            availablepercentiles = 100*((1:N)-0.5)/N;
            i = max(find(p>availablepercentiles));
            % interpolate linearly
            res(end+1) = sar(i)+(sar(i+1)-sar(i))*(p-availablepercentiles(i))/(availablepercentiles(i+1)-availablepercentiles(i));
        end
    end
    if flgtranspose
        res = res';
    end
    
    