% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% Run HR-CMA-ES Batch ...
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% Matlab Code for:
% Yang Lou, Shiu Yin Yuen and Guanrong Chen, "On-line Search
% History-assisted Restart Strategy for Covariance Matrix 
% Adaptation Evolution Strategy", In: IEEE Congress on
% Evolutionary Computation (CEC 2019).
% [preprint in: arXiv:1903.09085]
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% Code by Felix (Yang Lou)
% E-mail: felix.lou@my.cityu.edu.hk
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% updated: 10-03-2019
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

clear all;
close all;
clc
global ProbSet;

ProbSet.rept = 30;  % number of repeated times
ProbSet.pset = 'cec2013';  % benchmark problems {'cec2013';'cec2017'}
switch ProbSet.pset
    case 'cec2013'
        full_set_fn = [1:28];
    case 'cec2017'
        full_set_fn = [1,3:30];
end
ProbSet.fn = full_set_fn;  % or a specified integer for FN 
ProbSet.d = 10;  % problem dimension {10,30}
ProbSet.maxfe = 10000*ProbSet.d;
disp('>>>>  >>>>  Running HR-CMA-ES Batch >>>>  >>>>')
hr_cma_es

%exit

