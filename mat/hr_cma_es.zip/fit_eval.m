% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% benchmark function evaluation
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% updated 29-09-2018
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

function f = fit_eval(x,fn,ProbSet,D,PS)

    if (nargin==5)  % TEST D AND PS %
        [d,ps] = size(x);
        if (D==ps) && (PS==d)
            x = x';
        elseif (D==d) && (PS==ps)
            % *^* do nothing ...
        else
            error('wrong size of ''x'' ...');
        end
    elseif (nargin~=3) && (nargin~=5)
        error('input 3 or 5 paras ...');
    end
    
    switch ProbSet
        case 'cec2017'
            f = cec17_func(x,fn);
        case 'cec2013'
            f = cec13_func(x,fn);
        case 'cec2011'
            f = feval_cec2011(fn,x');
        case 'glg06'
            f = glg06_fit(x');
    end
    
end

