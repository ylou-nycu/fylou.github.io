% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% initialization of the BSP tree (aka. arXiv)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% updated: 09-03-2019
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

function [arXiv,depth,cur_tree_size] = arXiv_init(d,max_size)
% === === === === === === === === === %
% INPUT:  1) d - dimensionality
%         2) max_size - total number of evaluations
% OUTPUT: 1) arXiv
%         2) depth information
%         3) current tree size
% === === === === === === === === === %

    lv = ceil(log2(max_size/2));  % average depth
    k  = round(log2(4+floor(3*log(d))));  % lambda = 4+floor(3*log(d))
    depth = struct('dp_max',(lv+k), 'k',k, 'leafmark',max_size+1);
    arXiv = struct ('x',	zeros(d,max_size),      ...
                    'f',	zeros(1,max_size),      ...
                    'd',	-1*ones(1,max_size),	...
                    'min',	zeros(1,max_size),      ...
                    'max',	zeros(1,max_size),      ...
                    'px',	zeros(1,max_size),      ...
                    'lx',	(max_size+1)*ones(1,max_size),	...
                    'rx',	(max_size+1)*ones(1,max_size),  ...
                    'blk',	zeros(1,max_size),      ... %% block, (1:no_further_search || 0:normal)
                    'dp',	zeros(1,max_size));
    arXiv.d(1,1) = -2;
    cur_tree_size = 0;
    % Note: 1) un-initialized nodes: [.d == -1]
    %       2) leaf nodes:           [.d ==  0]
end

