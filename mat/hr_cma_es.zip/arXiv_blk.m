% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% to set the value of the blocked (non-revisiting) sub-region
% (blk = blocked)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% updated: 09-03-2019
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

function arXiv_blk(pos,x,f)
% pos - the id in the BSP tree (arXiv)
%   x - solution
%   f - fitness of the solution
global arXiv;
global depth;

    if ~arXiv.blk(1,pos);  error('check the blk node ...');  end
    if arXiv.dp(1,pos)~= depth.dp_max-depth.k;  error('check the depth of blk node ...');  end
    % only if (pos.blk==True) and (pos.dp==dp_max-k)
    % then, reset the following data:
    arXiv.x(:,pos) = x;
    arXiv.f(1,pos) = f;
    arXiv.d(1,pos) = 0;
    arXiv.lx(1,pos) = depth.leafmark;
    arXiv.rx(1,pos) = depth.leafmark;
    % the entire sub-region (under pos) has been blocked to cNrGA
end

