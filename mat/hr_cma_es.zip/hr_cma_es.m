% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% Matlab Code for:
% Yang Lou, Shiu Yin Yuen and Guanrong Chen, "On-line Search
% History-assisted Restart Strategy for Covariance Matrix 
% Adaptation Evolution Strategy", In: IEEE Congress on
% Evolutionary Computation (CEC 2019).
% [preprint in: arXiv:1903.09085]
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% Code by Felix (Yang Lou)
% E-mail: felix.lou@my.cityu.edu.hk
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% updated: 09-03-2019
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

global ProbSet;
global arXiv;
global depth;

Rept = ProbSet.rept;  %% Repeated Runs
pSet = ProbSet.pset;
d    = ProbSet.d;
max_feval = ProbSet.maxfe; %min(5000*d,50000);
FN = ProbSet.fn;

switch pSet
    case 'cec2013'
        bias = [-1400:100:-100,100:100:1400];
        %FN = 1:28;
    case 'cec2017'
        bias = 100:100:3000;
        %FN = [1,3:30]; FN=2 excluded
    otherwise
        error('wrong problem set ...')
end

% ----- | problem parameter | ----- %
lb0 = -100*ones(d,1);  % Both CEC 13 and 17 %
ub0 =  100*ones(d,1);
bound.lb = lb0;     bound.ub = ub0;
ProbSet.lb0 = lb0;  ProbSet.ub0 = ub0;
Cr  = 0.5;  % THERE ARE ONLY TWO PARAMETERS IN CNRGA % 
Ps  = 100;  % THEY ARE: XOVER_RATE(Cr) AND Ps  %
Root= 1;    % THE Root NODE OF THE BSP TREE %
lambda = 4+floor(3*log(d));  % for CMA-ES
out_fit = Inf*ones(Rept,max(FN));

for fn = FN
    solution = zeros(d,Rept);
    for r = 1:Rept
        clear cma
        % --- Initializing CMA --- %
        cma.iter = 0;
        cma.fes  = 0;
        cma.mode = 'stop';  %% {'one'; 'stop'; 'nfes'}
        % --- Initializing CMA --- %
        arXiv_size = 2*max_feval;        
        disp(['>> cNrGA + CMA-ES:: ',pSet,' fn.', int2str(fn), ', Max_FEs:', int2str(max_feval), ...
              ', Run:', int2str(r), '/', int2str(Rept), '... ']);
        % ----- | initialization | ----- %
        lb = repmat(lb0,1,Ps);
        ub = repmat(ub0,1,Ps);
        cur_pop = lb+(ub-lb).*rand(d,Ps);
        cur_fit = fit_eval(cur_pop,fn,pSet,d,Ps);
        cur_feval = Ps;
        [arXiv,depth,node_cnt] = arXiv_init(d,arXiv_size);
        arXiv.upl = ceil(log2(lambda));
        [node_cnt] = arXiv_inst(cur_pop,cur_fit,node_cnt);
        % ----- | end: initialization | ----- %
        % ----- | main loop of cnrga | ----- %
        while cur_feval<max_feval
            % --- uniform Xover --- %
            i_idx = 1:Ps;
            rnd_idx = ceil(Ps*rand(1,Ps));
            same_idx = find(rnd_idx(1,i_idx)==i_idx);
            len_same_idx = length(same_idx);
            if (len_same_idx)
                for ls_idx = 1:len_same_idx
                    while rnd_idx(1,same_idx(ls_idx))==i_idx(1,same_idx(ls_idx))
                        rnd_idx(1,same_idx(ls_idx))=ceil(Ps*rand);
                    end
                end
            end
            bin_eff = (rand(d,Ps)>Cr);
            nxt_pop = cur_pop(:,i_idx).*bin_eff(:,:) + cur_pop(:,rnd_idx).*(~bin_eff(:,:));
            % --- end: uniform Xover --- %

            % --- mutation --- %
            for idx = 1:Ps
                [bsptree_id_tmp,sub_h,blk_flag] = arXiv_search(nxt_pop(:,idx),lb0,ub0);
                if ~sum(abs(arXiv.x(:,bsptree_id_tmp) - nxt_pop(:,idx)))  % REVISITING %
                    jdx = ceil(d*rand);
                    nxt_pop(jdx,idx) = rand*(sub_h(jdx,2) - sub_h(jdx,1)) + sub_h(jdx,1);
                end
                while blk_flag
                    nxt_pop(:,idx) = lb0+(ub0-lb0).*rand(d,1);
                    [~,~,blk_flag] = arXiv_search(nxt_pop(:,idx),lb0,ub0);
                end
            end
            % --- end: mutation --- %

            % --- fitness evaluation --- %
            nxt_fit = fit_eval(nxt_pop,fn,pSet,d,Ps);
            cur_feval = cur_feval + Ps;
            % --- end: fitness evaluation --- %

            % --- insertion --- %
            [node_cnt,roi] = arXiv_inst(nxt_pop, nxt_fit, node_cnt);
            % --- end: insertion --- %
            if roi.flag  %% Region of Interest, using CMAS-ES
                cma.xmean = roi.xmean;
                %-> use cma properly
                cma.fes_remain = max_feval - cur_feval;
                cma.fes_cmaes = cma.fes_remain;  %% min(cma.fes_remain,6000);  %% a given max_fes for CMA
                feval_a = cma.fes;
                % --- limit a sub-region --- %
                %subb.lb = roi.sub_h(:,1);
                %subb.ub = roi.sub_h(:,2);
                % --- limit a sub-region --- %
                [~,cma,flg_stop] = cmaes(pSet,fn,d,bound,cma);
                feval_d = cma.fes - feval_a;
                cur_feval = cur_feval+feval_d;
                arXiv_blk(roi.pdx,cma.xmin,cma.fmin);
                if cma.fmin < out_fit(r,fn)
                    out_fit(r,fn) = cma.fmin;
                end  %% 'warnconditioncov';'warnnoeffectcoord';'warnnoeffectaxis';'warnequalfunvals';'warnequalfunvalhist';
                if ~isempty(flg_stop) && ~strcmp(flg_stop{end},'maxfunevals')
                    cma.reset = true;
                    cma.iter = 0;
                    cma.fes  = 0;
                end
            end
            
            % --- selection --- %
            tmp_pop = [cur_pop,nxt_pop];
            tmp_fit = [cur_fit,nxt_fit];
            if roi.flag
                tmp_pop = [tmp_pop,cma.xmin];
                tmp_fit = [tmp_fit,cma.fmin];
            end
            [~,sort_idx] = sort(tmp_fit);
            cur_pop(:,1:Ps) = tmp_pop(:,sort_idx(1:Ps));
            cur_fit(1,:) = tmp_fit(1,sort_idx(1:Ps));
            % --- end+ selection --- %

            [cur_min_fit,min_idx] = min(cur_fit);
            if cur_min_fit <= out_fit(r,fn)
                out_fit(r,fn) = cur_min_fit;
                solution(:,r) = cur_pop(:,min_idx);
            end
        end        
        out_fit(r,fn) = out_fit(r,fn)-bias(fn);
        disp(['   --> fitness_found (run ', int2str(r), '/', int2str(Rept), '): ', num2str(out_fit(r,fn))]);
    end
    fitness = out_fit(:,fn);
    fname = ['HRCMAES_',pSet,'_fn',int2str(fn),'_d',int2str(d),'.mat'];
    save(fname,'solution','fitness');
end

clear RAND_LIST PRUNE_LIST ub lb tmp_pop tmp_fit sub_h sort_idx same_idx rnd_idx nxt_pop nxt_fit min_idx ls_idx r len_same_idx ...
      idx jdx i_idx gen cur_pop cur_min_fit cur_fit bsptree_id_tmp bin_eff ts arXiv;
fname = ['HRCMAES_ALL_',pSet,'_d',int2str(d),'.mat'];
save(fname);

