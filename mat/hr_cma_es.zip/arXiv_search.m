% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% arXiv BSP tree search solution position
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% updated 09-03-2019
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

function [nx,sub_h,blk_flag] = arXiv_search(x,lb,ub)
% ---  ---  ---  ---  ---  ---  ---  --- 
% Input:
%       nx - index of x in arXiv
%    sub_h - sub-region
% blk_flag - flag: blocked or not
% ---  ---  ---  ---  ---  ---  ---  --- 
% Output:
%        x - solution
%       lb - lower bound
%       ub - upper bound
% ---  ---  ---  ---  ---  ---  ---  --- 
global arXiv;

    blk_flag = 0;
    nx = 1;
    sub_h = [lb,ub];  % search space
    while arXiv.d(1,nx)
        jdx = arXiv.d(1,nx);
        if x(jdx,1) < (arXiv.min(1,nx)+arXiv.max(1,nx))/2
            sub_h(jdx,2) = arXiv.max(1,nx);
            nx = arXiv.lx(1,nx);
        else
            sub_h(jdx,1) = arXiv.min(1,nx);
            nx = arXiv.rx(1,nx);
        end
        if arXiv.blk(1,nx)  %% blokced region
            blk_flag = 1;
            break
        end
    end
    
end

