% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% arXiv BSP tree insertion
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% all the solutions (x) ready to be inserted:
%       1. x is NOT a revisit of any other inserted solution
%       2. x is NOT within any BLOCKED sub-region
% if x is inserted deeper than depth.dp_max, then it is 
%       considered within a ROI (region of interest)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% updated 09-03-2019
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

function [nodesum,roi] = arXiv_inst(x,f,nodesum)
% nodesum - number of nodes in current arXiv
global arXiv;
global depth;
global ProbSet;

    roi.flag = 0;	 % default: ROI not found
    ps = size(x,2);  % get the number of solutions in x
    for idx = 1:ps
        if arXiv.d(1,1)==(-2)  % only root node
            arXiv.x(:,1) = x(:,1);
            arXiv.f(1,1) = f(1,1);
            arXiv.d(1,1) = 0;
            arXiv.dp(1,1) = 0;  % depth of tree node
            nodesum = 1;
        else  % i.e., 'arXiv.d(1,1) ~= -2'
            nx=1;  % search in the tree, from top-down
            while arXiv.d(1,nx)
                jdx = arXiv.d(1,nx);
                if x(jdx,idx) < (arXiv.min(1,nx)+arXiv.max(1,nx))/2
                    nx = arXiv.lx(1,nx);  % left
                else
                    nx = arXiv.rx(1,nx);  % right
                end
            end  % THEN PARTITION THE NODE 'N_IDX' %
            memo_x = arXiv.x(:,nx);
            memo_f = arXiv.f(1,nx);
            d_diff = abs(memo_x - x(:,idx));
            d = find(d_diff == max(d_diff));  % binary partition the max-difference-dimension
            d = d(randi(length(d)));
            % --- --- --- --- --- --- --- --- --- --- %
            cur_min = min(memo_x(d,1),x(d,idx));
            cur_max = max(memo_x(d,1),x(d,idx));
            % --- --- --- --- --- --- --- --- --- --- %
            arXiv.d(1,nx) = d;
            arXiv.min(1,nx) = cur_min;
            arXiv.max(1,nx) = cur_max;
            lx = nodesum+1;
            rx = nodesum+2;
            nodesum = nodesum+2;
            arXiv.lx(1,nx) = lx;
            arXiv.rx(1,nx) = rx;
            arXiv.px(1,lx) = nx;
            arXiv.px(1,rx) = nx;
            arXiv.d(1,lx) = 0;
            arXiv.d(1,rx) = 0;
            arXiv.dp(1,lx) = arXiv.dp(1,nx)+1;
            arXiv.dp(1,rx) = arXiv.dp(1,nx)+1;
            
            if x(d,idx) < (cur_min+cur_max)/2
                arXiv.x(:,lx) = x(:,idx);
                arXiv.f(1,lx) = f(1,idx);
                arXiv.x(:,rx) = memo_x;
                arXiv.f(1,rx) = memo_f;
            else
                arXiv.x(:,rx) = x(:,idx);
                arXiv.f(1,rx) = f(1,idx);
                arXiv.x(:,lx) = memo_x;
                arXiv.f(1,lx) = memo_f;
            end
            if arXiv.dp(1,lx) == depth.dp_max  %% || arXiv.dp(1,rx) == depth.dp_max
                roi.flag = 1;  % ROI found
                [roi.xmean,~,roi.pdx] = arXiv_roi(lx);  % ROI located
                % ----  ----  ----|  Info about roi  |----  ----  ----  - %
                % -    roi.flag   - 1 == ROI found                      - %
                % -    roi.xmean  - center of ROI                       - %
                % -    roi.pdx    - sub-root of ROI in arXiv            - %
                % -    roi.sub_h  - sub-region of ROI in search space   - %
                % ----  ----  ----|  Info about roi  |----  ----  ----  - %
                [~,sub_h,~] = arXiv_search(arXiv.x(:,roi.pdx),ProbSet.lb0,ProbSet.ub0);
                roi.sigma = 0.3*(max(sub_h(:,2)-sub_h(:,1)));
                return
                % >>>> cNrGA is paused >>>> CMA-ES is triggered >>>>
            end
        end
    end
end

