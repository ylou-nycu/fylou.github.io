-----  -----  -----  -----  -----  -----  -----  -----  ----- 
Matlab Code for:
	Yang Lou, Shiu Yin Yuen and Guanrong Chen, "On-line Search
    History-assisted Restart Strategy for Covariance Matrix
    Adaptation Evolution Strategy", In: IEEE Congress on
    Evolutionary Computation (CEC 2019).
    [preprint in: arXiv:1903.09085]
-----  -----  -----  -----  -----  -----  -----  -----  ----- 
Code by Felix (Yang Lou)
E-mail: felix.lou@my.cityu.edu.hk
-----  -----  -----  -----  -----  -----  -----  -----  ----- 
updated: 09-03-2019
-----  -----  -----  -----  -----  -----  -----  -----  ----- 
-----  -----  -----  -----  -----  -----  -----  -----  ----- 

Run HR-CMA-ES batch = 'RUN'

-----  -----  -----  -----  -----  -----  -----  -----  ----- 
-----  -----  -----  -----  -----  -----  -----  -----  ----- 
To run 'hr_cma_es.m' independently, all the fields of
(global variable) ProbSet should be assigned in advance.

-----  -----  -----  -----  -----  -----  -----  -----  ----- 
For example: 
    ProbSet.rept = 30;          % number of repeated times
    ProbSet.pset = 'cec2013';	% benchmark problems {'cec2013';'cec2017'}
    ProbSet.fn	 = 1;           % problem ID in the benchmark 
    ProbSet.d	 = 10;          % problem dimension {10,30}
    ProbSet.maxfe = 10000*ProbSet.d;    % maximum number of evaluations
then, run
    hr_cma_es
-----  -----  -----  -----  -----  -----  -----  -----  ----- 
-----  -----  -----  -----  -----  -----  -----  -----  ----- 
