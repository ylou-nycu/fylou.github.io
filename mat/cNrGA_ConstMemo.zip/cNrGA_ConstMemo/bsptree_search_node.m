% ===   ***** ***** ***** ***** ***** ***** *****  	=== %
% ===   BSPTREE_SEARCH_NODE                        	=== %
% ===   ***** ***** ***** ***** ***** ***** *****  	=== %
% === 	CREATED: 23 NOVEMBER, 2014                 	=== %
% ===   UPDATED: 23 NOVEMBER, 2014                  === %
% ===   ***** ***** ***** ***** ***** ***** *****  	=== %

function [n_idx, sub_h] = bsptree_search_node(x, lower, upper)

global BSPTREE;
    n_idx = 1;
    sub_h = [lower, upper];
    while BSPTREE.d(1, n_idx)
        jdx = BSPTREE.d(1, n_idx);
        if x(jdx, 1) < (BSPTREE.min(1, n_idx) + BSPTREE.max(1, n_idx)) / 2.0
            sub_h(jdx, 2) = BSPTREE.max(1, n_idx);
            n_idx = BSPTREE.l_idx(1, n_idx);
        else
            sub_h(jdx, 1) = BSPTREE.min(1, n_idx);
            n_idx = BSPTREE.r_idx(1, n_idx);
        end
    end
    
end