% ===   ***** ***** ***** ***** ***** ***** *****  	=== %
% ===   BSPTREE_INSERTION                         	=== %
% ===   ***** ***** ***** ***** ***** ***** *****  	=== %
% === 	CREATED: 22 NOVEMBER, 2014                 	=== %
% ===   UPDATED: 23 MAY, 2015                       === %
% ===   ***** ***** ***** ***** ***** ***** *****  	=== %

function [cur_bsptree_node] = bsptree_insertion(x, f, cur_bsptree_node)

global BSPTREE;
    [~, pop_size] = size(x);

    for idx = 1 : pop_size
        if BSPTREE.d(1, 1) == -2  % ROOT NODE ONLY %
            BSPTREE.x(:, 1)  = x(:, 1);
            BSPTREE.f(1, 1)  = f(1, 1);
            BSPTREE.d(1, 1)  = 0;   % THE ROOT IS NOW A 'LEAF' %
            cur_bsptree_node = 1;
        else  % MEANS IF 'BSPTREE.D(1, 1) ~= -2' %
            n_idx = 1;
            while BSPTREE.d(1, n_idx)
                jdx = BSPTREE.d(1, n_idx);
                if x(jdx, idx) < (BSPTREE.min(1, n_idx) + BSPTREE.max(1, n_idx)) / 2.0
                    n_idx = BSPTREE.l_idx(1, n_idx);
                else
                    n_idx = BSPTREE.r_idx(1, n_idx);
                end
            end  % THEN PARTITION THE NODE 'N_IDX' %
            memo_x = BSPTREE.x(:, n_idx);
            memo_f = BSPTREE.f(1, n_idx);
            d_diff = abs(memo_x - x(:, idx));
            d = find(d_diff == max(d_diff));
            d = d(1);
%             if length(d) > 1
% %                 d = d(ceil(rand * length(d)));
%               	d = d(1);
%             end
            % --- --- --- --- --- --- --- --- --- --- %
            cur_min = min(memo_x(d, 1), x(d, idx));
            cur_max = max(memo_x(d, 1), x(d, idx));
            % --- --- --- --- --- --- --- --- --- --- %
            BSPTREE.d(1, n_idx) = d;
            BSPTREE.min(1, n_idx) = cur_min;
            BSPTREE.max(1, n_idx) = cur_max;
            
            l_idx = cur_bsptree_node + 1;
            r_idx = cur_bsptree_node + 2;
            cur_bsptree_node = cur_bsptree_node + 2;
            BSPTREE.l_idx(1, n_idx) = l_idx;
            BSPTREE.r_idx(1, n_idx) = r_idx;
            BSPTREE.p_idx(1, l_idx) = n_idx;
            BSPTREE.p_idx(1, r_idx) = n_idx;
            BSPTREE.d(1, l_idx) = 0;
            BSPTREE.d(1, r_idx) = 0;
            
            if x(d, idx) < (cur_min + cur_max) / 2.0
                BSPTREE.x(:, l_idx) = x(:, idx);
                BSPTREE.f(1, l_idx) = f(1, idx);
                BSPTREE.x(:, r_idx) = memo_x;
                BSPTREE.f(1, r_idx) = memo_f;
            else
                BSPTREE.x(:, r_idx) = x(:, idx);
                BSPTREE.f(1, r_idx) = f(1, idx);
                BSPTREE.x(:, l_idx) = memo_x;
                BSPTREE.f(1, l_idx) = memo_f;
            end
            
        end  % END OF IF-ELSE 'BSPTREE.D(1, 1) == -2' %
        
    end  % END OF 'FOR IDX = 1 : POP_SIZE' %

end