% ===   ***** ***** ***** ***** ***** ***** ***** ***** ***** *****	=== %
% ===   Source Code for the Paper:                                  === %
% ===   Yang Lou, Shiu Yin Yuen, "Non-revisiting Genetic Algorithm	=== % 
% ===   with Adaptive Mutation Using Constant Memory",              === %
% ===   doi: 10.1007/s12293-015-0178-6. Memetic Computing, 2016.	=== %
% ===   http://link.springer.com/article/10.1007/s12293-015-0178-6  === %
% ===   Programmer: Yang Lou (http://www.ee.cityu.edu.hk/~ylou/)    === %
% ===   Email:      Felix.lou@my.cityu.edu.hk                       === %
% ===   ***** ***** ***** ***** ***** ***** ***** ***** ***** *****	=== %
% ===   Code Last Updated: 05/01/2016
% ===   ***** ***** ***** ***** ***** ***** ***** ***** ***** *****	=== %
% ===   More about Non-revisiting Stochastic Search:
% ===   http://www.ee.cityu.edu.hk/~syyuen/Public/Code.html
% ===   ***** ***** ***** ***** ***** ***** ***** ***** ***** *****	=== %

% % Copyright (c) 2016 Yang Lou and Shiu Yin Yuen. 
% % All rights reserved.
% % 
% % Redistribution and use in source and binary forms, with or without
% % modification, are permitted provided that the following conditions
% % are met: 
% % 
% % 1. Redistributions of source code must retain the above copyright
% %    notice, this list of conditions and the following disclaimer. 
% % 2. Redistributions in binary form must reproduce the above copyright
% %    notice, this list of conditions and the following disclaimer in
% %    the documentation and/or other materials provided with the 
% %    distribution.
% % 
% % This software is provided by the copyright holders and contributors
% % "as is" and any express or implied warranties, including, but not 
% % limited to, the implied warranties of merchantability and fitness
% % for a particular purpose are disclaimed. In no event shall the
% % copyright owner or contributors be liable for any direct, indirect,
% % incidental, special, exemplary, or consequential damages (including,
% % but not limited to, procurement of substitute goods or services;
% % loss of use, data, or profits; or business interruption) however
% % caused and on any theory of liability, whether in contract, strict
% % liability, or tort (including negligence or otherwise) arising in
% % any way out of the use of this software, even if advised of the
% % possibility of such damage.

% ===   ***** ***** ***** ***** ***** ***** ***** ***** ***** *****	=== %

clear all;
close all;

global BSPTREE;

% === USER-DEFINED PARAMETER DEFINITION ... === %
disp('Input the Following data: ')
PRUNE_ID = input('Prune Strategy [1(cNrGA) 2(cNrGA/CM/LRU) 3(cNrGA/CM/R)]: ');	% 'lru' OR 'rnd' OR 'non' %
switch PRUNE_ID
    case 1
        PRUNE_STRATEGY = 'non';
    case 2
        PRUNE_STRATEGY = 'lru';
        addpath('pruning');
    case 3
        PRUNE_STRATEGY = 'rnd';
        addpath('pruning');
    otherwise
        error('Please input correct Prune Strategy.');
end
REPEAT_RUN = input('Number of Independent Runs: ');
FUNC_ID    = input('ID of Problem (1~28): ');
MAX_FES    = input('Maximum Number of Evaluations (e.g. 40000): ');
if strcmp(PRUNE_STRATEGY, 'non')
    LIMIT_FES = MAX_FES;
else
    LIMIT_FES = input('Memory Threshold (e.g. 10000): ');
end
save_tree_flag = input('Do you want to save the BSP_Tree(s) (y/n)? ', 's');

% === NON-USER-DEFINED PARAMETER FOLLOWING ... === %
DIM         = 30;
LOWER_BOUND = - 100 * ones(DIM, 1);     % THE LOWER AND UPPER BOUND FOR CEC 2013 FUNCTIONS %
UPPER_BOUND = + 100 * ones(DIM, 1);
CR          = 0.5;  % THERE ARE ONLY TWO PARAMETERS IN CNRGA % 
POP_SIZE	= 100;  % THEY ARE: XOVER_RATE(CR) AND POP_SIZE  %
ROOT        = 1;    % THE ROOT NODE OF THE BSP TREE %

OUTPUT_FITNESS = Inf * ones(REPEAT_RUN, 1);  % FINAL RESULT OBTAINED %
TEST = false;       % [true / false] - WHEN TEST IS TRUE: RECORD FITNESS CURVE & RUNNING TIME %
if TEST    
    FIT_CURVE = cell(REPEAT_RUN, 1);        % FITNESS CURVE %
    RUN_TIME = zeros(REPEAT_RUN, 1);        % RUN TIME %
end
% === END OF PARAMETER DEFINITION === %

for r = 1 : REPEAT_RUN
    
    MAX_GENERATION   = floor(MAX_FES  / POP_SIZE);
    LIMIT_GENERATION = floor(LIMIT_FES / POP_SIZE);  % NO PRUNING HAPPEN WITHIN THIS GENS %
    
    if strcmp(PRUNE_STRATEGY, 'non') && LIMIT_GENERATION < MAX_GENERATION
        error('When there is no pruning, MemoUsage should equal to MaxFEs ... ');
    end
    MAX_BSPTREE_NODE = 2 * LIMIT_FES;
    if TEST
        fit_curve = zeros(1, MAX_GENERATION);
    end
    % DISPLAY RUNNING INFORMATION ... %
    disp(['>> CEC 2013 Func.', int2str(FUNC_ID), ', Max_FEs:', int2str(MAX_FES), ...
          ', Memory Threshold(MT):', int2str(LIMIT_FES),', Run:', int2str(r), '/', int2str(REPEAT_RUN), '... ']);
      
% >> === === === INITIALIZATION === === === %
    if TEST tic; end
	lb = repmat(LOWER_BOUND, 1, POP_SIZE);  % LOWER BOUNDARY IN MATRIX FORM %
    ub = repmat(UPPER_BOUND, 1, POP_SIZE);  % UPPER BOUNDARY IN MATRIX FORM %
    cur_pop = lb + (ub - lb) .* rand(DIM, POP_SIZE);
    cur_fit = cec13_func(cur_pop, FUNC_ID);
    [BSPTREE, NUM_OF_BSPTREE] = bsptree_initilization(DIM, MAX_BSPTREE_NODE, PRUNE_STRATEGY);
    if strcmp(PRUNE_STRATEGY, 'lru')
        ts = 1;     % TIME STAMP FOR LEAST RECENT USED %
    end
    switch PRUNE_STRATEGY
        case 'non'
            [NUM_OF_BSPTREE] = bsptree_insertion(cur_pop, cur_fit, NUM_OF_BSPTREE);
        case 'lru'
            [NUM_OF_BSPTREE] = bsptree_insertion_p(cur_pop, cur_fit, ts, NUM_OF_BSPTREE);
            PRUNE_LIST = [];  % TO PRUNE LIST FOR LRU %
        case 'rnd'
            [NUM_OF_BSPTREE] = bsptree_insertion_r(cur_pop, cur_fit, NUM_OF_BSPTREE);
            RAND_LIST  = [];  % TO PRUNE LIST FOR RND %
    end
    if TEST fit_curve(1, 1) = min(cur_fit); end
% >> === === === END OF INITIALIZATION === === === %

% >> === === === MAIN LOOP OF CNRGA === === === %
    for gen = 2 : MAX_GENERATION
        % --- --- --- UNIFORM CROSSOVER --- --- --- %
        i_idx = 1 : POP_SIZE;
        rnd_idx = ceil(POP_SIZE * rand(1, POP_SIZE));
        same_idx = find(rnd_idx(1, i_idx) == i_idx);
        len_same_idx = length(same_idx);
        if (len_same_idx)
            for ls_idx = 1 : len_same_idx
                while rnd_idx(1, same_idx(ls_idx)) == i_idx(1, same_idx(ls_idx))
                    rnd_idx(1, same_idx(ls_idx)) = ceil(POP_SIZE * rand(1, 1));
                end
            end
        end
        bin_eff = (rand(DIM, POP_SIZE) > CR);
        nxt_pop = cur_pop(:, i_idx) .* bin_eff(:, :) + cur_pop(:, rnd_idx) .* (~bin_eff(:, :));
        % --- --- --- END OF CROSSOVER --- --- --- %

        % --- --- --- MUTATION (ONLY WHEN REVISIT) --- --- --- %
        for idx = 1 : POP_SIZE
            [bsptree_id_tmp, sub_h] = bsptree_search_node(nxt_pop(:, idx), LOWER_BOUND, UPPER_BOUND);
            if ~ sum(abs(BSPTREE.x(:, bsptree_id_tmp) - nxt_pop(:, idx)))  % REVISITING %
                jdx = ceil(DIM * rand);
                nxt_pop(jdx, idx) = rand * (sub_h(jdx, 2) - sub_h(jdx, 1)) + sub_h(jdx, 1);
            end
        end
        % --- --- --- END OF MUTATION --- --- --- %
        
        % --- --- --- FITNESS EVALUATION ----- %
        nxt_fit = cec13_func (nxt_pop, FUNC_ID);
        % --- --- --- END OF FITNESS EVALUATION ----- %
        
        % --- --- --- INSERTION --- --- --- %
        if gen <= LIMIT_GENERATION  % BEFORE MT REACHED, EVERY EVALUATION IS RECORDED %
            switch PRUNE_STRATEGY
                case 'non'
                    [NUM_OF_BSPTREE] = bsptree_insertion(nxt_pop, nxt_fit, NUM_OF_BSPTREE);
                case 'lru'
                    [NUM_OF_BSPTREE] = bsptree_insertion_p(nxt_pop, nxt_fit, ((gen - 1) * POP_SIZE + 1), NUM_OF_BSPTREE);
                case 'rnd'
                    [NUM_OF_BSPTREE] = bsptree_insertion_r(nxt_pop, nxt_fit, NUM_OF_BSPTREE);
            end
        else  % WHEN/AFTER MT REACHED, PRUNING IS PERFORMED %
            switch PRUNE_STRATEGY
                case 'non'
                    [NUM_OF_BSPTREE] = bsptree_insertion(nxt_pop, nxt_fit, NUM_OF_BSPTREE);
                case 'lru'
                    for idx = 1 : POP_SIZE  % IN THIS CASE, WE INSERT ONE AFTER ANOTHER %
                        if length(PRUNE_LIST) > 1
                            PRUNE_LIST = prune_and_reinsert_p(PRUNE_LIST, nxt_pop(:, idx), nxt_fit(idx), ((gen - 1) * POP_SIZE + idx));
                        else
                            PRUNE_LIST = get_prune_list_p;
%                             PRUNE_LIST = get_prune_list_p(2 * ceil(MAX_FES - LIMIT_FES));
                            PRUNE_LIST = prune_and_reinsert_p(PRUNE_LIST, nxt_pop(:, idx), nxt_fit(idx), ((gen - 1) * POP_SIZE + idx));
                        end
                    end
                case 'rnd'
                    for idx = 1 : POP_SIZE
                        if length(RAND_LIST) > 1
                            RAND_LIST = prune_and_reinsert_r(RAND_LIST, nxt_pop(:, idx), nxt_fit(idx));
                        else
                            RAND_LIST = get_prune_list_r;
                            RAND_LIST = prune_and_reinsert_r(RAND_LIST, nxt_pop(:, idx), nxt_fit(idx));
                        end
                    end
            end
        end
        % --- --- --- END: INSERTION, BOTH NON-PRUNE & PRUNE --- --- --- %
        
        % --- --- --- SELECTION ----- %
        tmp_pop = [cur_pop, nxt_pop];
        tmp_fit = [cur_fit, nxt_fit];
        [~, sort_idx] = sort(tmp_fit);
        cur_pop(:, 1 : POP_SIZE) = tmp_pop(:, sort_idx(1 : POP_SIZE));
        cur_fit(1, :) = tmp_fit(1, sort_idx(1 : POP_SIZE));
        % --- --- --- END: SELECTION ----- %
        
        [cur_min_fit, min_idx] = min(cur_fit);
        if cur_min_fit <= OUTPUT_FITNESS(r, 1)
            OUTPUT_FITNESS(r, 1) = cur_min_fit;
        end
        if TEST fit_curve(1, gen) = cur_min_fit; end
    end  % END OF GEN = 2 : LIMIT_GENERATION %
    
    if TEST
        RUN_TIME(r, 1) = RUN_TIME(r, 1) + toc;
        FIT_CURVE{r, 1} = fit_curve;
    end
    
    disp(['>> Fitness found (run ', int2str(r), '/', int2str(REPEAT_RUN), '): ', num2str(cur_min_fit)]);
    if strcmp(save_tree_flag, 'y') || strcmp(save_tree_flag, 'Y')
        switch PRUNE_STRATEGY
            case 'non'
                fname = ['BSPTREE'];
            case 'lru'
                fname = ['BSPTREE_CMLRU'];
            case 'rnd'
                fname = ['BSPTREE_CMR'];
        end
        fname1 = ['_F', int2str(FUNC_ID), '_R', int2str(r), '.mat'];
        fname = strcat(fname, fname1);
        save(fname, 'BSPTREE');
        clear fname fname1;
    end
end

if PRUNE_ID ~= 1
    rmpath('pruning');
end

clear RAND_LIST PRUNE_LIST ub lb tmp_pop tmp_fit sub_h sort_idx same_idx rnd_idx nxt_pop nxt_fit min_idx ls_idx r len_same_idx ...
      idx jdx i_idx gen cur_pop cur_min_fit cur_fit bsptree_id_tmp bin_eff ts BSPTREE save_tree_flag;

save_flag = input('Save the Results(y/n)? ', 's');
if strcmp(save_flag, 'y') || strcmp(save_flag, 'Y')
    switch PRUNE_STRATEGY
        case 'non'
            fname = ['cNrGA'];
        case 'lru'
            fname = ['cNrGA_CM_LRU'];
        case 'rnd'
            fname = ['cNrGA_CM_R'];
    end
    fname1 = ['_F', int2str(FUNC_ID), '.mat'];
    fname = strcat(fname, fname1);
    save(fname);
    clear save_flag fname fname1;
end
