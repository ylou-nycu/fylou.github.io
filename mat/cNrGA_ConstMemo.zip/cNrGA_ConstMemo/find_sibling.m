% ===   ***** ***** ***** ***** ***** ***** *****  	=== %
% ===   FIND_SIBLING                               	=== %
% ===   ***** ***** ***** ***** ***** ***** *****  	=== %
% === 	CREATED: 23 NOVEMBER, 2014                 	=== %
% ===   UPDATED: 23 NOVEMBER, 2014                  === %
% ===   ***** ***** ***** ***** ***** ***** *****  	=== %

function [jdx, is_leaf] = find_sibling(idx)
% === === === === === === === === === %
% INPUT:  1) IDX, NODE ADDRESS;
% OUTPUT: 1) JDX, ITS SIBLING;
%   	  2) IS_LEAF, (0)NON-LEAF, (1)LEAF;
% === === === === === === === === === %
global BSPTREE;

    p_idx   = BSPTREE.p_idx(1, idx);
    left    = BSPTREE.l_idx(1, p_idx);
    right   = BSPTREE.r_idx(1, p_idx);
    jdx     = right * (BSPTREE.l_idx(1, p_idx) == idx) + left * (BSPTREE.r_idx(1, p_idx) == idx);
    if ~ jdx
        disp(['idx = ', num2str(idx)]);
        error('wrong here ...');
    end
    is_leaf = (~ BSPTREE.d(1, jdx));
    
end     % END OF FUNCTION %