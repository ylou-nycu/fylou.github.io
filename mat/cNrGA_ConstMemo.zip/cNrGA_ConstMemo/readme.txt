% ===   ***** ***** ***** ***** ***** ***** ***** ***** ***** *****	=== %
% ===   Source Code for the Paper:                                  === %
% ===   Yang Lou, Shiu Yin Yuen, "Non-revisiting Genetic Algorithm	=== % 
% ===   with Adaptive Mutation Using Constant Memory",              === %
% ===   doi: 10.1007/s12293-015-0178-6. Memetic Computing, 2016.	=== %
% ===   http://link.springer.com/article/10.1007/s12293-015-0178-6  === %
% ===   Programmer: Yang Lou (http://www.ee.cityu.edu.hk/~ylou/)    === %
% ===   Email:      Felix.lou@my.cityu.edu.hk                       === %
% ===   ***** ***** ***** ***** ***** ***** ***** ***** ***** *****	=== %
% ===   Code Last Updated: 05/01/2016
% ===   ***** ***** ***** ***** ***** ***** ***** ***** ***** *****	=== %
% ===   More about Non-revisiting Stochastic Search:
% ===   http://www.ee.cityu.edu.hk/~syyuen/Public/Code.html
% ===   ***** ***** ***** ***** ***** ***** ***** ***** ***** *****	=== %
% ===	Copyright (c) 2016 Yang Lou and Shiu Yin Yuen.           	=== %
% ===   All rights reserved.                                        === %
% ===   ***** ***** ***** ***** ***** ***** ***** ***** ***** *****	=== %

RUN = 'cNrGA_ConstMemo'

[INTRODUCTION:]

THE SOURCE SODE INCLUDES THREE PARTS:
    (1) THE CNRGA SOURCE CODE AND ITS MODIFICATION
        1.1 BSPTREE_INITILIZATION.M
        1.2 BSPTREE_INSERTION.M
        1.3 BSPTREE_SEARCH_NODE.M
    (2) THE IMPLEMENTATION OF TWO PRUNING STRATEGIES
        2.1 ALL THE FILES INSIDE FOLDER 'PRUNING'
        2.2 FIND_SIBLING.M
    (3) THE CEC 2013 BENCHMARK TEST SUITE
        3.1 ALL THE FILES INSIDE FOLDER 'INPUT_DATA'
        3.2 CEC13_FUNC.CPP
        PLEASE USE MEX WHEN USING IT THE FIRST TIME
        DETAILS ARE BELOW OR SEE CEC13_FUNC.CPP
       	/*
          CEC13 Test Function Suite 
          Jane Jing Liang (email: liangjing@zzu.edu.cn) 
          14th Feb. 2013
          1. Run the following command in Matlab window:
          mex cec13_func.cpp -DWINDOWS
          2. Then you can use the test functions as the following example:
          f = cec13_func(x,func_num); 
          Here x is a D*pop_size matrix.
        */

[EXAMPLE:]

--

>> cNrGA_ConstMemo
Input the Following data: 
Prune Strategy [1(cNrGA) 2(cNrGA/CM/LRU) 3(cNrGA/CM/R)]:       	2
Number of Independent Runs:                                     10
ID of Problem (1~28):                                           22
Maximum Number of Evaluations (e.g. 40000):                     60000
Memory Threshold (e.g. 10000):                                  10000
Do you want to save the BSP_Tree(s) (y/n)?                      n
--

THEN, THE SCREEN WILL DISPLAY:

--
>> CEC 2013 Func.22, Max_FEs:60000, Memory Threshold(MT):10000, Run:1/10... 
>> Fitness found (run 1/10): 836.4179
>> CEC 2013 Func.22, Max_FEs:60000, Memory Threshold(MT):10000, Run:2/10... 
>> Fitness found (run 2/10): 922.8358
>> CEC 2013 Func.22, Max_FEs:60000, Memory Threshold(MT):10000, Run:3/10... 
>> Fitness found (run 3/10): 924.4146
>> CEC 2013 Func.22, Max_FEs:60000, Memory Threshold(MT):10000, Run:4/10... 
>> Fitness found (run 4/10): 915.6001
>> CEC 2013 Func.22, Max_FEs:60000, Memory Threshold(MT):10000, Run:5/10... 
>> Fitness found (run 5/10): 920.2304
>> CEC 2013 Func.22, Max_FEs:60000, Memory Threshold(MT):10000, Run:6/10... 
>> Fitness found (run 6/10): 927.938
>> CEC 2013 Func.22, Max_FEs:60000, Memory Threshold(MT):10000, Run:7/10... 
>> Fitness found (run 7/10): 1056.1238
>> CEC 2013 Func.22, Max_FEs:60000, Memory Threshold(MT):10000, Run:8/10... 
>> Fitness found (run 8/10): 916.4388
>> CEC 2013 Func.22, Max_FEs:60000, Memory Threshold(MT):10000, Run:9/10... 
>> Fitness found (run 9/10): 912.912
>> CEC 2013 Func.22, Max_FEs:60000, Memory Threshold(MT):10000, Run:10/10... 
>> Fitness found (run 10/10): 929.255

--

NOTE THAT THE RESULTS CAN BE FOUND IN THE VARIABLE NAMED "OUTPUT_FITNESS"

--
Save the Results(y/n)?                                          y

--

IF INPUT 'Y/y', ALL THE RELATED VARIABLES WILL BE SAVED,
OTHERWISE, YOU CAN FIND THEM ON WORKSPACE BEFORE 'CLEAR' OR 'EXIT'.

--


THE FOLLOWING FILES AND FOLDER ARE FOR THE CEC2013 TEST FUNCTION SUITE:

    1) FOLDER NAMED "INPUT_DATA"
    2) CEC13_FUNC.CPP
    3) CEC13_FUNC.MEXW32/64 (IF ANY)

THE AUTHORS OF NON-REVISITING GA (WITH CONSTANT MEMORY) USE THESE FILES
FOR COMPARISON WITHOUT ANY MODIFICATION.

FOR MORE INFORMATION ABOUT CEC2013 TEST FUNCTION SUITE, PLEASE CONTACT

/*
  CEC13 TEST FUNCTION SUITE 
  JANE JING LIANG (EMAIL: LIANGJING@ZZU.EDU.CN) 
  14TH FEB. 2013
*/