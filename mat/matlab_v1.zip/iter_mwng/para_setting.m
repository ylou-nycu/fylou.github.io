% PARAMETER SETTING %

function [TEN, MAXN, MAX_ITER,  INTERVAL] = para_setting(NC, POP_SIZE)

    TEN = 10;
    MAXN = 5000 * ones(NC,1);
    
    if POP_SIZE <= 500
        MAX_ITER = 1E6;
        INTERVAL = 5E2;
    elseif POP_SIZE > 500 && POP_SIZE <= 800
        MAX_ITER = 1E7;
        INTERVAL = 1E3;
    elseif POP_SIZE > 800 %% && POP_SIZE <= 1000
        MAX_ITER = 1E8;
        INTERVAL = 1E3;
    end
    
end

