

function [rule_opr, rule, n] = init_rules(disp_flag, word_class, str, n, m)

% n: NUMBER OF RULES        %
% m: SIZE OF RULES(IF ANY)	%

    rule_opr = cell(1, n);
    rule = 1 : n;
    if nargin == 4
        switch str
            case 'rnd'     % ALL RAND %
                len = randi(word_class - 1, [n, 1]) + 1;     % ENSURE THAT NO RULE IS OF LENGTH 1 %
                for idx = 1 : n
                    tmp = randperm(n);
                    for jdx = 1 : len(idx)
                        rule_opr{1, idx} = [rule_opr{1, idx}, int2str(tmp(jdx))];
                    end
                end
            case 'def'
                disp([int2str(n), ' rules, with each no longer than, and NO words limit: ']);
                for idx = 1 : n
                    rule_opr{1, idx} = input('Input the rules: ', 's');  % DEFINED BY USER %
                end
        end
        
    elseif nargin == 5
        if m > n
            error('impossible ...');
        end
        switch str
            case 'rnd'     % RAND WORD, BUT FIXED LENGTH %
                for idx = 1 : n
                    tmp = randperm(n);
                    for jdx = 1 : m
                        rule_opr{1, idx} = [rule_opr{1, idx}, int2str(tmp(jdx))];
                    end
                end
            case 'def'
                disp([int2str(n), ' rules, with each no longer than, ' int2str(m), ' words: ']);
                for idx = 1 : n
                    rule_opr{1, idx} = input('Input the rules: ', 's');  % DEFINED BY USER %
                end
        end
    end
    
    if disp_flag
        for idx = 1 : n
            disp(['''', rule_opr{1, idx}, '''']);
        end
    end
    
end