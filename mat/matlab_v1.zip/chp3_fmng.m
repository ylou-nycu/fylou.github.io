% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% Ref: W.X. Wang, B.Y. Lin, C.L. Tang, and G.R. Chen. "Agreement
% Dynamics of Inite-memory Language Games on Networks,"
% Eur Phys J B, 60(4):529-536, 2007. doi:10.1140/epjb/e2008-00013-5.
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% Chapter 3 Finite-Memory Naming Game
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% Matlab code by: Yang (Felix) Lou (felix.lou@my.cityu.edu.hk)
% updated: 01-09-2018
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

clear;  %clc;
global NGSet;   % naming game setting
global NetSet;  % network setting
NGSet.maxIter = 1E7;
NGSet.itv = NGSet.maxIter/1E3;
NGSet.memo.flag = 'lmt';  %% {'inf';'lmt'}
NGSet.strategy = 'dir';
addpath('net')  % for network generation
NET = {'RG';'SF';'SW';};

disp(' --- Running Finite-Memory Naming Game --- ')
disp('please input the following parameters for simulation ... ')
disp('1. Underlying network type (choose 1,2,3): ')
s = input('   [1] Rand-Graph; [2] Scale-Free; [3] Small-World: ');
while s~=1 && s~=2 && s~=3
    s = input('input 1,2,3: ');
end
NetSet.name = NET{s};
setK = input('2. Approximate average degree <k> (e.g., 20): ');
while mod(setK,1)
    setK = input('<k> should be an integer: ');
end
N = input('3. Population size N (e.g., 1000): ');
while mod(N,1)
    N = input('<k> should be an integer: ');
end
NetSet.n = N;
N = input('4. Memory length (e.g., 4): ');
while mod(N,1)
    N = input('should be an integer: ');
end
NGSet.memo.len = N;

NGSet.memo.ovr = 'lst';  %% Overflow Strategy {'lts';'uni'}
% 'lst' - the last one has 50% to be discarded
% 'uni' - uniform
% see Fig 3.2 for more detail

Rept = 1;  %% take the average of Rept runs, to filter out randomness
switch s
    case 1  %% Rand Graph
        Paras_RG.p = setK./NetSet.n;
        Paras_RG.N = length(Paras_RG.p);
        Paras_RG.p_rg = Paras_RG.p;
        for i=1:Paras_RG.N
            tmp = num2str(Paras_RG.p(i)*100);
            if ~isempty(find(tmp=='.',1));  tmp(find(tmp=='.'))='_';  end
            Paras_RG.name{i} = ['rg',tmp];
            r = 1;
            while r<=Rept
                [ak,apl,acc] = gen_net('rg',NetSet.n,Paras_RG);
                it = fmng(Paras_RG);
                if it==NGSet.maxIter
                    NGSet.maxIter = floor(NGSet.maxIter*1.25);
                    r = r-1;
                elseif it<NGSet.maxIter/2
                    NGSet.maxIter = floor(NGSet.maxIter*.75);
                end
                r = r+1;
            end
        end
    case 2  %% Scale Free
        Paras_SF.n = floor(setK./2);
        Paras_SF.N = length(Paras_SF.n);
        Paras_SF.n_sf = Paras_SF.n;
        for i=1:Paras_SF.N
            Paras_SF.name{i} = ['sf',int2str(Paras_SF.n(i))];
        end
        for i=1:Paras_SF.N
            r = 1;
            while r<=Rept
                [ak,apl,acc] = gen_net('sf',NetSet.n,Paras_SF);
                it = fmng(Paras_SF);
                if it==NGSet.maxIter
                    NGSet.maxIter = floor(NGSet.maxIter*1.25);
                    r = r-1;
                elseif it<NGSet.maxIter/2
                    NGSet.maxIter = floor(NGSet.maxIter*.75);
                end
                r = r+1;
            end
        end
    case 3  %% Small World
        Paras_SW.k = floor(setK./2);	%% neighbors
        Paras_SW.p = [0.2;];            %% re-wiering prob = {0.1; 0.2}
        Paras_SW.Nk = length(Paras_SW.k);
        Paras_SW.Np = length(Paras_SW.p);
        Paras_SW.p_sw = Paras_SW.p;
        Paras_SW.k_sw = Paras_SW.k;
        % ----- Get Paras_SW.namek and Paras_SW.namep, respectively ----- %
        for i=1:Paras_SW.Nk
            Paras_SW.namek{i} = ['swk',num2str(Paras_SW.k(i))];
        end
        for i=1:Paras_SW.Np
            tmp = num2str(Paras_SW.p(i));
            if ~isempty(find(tmp=='.',1))
                tmp(find(tmp=='.'))='_';
            end
            Paras_SW.namep{i} = ['p',tmp];
        end
        % ----- Get Paras_SW.namek and Paras_SW.namep, respectively ----- %
        for i=1:Paras_SW.Nk
            for j=1:1:Paras_SW.Np
                r = 1;
                while r<=Rept
                    [ak,apl,acc] = gen_net('sw',NetSet.n,Paras_SW);
                    it = fmng(Paras_SW);
                    if it==NGSet.maxIter
                        NGSet.maxIter = floor(NGSet.maxIter*1.25);
                        r = r-1;
                    elseif it<NGSet.maxIter/2
                        NGSet.maxIter = floor(NGSet.maxIter*.75);
                    end
                    r = r+1;
                end
            end
        end
end

