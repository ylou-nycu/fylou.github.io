% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% Ref: Y. Gao, G.R. Chen, and R.H.M. Chan. Naming game on networks:
% Let everyone be both speaker and hearer. Sci Rep,
% 4:6149, 2014. doi:10.1038/srep06149.
% -----  -----  -----  -----  -----  -----  -----  -----  -----
% Chapter 6 Naming Game on Multi-Community Networks
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% Matlab code by: Yang (Felix) Lou (felix.lou@my.cityu.edu.hk)
% updated: 01-09-2018
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

clear;  %clc;

global IN;
IN.r = 1;   % number of repeated runs

addpath('net')
addpath('iter_mwng')
disp(' --- Running Multi-Word Naming Game --- ')
disp('Please input the following parameters for simulation ... ')
disp('1. Choose the Pattern:')
disp('[1] basic English pattern; [2] man-designed pattern')
IN.pattern = input('Input 1 or 2? ');
while IN.pattern ~= 1 && IN.pattern ~= 2
    IN.pattern = input('input 1 or 2 only: ');
end
if IN.pattern == 2
    disp([int2str(IN.pattern),'. (See Fig 7.11 for details about the 5 man-designed patterns.)'])
    IN.ptid = input('Input 1~5 to choose a man-designed pattern: ');
    while IN.ptid < 1 || IN.ptid > 5
        IN.ptid = input('input a correct number within 1~5:');
    end
else
    IN.ptid = 0;
end
IN.n = input([int2str(IN.pattern+1),'. Population size (e.g. 500): ']);

disp([int2str(IN.pattern+2),'. Input network type: '])
disp('| 1. RG/0.03   || 2. RG/0.05   || 3. RG/0.1    |')
disp('| 4. SW/20/0.1 || 5. SW/20/0.2 || 6. SW/20/0.3 |')
disp('| 7. SW/40/0.1 || 8. SW/40/0.2 || 9. SW/40/0.3 |')
disp('| 10. SF/25    || 11. SF/50    || 12. SF/75    |')
IN.net = input('Choose the network (1~12): ');
while IN.net > 12 || IN.net < 1 || mod(IN.net,1)
    IN.net = input('choose a correct network ID (1~12): ');
end

% disp('Plot the converging curves or not? ')
% s = input('Y/N?  ','s');
% % while ~strcmp(s,'Y')&&~strcmp(s,'N')&&~strcmp(s,'y')&&~strcmp(s,'n')
% %     s = input('Input ''Y''/''N''?  ','s');
% % end
% switch s
%     case {'Y','y'}
%         IN.plot_flag = 1;
%     otherwise  %%case {'N','n'}
%         IN.plot_flag = 0;
% end

if IN.pattern == 1
    basic;      %% Basic Patterns
elseif IN.pattern == 2
    designed;	%% Man-Designed Patterns
else
    error('Choose a correct pattern ID, 1 or 2?')
end