% Naming Game in Groups
% updated: 31-08-2018 

function [cTime] = ngg(para)
global NGSet;
global NetSet;
global A;

    Lcw = floor(para.beta*(NGSet.nh+1));
    TEN = 10;
    maxMsg = 1E10;  %% 'msg' = message
    % ----- Initialization ----- %
    cLen = floor(NGSet.maxIter / NGSet.itv); 
    nTotl = zeros(cLen,1);  %% # Total names - a curve
    nDiff = zeros(cLen,1);  %% # Different names - a curve
    sRate = zeros(cLen,1);  %% Success rate - a curve
    cTime = NGSet.maxIter;
    disp('-----  -----  -----  -----  -----  ')
    disp(['Current Network = ',     num2str(NetSet.name)])
    disp(['Population Size = ',     num2str(NetSet.n)])  %% NetSet.n == NGSet.n, the same thing
    disp(['Max # Iteration = ',     num2str(NGSet.maxIter)])
    disp('-----  -----  -----  -----  -----  ')
    node   = cell(NetSet.n,1);
    lenU   = zeros(NetSet.n,1);	%% Length of memory used in each node
    isCons = zeros(NetSet.n,1);	%% Is consensus? (Yes=1;No=0)
    sCnt   = zeros(TEN,1);      %% Success_time(sCnt) / Last_TEN_times
    cnt  = 1;	%% Counter for all (real) Iteration
    cntFake = 1;	%% Iteration counter - "Speaker to multiple hearers" as one iteration
    smpCnt = 0;	%% Counter for (sampled) Iteration, smpCnt = cnt / NGSet.itv
    
    while cnt < NGSet.maxIter
        idx = randi(NetSet.n);
        neb_arr = find(A(idx,:));
        if isempty(neb_arr);  error('The graph is not conneted ... ');  end  %% Just in case, probably NOT happen
        % --- Find 'NGSet.nh' hearers --- %
        hLen = min(NGSet.nh,length(neb_arr));  %% hLen = number of hearers, may not as many as NGSet.nh
        jdx = neb_arr(randi(length(neb_arr),[hLen,1]));
        % --- form the Group with GS members --- %
        idx = [idx,jdx];	%% the group G
        gs  = length(idx);	%% group size
        % ----- Eqs.(1,2) ----- %
        Ip = zeros(gs,gs);
        In = zeros(gs,1);
        for i=1:gs-1
            for j=i+1:gs
                Ip(i,j) = A(idx(i),idx(j)) + (~A(idx(i),idx(j)))*0.5;
                Ip(j,i) = Ip(i,j);
            end
            %%Ip(i,i) = 0;
            In(i,1) = sum(Ip(i,:));
        end
        In(gs,1) = sum(Ip(gs,:));
        % ----- End Eqs.(1,2) ----- %
        cw = [];  %% CW: everyone contributes a word
                  % .name = name
                  % .ctbt = contributor
        % ----- Following collect gs names ----- %
        for i = 1:gs
            if lenU(idx(i))  %% Pick up a name
                msg = node{idx(i),1}(randi(lenU(idx(i))));
            else  %% Create a name
                node{idx(i),1}(1) = randi(maxMsg);
                lenU(idx(i)) = 1;
                msg = node{idx(i),1}(1);
            end
            if isempty(cw)
                v.name = msg;  v.ctbt = idx(i);  v.ctbtin = i;
                cw = v;
            else
                sameFlg = 0;
                for j=1:length(cw)
                    if msg == cw(j).name
                        cw(j).ctbt = [cw(j).ctbt;idx(i)];
                        cw(j).ctbtin = [cw(j).ctbtin;i];
                        sameFlg = 1;
                    end
                end
                if ~sameFlg
                    v.name = msg;  v.ctbt = idx(i);  v.ctbtin = i;
                    cw = [cw;v];
                end
            end
        end
        % ----- End gs names collected ----- %
        % ----- Eq.(3) ----- %
        L1 = length(cw);
        Iw = zeros(L1,1);
        for i=1:L1
            Iw(i) = sum(In(cw(i).ctbtin));
        end
        % ----- End Eq.(3) ----- %
        Pw = Iw./sum(Iw);  %% Eq.(4)
        Lw = min(Lcw,L1);
        cw = sortCw(cw,Pw,Lw);  %% a shortened word list is constructed
        
        uc = idx;  %% the un-consented individuals
        %%if length(uc)~=gs;  error('check here ...');  end;
        for i = 1:Lw
            sCnt(2:TEN,1)=sCnt(1:TEN-1,1);
            msg = cw(i).name;
            spkList = cw(i).ctbt;  %% Speaker(s) of 'cw(i).name'
            nspk = length(spkList);
            sc = [];   %% the consented individuals
            ct = 0;    %% consensus counter
            for ii = 1:gs  %% Hearers
                if uc(ii)~=inf
                    for jj = 1:nspk
                        if A(uc(ii),spkList(jj)) || rand<0.5  %% Connected or 0.5
                            if isempty(find(node{uc(ii),1}==msg,1))  %% Hearer has no Speaker's msg
                                if lenU(uc(ii)) == NGSet.memo.len
                                    mLost(uc(ii)) = mLost(uc(ii))+1;
                                    switch NGSet.memo.ovr
                                        case 'uni'  %% uniformly discard one
                                            tmpi = randi(NGSet.memo.len+1)-1;
                                            if tmpi
                                                node{uc(ii),1}(tmpi) = msg;
                                            end  %% Else, discard 'msg'
                                        case 'lst'  %% discard the last one
                                            if rand<0.5
                                                node{uc(ii),1}(randi(NGSet.memo.len)) = msg;
                                            end
                                    end
                                elseif lenU(uc(ii)) > NGSet.memo.len
                                    error('check your program ... ')  %% Generally impossible, just in case ...
                                else
                                    node{uc(ii),1} = [node{uc(ii),1};msg];
                                    lenU(uc(ii),1) = lenU(uc(ii),1)+1;  %% Length of node(jdx(h)) plus 1
                                end
                                isCons(uc(ii),1) = 0;  %% Not consented
                                sCnt(1,1) = 0;  %% Success counter +0
                            else  %% Consensus
                                isCons(uc(ii),1) = 1;
                                node{uc(ii),1} = msg;
                                lenU(uc(ii),1) = 1;  %% Length of node(uc(ii)) reset to 1
                                sCnt(1,1) = 1;
                                sc = [sc;uc(ii)];
                                uc(ii) = inf;  %% 'uc'&'idx' are identical initially
                                ct = ct+1;
                                break;
                            end
                        else  %% not be a hearer
                            %%-Nothing happens
                        end
                    end  %% End-for-HearerList
                end
            end  %% End-for-SpeakerList
            for k = 1:length(sc)
                cp = ct/gs;
                if rand < cp && sc(k)~=inf
                    isCons(sc(k),1) = 1;
                    node{sc(k),1} = msg;
                    lenU(sc(k),1) = 1;  %% Length of node(uc(ii)) reset to 1
                    sCnt(1,1) = 1;
                end
            end
        end  %% End-for wc(wdx)
        % -----  -----  -----  -----  -----  -----  -----  -----  ----- %
        
        % ----- Calculate features ----- %
        if mod(cnt,NGSet.itv)<NGSet.nh
            smpCnt = smpCnt+1;
            nTotl(smpCnt,1) = sum(lenU);  %% # Total names
            tmp_dif = [];
            for i=1:NetSet.n
                tmp_dif = [tmp_dif;node{i,1}];
            end
            nDiff(smpCnt,1) = length(unique(tmp_dif));  %% # Different names
            sRate(smpCnt,1) = sum(sCnt)/TEN;  %% Success rate
            clear tmp_dif
        end
        % ----- End of Calculate features ----- %
        
        % ----- Test convergence ----- %
        conv_flag = 1;
        if sum(isCons)~=NetSet.n || sum(lenU)~=NetSet.n
            conv_flag=0;
        else
            for i=2:NetSet.n
                if node{i-1,1}(1,1)~=node{i,1}(1,1)
                    conv_flag = 0;
                    break;
                end
            end
        end
        if conv_flag
            smpCnt = smpCnt+1;
            nTotl(smpCnt,1) = sum(lenU);  %% # Total names
            tmp_dif = [];
            for i=1:NetSet.n
                tmp_dif = [tmp_dif,node{i,1}];
            end
            nDiff(smpCnt,1) = length(unique(tmp_dif));  %% # Different names
            if nDiff(smpCnt,1)>1;
                nDiff(smpCnt,1)
                error('Check ...');
            end
            sRate(smpCnt,1) = sum(sCnt)/TEN;  %% Success rate
            clear tmp_dif
            
            nTotl(smpCnt+1:cLen) = [];  %%nTotl(smpCnt,1);
            nDiff(smpCnt+1:cLen) = [];  %%nDiff(smpCnt,1);
            sRate(smpCnt+1:cLen) = [];  %%sRate(smpCnt,1);
            cTime = cnt;
            break;  %% End of Game Loop
        end
        % ----- End of Test convergence ----- %
        
        cnt = cnt+hLen;         %% Operation
        cntFake = cntFake+1;	%% Iteration
        if mod(cnt,1E4)<NGSet.nh;  disp(['iter - ',int2str(cnt)]);  end
    end  %% End-of-While-cnt ...
    if conv_flag
        disp(['Converged at interation ',int2str(cnt),'. '])
    else
        disp('Not converged ... ')
    end
    disp(' ');
    
    fname = ['NGG_GS',int2str(NGSet.nh+1),'_Net',NetSet.name];
    save(fname,'NGSet','NetSet','nTotl','nDiff','sRate','cTime','para')
    
    function  cws_ = sortCw(cw_,Pw_,Lw_)
        % .name
        % .ctbt
        [~,pos] = sort(Pw_,'descend');
        cws_ = cw_(pos(1:Lw_));
    end

end

