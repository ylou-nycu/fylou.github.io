% nw_small_world
% updated 31-08-2018

function [A, disc] = nw(N, rp, K)
    A = zeros(N,N);
    disc = 0;
    if K>floor(N/2);  error('Illegal input of K ... ');  end
    
    % STEP1: RING SHAPED NETWORK
    for idx = 1:N
        for jdx = (idx+1):(idx+K)
            jj = jdx;
            if jdx > N
                jj = mod(jdx,N);
            end
            A(idx,jj) = 1;
            A(jj,idx) = 1;
        end
    end
    % STEP2: REWIRING ... %
    nodes = 1:N;
    pair_nodes = nchoosek(nodes,2);
    n_tri = length(pair_nodes);
    for i = 1:n_tri
        if rand < rp
            A(pair_nodes(i,1),pair_nodes(i,2)) = 1;
            A(pair_nodes(i,2),pair_nodes(i,1)) = 1;
        end
    end
    
    if ~isempty(find(~sum(A,2),1))
        disc = 1;
    end
end