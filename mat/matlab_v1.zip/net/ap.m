% average_path_length
% updated: 31-08-2018

function ad = ap(A)
% input: adjacency matrix
% Get the distances of any pair of nodes using 'Floyd algorithm', and get it averaged %

    N = size(A,2);
    D = A;
    D(D==0) = inf;
    for i = 1:N
        D(i,i) = 0;
    end
    
    for k = 1:N
        for i = 1:N
            for j = 1:N
                if D(i,j) > D(i,k) + D(k,j)
                    D(i,j) = D(i,k) + D(k,j);
                end
            end
        end
    end
    ad = sum(sum(D)) / (N*(N-1));
    if ad == inf
        %error('The network is NOT connected ... ');
        disp('The network is NOT connected ... ');
    end
end

