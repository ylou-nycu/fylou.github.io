
function [avg_degree, avg_path_length, avg_cc] = gen_net_mlw(net_type, avg_degree, avg_path_length, avg_cc, mlw_para)

    global A;
    switch net_type
        case 1
            NET_CLASS = 1;  % NET_CLASS: 1.RAND-GRAPH, 2.SMALL-WORLD, 3.SCALE-FREE %
            RAND_GRAPH_P = 0.03;
            disp(['~ Random_Graph_Network, P = ', num2str(RAND_GRAPH_P)]);
        case 2
            NET_CLASS = 1;
            RAND_GRAPH_P = 0.05;
            disp(['~ Random_Graph_Network, P = ', num2str(RAND_GRAPH_P)]);
        case 3
            NET_CLASS = 1;
            RAND_GRAPH_P = 0.1;
            disp(['~ Random_Graph_Network, P = ', num2str(RAND_GRAPH_P)]);
        case 4
            NET_CLASS = 2;
            SMALL_WORD_RP = 0.1;
            SMALL_WORD_K = 20;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
        case 5
            NET_CLASS = 2;
            SMALL_WORD_RP = 0.2;
            SMALL_WORD_K = 20;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
        case 6
            NET_CLASS = 2;
            SMALL_WORD_RP = 0.3;
            SMALL_WORD_K = 20;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
        case 7
            NET_CLASS = 2;
            SMALL_WORD_RP = 0.1;
            SMALL_WORD_K = 40;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
        case 8
            NET_CLASS = 2;
            SMALL_WORD_RP = 0.2;
            SMALL_WORD_K = 40;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
        case 9
            NET_CLASS = 2;
            SMALL_WORD_RP = 0.3;
            SMALL_WORD_K = 40;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
        case 10
            NET_CLASS = 3;
            SCALE_FREE_INIT_NODE = 26;
            SCALE_FREE_NEW_EDGE = SCALE_FREE_INIT_NODE - 1;
            disp(['~ BA_Scale_Free_Network, Initial Nodes = ', num2str(SCALE_FREE_INIT_NODE), ...
                ', and New Edges Each Step = ', num2str(SCALE_FREE_NEW_EDGE)]);
        case 11
            NET_CLASS = 3;
            SCALE_FREE_INIT_NODE = 51;
            SCALE_FREE_NEW_EDGE = SCALE_FREE_INIT_NODE - 1;
            disp(['~ BA_Scale_Free_Network, Initial Nodes = ', num2str(SCALE_FREE_INIT_NODE), ...
                ', and New Edges Each Step = ', num2str(SCALE_FREE_NEW_EDGE)]);
        case 12
            NET_CLASS = 3;
            SCALE_FREE_INIT_NODE = 76;
            SCALE_FREE_NEW_EDGE = SCALE_FREE_INIT_NODE - 1;
            disp(['~ BA_Scale_Free_Network, Initial Nodes = ', num2str(SCALE_FREE_INIT_NODE), ...
                ', and New Edges Each Step = ', num2str(SCALE_FREE_NEW_EDGE)]);
            
        case 20  % 'mlw': Multi-Local-World Network
            NET_CLASS = 4;
            disp('~ Multi-Local-World Network')
            disp(['# of Total Nodes = ', num2str(mlw_para.N)])
            disp(['# of Local-Worlds = ', num2str(mlw_para.LW)])
            disp(['# of Nodes per Local-Worlds = ', num2str(mlw_para.LN)]);
    end
    
    % GENERATING OF NETWORKS %
    switch NET_CLASS 
        case 1  %% Rand Graph
            [A, avg_deg, avg_pl, avg_cce, dis] = rg(N, RAND_GRAPH_P);
            if dis
                tmp_cnt = 10;
                while dis == 1 && tmp_cnt  % AT THE MOST RE-GENERATE NETWORK TEN TIMES %
                    [A, avg_deg, avg_pl, avg_cce, dis] = rg(N, RAND_GRAPH_P);
                    tmp_cnt = tmp_cnt - 1;
                end
            end
            avg_degree = avg_degree  + avg_deg;
            avg_path_length  = avg_path_length  + avg_pl;
            avg_cc  = avg_cc  + avg_cce;
        case 2  %% Small World
            [A, avg_deg, avg_pl, avg_cce, dis] = sw(N, SMALL_WORD_RP, SMALL_WORD_K);
            if dis
                tmp_cnt = 10;
                while dis == 1 && tmp_cnt  % AT THE MOST RE-GENERATE NETWORK TEN TIMES %
                    [A, avg_deg, avg_pl, avg_cce, dis] = sw(N, SMALL_WORD_RP, SMALL_WORD_K);
                    tmp_cnt = tmp_cnt - 1;
                end
            end
            avg_degree(net_idx, 1) = avg_degree(net_idx, 1) + avg_deg;
            avg_path_length(net_idx, 1) = avg_path_length(net_idx, 1) + avg_pl;
            avg_cc  = avg_cc  + avg_cce;
        case 3  %% Scale Free
            [A, avg_deg, avg_pl, avg_cce, dis] = sf(N, SCALE_FREE_INIT_NODE, SCALE_FREE_NEW_EDGE);
            if dis
                tmp_cnt = 10;
                while dis == 1 && tmp_cnt  % AT THE MOST RE-GENERATE NETWORK TEN TIMES %
                    [A, avg_deg, avg_pl, avg_cce, dis] = sf(N, SCALE_FREE_INIT_NODE, SCALE_FREE_NEW_EDGE);
                    tmp_cnt = tmp_cnt - 1;
                end
            end
            avg_degree  = avg_degree  + avg_deg;
            avg_path_length  = avg_path_length  + avg_pl;
            avg_cc  = avg_cc  + avg_cce;        
        case 4  %% 
            % AdjacentMat = mlw(NetSize, #of_LWs, #Nodes_per_LW); %
            [A] = mlw(mlw_para.N, mlw_para.LW, mlw_para.LN);
            avg_deg	= sum(sum(A))/mlw_para.N;
            avg_pl  = ap(A);
            avg_cce = cc(A);
            avg_degree  = avg_degree  + avg_deg;
            avg_path_length  = avg_path_length  + avg_pl;
            avg_cc  = avg_cc  + avg_cce;
        otherwise
            error('Wrong Network Type (NET_CLASS) ...');
    end
    disp('Graph Construced ...');
            
end