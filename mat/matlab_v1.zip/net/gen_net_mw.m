
function [avg_degree, avg_path_length, avg_cc] = gen_net_mw(net_type, avg_degree, avg_path_length, avg_cc, N)

global A;

    switch net_type
        case 1
            NET_TYPE = 1;
            RAND_GRAPH_P = 0.03;
            disp(['~ Random_Graph_Network, P = ', num2str(RAND_GRAPH_P)]);
% %             RAND_GRAPH_P = 0.03;
% %             disp(['~ Random_Graph_Network, P = ', num2str(RAND_GRAPH_P)]);
        case 2
            NET_TYPE = 1;
            RAND_GRAPH_P = 0.05;
            disp(['~ Random_Graph_Network, P = ', num2str(RAND_GRAPH_P)]);
        case 3
            NET_TYPE = 1;
            RAND_GRAPH_P = 0.1;
            disp(['~ Random_Graph_Network, P = ', num2str(RAND_GRAPH_P)]);
        case 4
            NET_TYPE = 2;
            SMALL_WORD_RP = 0.1;
            SMALL_WORD_K = 50;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
        case 5
            NET_TYPE = 2;
            SMALL_WORD_RP = 0.2;
            SMALL_WORD_K = 50;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
        case 6
            NET_TYPE = 2;
            SMALL_WORD_RP = 0.3;
            SMALL_WORD_K = 50;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
        case 7
            NET_TYPE = 2;
            SMALL_WORD_RP = 0.1;
            SMALL_WORD_K = 60;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
        case 8
            NET_TYPE = 2;
            SMALL_WORD_RP = 0.2;
            SMALL_WORD_K = 60;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
        case 9
            NET_TYPE = 2;
            SMALL_WORD_RP = 0.3;
            SMALL_WORD_K = 60;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
        case 10
            NET_TYPE = 3;
            SCALE_FREE_INIT_NODE = 26;
            SCALE_FREE_NEW_EDGE = SCALE_FREE_INIT_NODE - 1;
            disp(['~ BA_Scale_Free_Network, Initial Nodes = ', num2str(SCALE_FREE_INIT_NODE), ...
                ', and New Edges Each Step = ', num2str(SCALE_FREE_NEW_EDGE)]);
        case 11
            NET_TYPE = 3;
            SCALE_FREE_INIT_NODE = 51;
            SCALE_FREE_NEW_EDGE = SCALE_FREE_INIT_NODE - 1;
            disp(['~ BA_Scale_Free_Network, Initial Nodes = ', num2str(SCALE_FREE_INIT_NODE), ...
                ', and New Edges Each Step = ', num2str(SCALE_FREE_NEW_EDGE)]);
        case 12
            NET_TYPE = 3;
            SCALE_FREE_INIT_NODE = 76;
            SCALE_FREE_NEW_EDGE = SCALE_FREE_INIT_NODE - 1;
            disp(['~ BA_Scale_Free_Network, Initial Nodes = ', num2str(SCALE_FREE_INIT_NODE), ...
                ', and New Edges Each Step = ', num2str(SCALE_FREE_NEW_EDGE)]);
    
    end
    
    % GENERATING OF NETWORKS %
            if NET_TYPE == 1
                [A, avg_deg, avg_pl, avg_cce, dis] = rg(N, RAND_GRAPH_P);
                if dis
                    tmp_cnt = 10;
                    while dis == 1 && tmp_cnt  % AT THE MOST RE-GENERATE NETWORK TEN TIMES %
                        [A, avg_deg, avg_pl, avg_cce, dis] = rg(N, RAND_GRAPH_P);
                        tmp_cnt = tmp_cnt - 1;
                    end
                end
                avg_degree  = avg_degree + avg_deg;
                avg_path_length  = avg_path_length + avg_pl;
                avg_cc  = avg_cc + avg_cce;
            elseif NET_TYPE == 2
                [A, avg_deg, avg_pl, avg_cce, dis] = sw(N, SMALL_WORD_RP, SMALL_WORD_K);
                if dis
                    tmp_cnt = 10;
                    while dis == 1 && tmp_cnt  % AT THE MOST RE-GENERATE NETWORK TEN TIMES %
                        [A, avg_deg, avg_pl, avg_cce, dis] = sw(N, SMALL_WORD_RP, SMALL_WORD_K);
                        tmp_cnt = tmp_cnt - 1;
                    end
                end
                avg_degree = avg_degree + avg_deg;
                avg_path_length = avg_path_length + avg_pl;
                avg_cc  = avg_cc + avg_cce;
            elseif NET_TYPE == 3
                [A, avg_deg, avg_pl, avg_cce, dis] = sf(N, SCALE_FREE_INIT_NODE, SCALE_FREE_NEW_EDGE);
                if dis
                    tmp_cnt = 10;
                    while dis == 1 && tmp_cnt  % AT THE MOST RE-GENERATE NETWORK TEN TIMES %
                        [A, avg_deg, avg_pl, avg_cce, dis] = sf(N, SCALE_FREE_INIT_NODE, SCALE_FREE_NEW_EDGE);
                        tmp_cnt = tmp_cnt - 1;
                    end
                end
                avg_degree  = avg_degree + avg_deg;
                avg_path_length  = avg_path_length + avg_pl;
                avg_cc  = avg_cc + avg_cce;
            else
                error('wrong network type (NET_TYPE) ...');
            end
            disp('graph is construced ...');
            
end