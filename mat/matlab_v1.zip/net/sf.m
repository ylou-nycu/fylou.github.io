% scale_free
% updated 31-08-2018

function [A,ak,apl,acc, disc] = sf(N,n0,em)
% input:  n0 - initial number of nodes
%         em - number of edges added per gen.

    disc = 0;
    net0 = ones(n0,n0) - diag(ones(1,n0),0);
    A = zeros(N,N);
    A(1:n0,1:n0) = net0;
    sumlinks = sum(sum(A));
    
    cur_idx = n0;
    while cur_idx < N
        cur_idx = cur_idx+1;
        linkage = 0;
        while linkage < em
            rnode = randi(cur_idx);
            deg	  = sum(A(:,rnode))*2;
            if (rand < (deg/sumlinks)) && (~A(cur_idx,rnode))
                A(cur_idx,rnode) = 1;
                A(rnode,cur_idx) = 1;
                linkage = linkage + 1;
                sumlinks = sumlinks + 2;
            end
        end
    end
    disc = 0;
    if ~isempty(find(~sum(A,2),1))
        disc = 1;
    end
    ak  = sum(sum(A))/N;
    apl = ap(A);
    acc = cc(A);
    
end

