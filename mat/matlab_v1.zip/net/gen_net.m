% generating_network
% updated: 31-08-2018

function [ak,apl,acc] = gen_net(net_type,N,para)
global A;  % to avoid matrix copy and paste ...
% Output:  ak  - average degree
%          apl - average path length
%          acc - average clustering coefficient
TEN = 10;  % See if cannot generate a connected graph in TEN trials

    switch net_type
        case {'er';'rg'}  %%  ER Rand Graph
            p_rg = para.p_rg;
            disp(['~ Random Graph Network, P = ', num2str(p_rg)]);
            [A,ak,apl,acc,dis] = rg(N,p_rg);
            if dis
                tmp_cnt = TEN;
                while dis && tmp_cnt  %% AT THE MOST RE-GENERATE NETWORK TEN TIMES %
                    [A,ak,apl,acc,dis] = random_graph(N,p_rg);
                    tmp_cnt = tmp_cnt-1;
                end
                if dis,  error(['Disconnected network even after ',int2str(TEN),' trials ...']);  end
            end
            
        case {'ws';'sw'}  %% WS Small World
            p_sw = para.p_sw;
            k_sw = para.k_sw;
            disp(['~ Small World (WS) Network, RP = ', num2str(p_sw), ', and K = ', num2str(k_sw)]);
            [A,ak,apl,acc,dis] = sw(N,p_sw,k_sw);
            if dis
                tmp_cnt = TEN;
                while dis && tmp_cnt  %% AT THE MOST RE-GENERATE NETWORK TEN TIMES %
                    [A,ak,apl,acc,dis] = ws_small_world(N,p_sw,k_sw);
                    tmp_cnt = tmp_cnt-1;
                end
                if dis,  error(['Disconnected network even after ',int2str(TEN),' trials ...']);  end
            end
            
        case {'ba';'sf'}  %% BA Scale Free
            n_sf = para.n_sf;	%% Initial number of Nodes
            e_sf = n_sf-1;      %% Number of Eages added each time
            disp(['~ BA Scale Free Network, Initial Nodes = ', num2str(n_sf), ...
                ', and New Edges Each Step = ', num2str(e_sf)]);
            [A,ak,apl,acc,dis] = sf(N,n_sf,e_sf);
            if dis
                tmp_cnt = TEN;
                while dis && tmp_cnt  %% AT THE MOST RE-GENERATE NETWORK TEN TIMES %
                    [A,ak,apl,acc,dis] = scale_free(N,n_sf,e_sf);
                    tmp_cnt = tmp_cnt-1;
                end
                if dis,  error(['Disconnected network even after ',int2str(TEN),' trials ...']);  end
            end
            
        case {'mlw'}  %% Multi-Local-World
            % AdjacentMat = mlw(NetSize, #of_LWs, #Nodes_per_LW); %
            lw_mlw = para.lw_mlw;  %% #of_LWs
            ln_mlw = para.ln_mlw;  %% #Nodes_per_LW
            disp(['~ Multi-Local-World, #Local Worlds = ', num2str(lw_mlw), ...
                ', and ', num2str(ln_mlw), ' Nodes per Local World']);
            [A] = mlw(N,lw_mlw,ln_mlw);
            ak	= sum(sum(A))/N;
            apl	= ap(A);
            acc	= cc(A);
            
        case {'full'}  %% Fully-connected
            A = ones(N,N);
            for idx = 1:N
                A(idx,idx) = 0;
            end
            ak = N-1;  apl = 1;  acc = 1;
    end
    disp('network construced ... ');

end

