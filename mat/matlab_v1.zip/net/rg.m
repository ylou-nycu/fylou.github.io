% random_graph
% updated 31-08-2018

function [A,ak,apl,acc,disc] = rg(N,p)

    A = zeros(N,N);
    disc = 0;  %% assuming it is connected
    for i = 1:(N-1)
        for j = (i+1):N
            if rand <= p && (~A(i,j))
                A(i,j) = 1; 
                A(j,i) = 1;
            end
        end
    end
    
    if ~isempty(find(~sum(A,2),1))
        disc = 1;
    end
    
    ak  = sum(sum(A))/N;
    apl = ap(A);
    acc = cc(A);
    
end

