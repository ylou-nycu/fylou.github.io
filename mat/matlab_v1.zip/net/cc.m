% clustering_coefficient
% updated: 31-08-2018

function  ac = cc(A)
% input: adjacency matrix

    N = size(A,1);
    C = zeros(N,1);
    
    for i = 1:N
        neb = find(A(i,:)==1);  %% find neighbors
        if isempty(neb)
            error('The network is NOT connected ... ');
        end
        m = length(neb);
        
        if m == 1
            C(i,1) = 0;
        else
            B = A(neb,neb);
            C(i,1) = length(find(B==1))/(m*(m-1));
        end
    end
    ac = mean(C);
end