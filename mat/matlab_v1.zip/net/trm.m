% triangular_random_model
% updated 01-09-2018

function [A,disc] = trm(N,n0,medge)

    A = zeros(N,N);
    A(1:n0,1:n0) = 1;
    for i = 1:n0
        A(i,i) = 0;
    end
    
    for i = (n0+1):N
        rand_list = randperm(i-1);
        rand_nodes = rand_list(1:medge);	%% randomly select medge nodes
        for j = 1:medge
            A(i,rand_nodes(j)) = 1;         %% add edges to the selected nodes
            A(rand_nodes(j),i) = 1;
            a = find(A(rand_nodes(j), :) == 1);
            len = length(a);
            if len
                j_neb = a(randi(len));      %% randomly select a node from the neighbors
                A(i,j_neb) = 1;
                A(j_neb,i) = 1;
            end
        end
    end
    
    disc = 0;
    if ~isempty(find(~sum(A,2),1))
        disc = 1;
    end
%     ak = sum(sum(A))/N;
%     % calculated ak
%     cal_ak = (n0*(n0-1)+4*2*medge*(N-n0))/N;

end


