% ws_small_world
% updated 31-08-2018

function [A,ak,apl,acc,disc] = sw(N,rp,K)

    disc = 0;
    if K > floor(N/2);  error('Illegal input of K ... ');  end
    A = zeros(N,N);
    
    % step1: to build the ring shaped network %
    for idx = 1:N
        for jdx = (idx+1):(idx+K)
            jj = jdx;
            if jdx > N;  jj = mod(jdx,N);  end
            A(idx,jj) = 1;
            A(jj,idx) = 1;
        end
    end
    % step2: rewiring ... %
    for idx = 1:N
        for jdx = (idx+1):(idx+K)
            jj = jdx;
            if jdx > N;  jj = mod(jdx,N);  end
            if rand < rp
                A(idx,jj) = 0;
                A(jj,idx) = 0;
                A(idx,idx) = inf;
                a = find(A(idx,:)==0);
                jjj = a(randi(length(a)));
                A(idx, jjj) = 1;
                A(jjj, idx) = 1;  %% rewiring
                A(idx, idx) = 0;
            end
        end
    end
    
    if ~isempty(find(~sum(A,2),1))
        disc = 1;
    end
    ak  = sum(sum(A))/N;
    apl = ap(A);
    acc = cc(A);

end

