% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% Ref: Y. Gao, G.R. Chen, and R.H.M. Chan. Naming game on networks:
% Let everyone be both speaker and hearer. Sci Rep,
% 4:6149, 2014. doi:10.1038/srep06149.
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% Chapter 4 Naming Game with Group Discussions
%           (Part B Naming Game in Groups)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% Matlab code by: Yang (Felix) Lou (felix.lou@my.cityu.edu.hk)
% updated: 01-09-2018
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

clear;  %clc;

global NGSet;
global NetSet;
NGSet.maxIter = 1E7;
NGSet.itv = NGSet.maxIter/1E3;
NGSet.memo.flag = 'inf';  %% {'inf';'lmt'}
NGSet.memo.len = inf;
NGSet.strategy = 'dir';
addpath('net')  % for network generation
NET = {'RG';'SF';'SW';};
beta = 0.5;	%% 0.1 ~ 1.0
Rept = 1;	%% take the average of Rept runs, to filter out randomness

disp(' --- Running Multi-Hearers Naming Game --- ')
disp('Please input the following parameters for simulation ... ')
disp('1. Underlying network type (choose 1,2,3): ')
s = input('   [1] Rand-Graph; [2] Scale-Free; [3] Small-World: ');
while s~=1 && s~=2 && s~=3
    s = input('input 1,2,3: ');
end
NetSet.name = NET{s};
setK = input('2. Approximate average degree <k> (e.g., 20): ');
while mod(setK,1)
    setK = input('<k> should be an integer: ');
end
N = input('3. Population size N (e.g., 1000): ');
while mod(N,1)
    N = input('<k> should be an integer: ');
end
NetSet.n = N;
N = input('4. Group size (GS) (e.g., 5): ');
while mod(N,1)
    N = input('should be an integer: ');
end
NGSet.nh = N-1;  %% Group Size, need add back a spealer, though everyone is spealer/hearer

switch s
    case 1  %% Rand Graph
        Paras_RG.beta = beta;
        Paras_RG.p = setK./NetSet.n;
        Paras_RG.N = length(Paras_RG.p);
        Paras_RG.p_rg = Paras_RG.p;
        for i=1:Paras_RG.N
            tmp = num2str(Paras_RG.p(i)*100);
            if ~isempty(find(tmp=='.',1));  tmp(find(tmp=='.'))='_';  end
            Paras_RG.name{i} = ['rg',tmp];
            r = 1;
            while r<=Rept
                [ak,apl,acc] = gen_net('rg',NetSet.n,Paras_RG);
                it = ngg(Paras_RG);
                if it==NGSet.maxIter
                    NGSet.maxIter = floor(NGSet.maxIter*1.25);
                    r = r-1;
                elseif it<NGSet.maxIter/2
                    NGSet.maxIter = floor(NGSet.maxIter*.75);
                end
                r = r+1;
            end
        end
    case 2  %% Scale Free
        Paras_SF.beta = beta;
        Paras_SF.n = floor(setK./2);
        Paras_SF.N = length(Paras_SF.n);
        Paras_SF.n_sf = Paras_SF.n;
        for i=1:Paras_SF.N
            Paras_SF.name{i} = ['sf',int2str(Paras_SF.n(i))];
        end
        for i=1:Paras_SF.N
            r = 1;
            while r<=Rept
                [ak,apl,acc] = gen_net('sf',NetSet.n,Paras_SF);
                it = ngg(Paras_SF);
                if it==NGSet.maxIter
                    NGSet.maxIter = floor(NGSet.maxIter*1.25);
                    r = r-1;
                elseif it<NGSet.maxIter/2
                    NGSet.maxIter = floor(NGSet.maxIter*.75);
                end
                r = r+1;
            end
        end
    case 3  %% Small World
        Paras_SW.beta = beta;
        Paras_SW.k = floor(setK./2);	%% neighbors
        Paras_SW.p = [0.2;];            %% re-wiering prob = {0.1; 0.2}
        Paras_SW.Nk = length(Paras_SW.k);
        Paras_SW.Np = length(Paras_SW.p);
        Paras_SW.p_sw = Paras_SW.p;
        Paras_SW.k_sw = Paras_SW.k;
        % ----- Get Paras_SW.namek and Paras_SW.namep, respectively ----- %
        for i=1:Paras_SW.Nk
            Paras_SW.namek{i} = ['swk',num2str(Paras_SW.k(i))];
        end
        for i=1:Paras_SW.Np
            tmp = num2str(Paras_SW.p(i));
            if ~isempty(find(tmp=='.',1))
                tmp(find(tmp=='.'))='_';
            end
            Paras_SW.namep{i} = ['p',tmp];
        end
        % ----- Get Paras_SW.namek and Paras_SW.namep, respectively ----- %
        for i=1:Paras_SW.Nk
            for j=1:1:Paras_SW.Np
                r = 1;
                while r<=Rept
                    [ak,apl,acc] = gen_net('sw',NetSet.n,Paras_SW);
                    it = ngg(Paras_SW);
                    if it==NGSet.maxIter
                        NGSet.maxIter = floor(NGSet.maxIter*1.25);
                        r = r-1;
                    elseif it<NGSet.maxIter/2
                        NGSet.maxIter = floor(NGSet.maxIter*.75);
                    end
                    r = r+1;
                end
            end
        end
end

