% Finite Memory Naming Game
% updated: 31-08-2018 

function [cTime] = fmng(para)
global NGSet;
global NetSet;
global A;

    TEN = 10;
    maxMsg = 1E10;  % External Lexicon ('msg' = message)
    % ----- Initialization ----- %
    cLen = floor(NGSet.maxIter / NGSet.itv); 
    nTotl = zeros(cLen,1);  %% # Total names - a curve
    nDiff = zeros(cLen,1);  %% # Different names - a curve
    sRate = zeros(cLen,1);  %% Success rate - a curve
    cTime = NGSet.maxIter;
    disp('-----  -----  -----  -----  -----  ')
    disp(['Current Network = ',     num2str(NetSet.name)])
    disp(['Population Size = ',     num2str(NetSet.n)])  %% NetSet.n == NGSet.n, the same thing
    disp(['Max # Iteration = ',     num2str(NGSet.maxIter)])
    disp('-----  -----  -----  -----  -----  ')
    node   = cell(NetSet.n,1);
    lenU   = zeros(NetSet.n,1);     %% Length of memory used in each node
    isCons = zeros(NetSet.n,1);     %% Is consensus? (Yes=1;No=0)
    mLost  = zeros(NetSet.n,1);
    sCnt   = zeros(TEN,1);          %% Success_time(sCnt) / Last_TEN_times
    cnt = 1;	%% Counter for all (real) Iteration, i.e., operations
    smpCnt = 0;	%% Counter for (sampled) Iteration, smpCnt = cnt / NGSet.itv
    
    while cnt < NGSet.maxIter
        idx = randi(NetSet.n);
        neb_arr = find(A(idx,:));
        if isempty(neb_arr);  error('The graph is NOT conneted ... ');  end  %% Just check again
        jdx = neb_arr(randi(length(neb_arr)));        
        if strcmp(NGSet.strategy,'inv')
            tmp = idx;  idx = jdx;  jdx = tmp;  %% Swap (idx <-> jdx)
        end
        % ----- Speaker sends out Message ----- %
        if ~lenU(idx)               %% Nothing in speaker's memory
            msg = randi(maxMsg);
            node{idx,1} = msg;	%% Initialize the Speaker
            lenU(idx) = 1;
        else
            msg = node{idx,1}(randi(lenU(idx)),1);
        end
        % ----- Hearer receives Message ----- %
        sCnt(2:TEN,1) = sCnt(1:TEN-1,1);
        if ~lenU(jdx)  %% Nothing in hearer's memory
            node{jdx,1} = msg;
            sCnt(1,1) = 0;
            lenU(jdx) = 1;
        else
            if isempty(find(node{jdx,1}==msg,1))  %% Hearer has no Speaker's msg
                if lenU(jdx) == NGSet.memo.len
                    mLost(jdx) = mLost(jdx)+1;
                    switch NGSet.memo.ovr
                        case 'uni'  %% uniformly discard one
                            tmpi = randi(NGSet.memo.len+1)-1;
                            if tmpi
                                node{jdx,1}(tmpi) = msg;
                            end  %% Else, discard 'msg'
                        case 'lst'  %% discard the last one
                            if rand<0.5
                                node{jdx,1}(randi(NGSet.memo.len)) = msg;
                            end
                    end
                elseif lenU(jdx) > NGSet.memo.len
                    error('check your program ... ')
                else
                    node{jdx,1} = [node{jdx,1};msg];
                    lenU(jdx,1) = lenU(jdx,1)+1;  %% Length of node(jdx) plus 1
                end
                isCons(jdx,1) = 0;  %% Not consented
                sCnt(1,1) = 0;  %% Success counter +0
            else  %% Consensus
                isCons(idx,1) = 1;
                isCons(jdx,1) = 1;
                node{idx,1} = msg;
                node{jdx,1} = msg;
                sCnt(1,1) = 1;  %% Success counter +1
                lenU(idx,1) = 1;  %% Length of node(idx) reset to 1
                lenU(jdx,1) = 1;  %% Length of node(jdx) reset to 1
            end
        end
        % ----- Calculate features ----- %
        if ~mod(cnt-1,NGSet.itv)
            smpCnt = smpCnt+1;
            nTotl(smpCnt,1) = sum(lenU);  %% # Total names
            tmp_dif = [];
            for i=1:NetSet.n
                tmp_dif = [tmp_dif;node{i,1}];
            end
            nDiff(smpCnt,1) = length(unique(tmp_dif));  %% # Different names
            sRate(smpCnt,1) = sum(sCnt)/TEN;  %% Success rate
            clear tmp_dif
        end
        % ----- End of Calculate features ----- %
        % ----- Test convergence ----- %
        conv_flag = 1;
        if sum(isCons)~=NetSet.n || sum(lenU)~=NetSet.n
            conv_flag=0;
        else
            for i=2:NetSet.n
                if node{i-1,1}(1,1)~=node{i,1}(1,1)
                    conv_flag = 0;
                    break;
                end
            end
        end
        if conv_flag
            smpCnt = smpCnt+1;
            nTotl(smpCnt,1) = sum(lenU);  %% # Total names
            tmp_dif = [];
            for i=1:NetSet.n
                tmp_dif = [tmp_dif,node{i,1}];
            end
            nDiff(smpCnt,1) = length(unique(tmp_dif));  %% # Different names
            if nDiff(smpCnt,1)>1;
                nDiff(smpCnt,1)
                error('Check ...');
            end
            sRate(smpCnt,1) = sum(sCnt)/TEN;  %% Success rate
            clear tmp_dif
            
            nTotl(smpCnt+1:cLen) = [];  %%nTotl(smpCnt,1);
            nDiff(smpCnt+1:cLen) = [];  %%nDiff(smpCnt,1);
            sRate(smpCnt+1:cLen) = [];  %%sRate(smpCnt,1);
            cTime = cnt;
            break;  %% End of Game Loop
        end
        % ----- End of Test convergence ----- %
        cnt = cnt+1;
        if ~mod(cnt,1E4);  disp(['iter - ',int2str(cnt)]);  end
    end  %% End-of-While-cnt ...
    if conv_flag
        disp(['Converged at interation ',int2str(cnt),'. '])
    else
        disp(['Not converged ... '])
    end
    disp(' ');
    
    fname = ['FMNG_LM',int2str(NGSet.memo.len),'_Net',NetSet.name];
    save(fname,'NGSet','NetSet','nTotl','nDiff','sRate','cTime','mLost','para')

end

