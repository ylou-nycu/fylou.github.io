% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% Ref: Y. Lou, G.R. Chen, Z.P. Fan, and L.N. Xiang. Local Communities
% Obstruct Global Consensus: Naming Game on Multi-Local-World Networks,"
% Physica A, 492:1741-1752, 2018. doi:10.1016/j.physa.2017.11.094.
% -----  -----  -----  -----  -----  -----  -----  -----  -----
% Chapter 7 Multi-Word Naming Game
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% Matlab code by: Yang (Felix) Lou (felix.lou@my.cityu.edu.hk)
% updated: 01-09-2018
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

clear;  %clc;

global A;  % ADJACENCY MATRIX OF NETWORKS %

addpath('net');
disp(' --- Running Naming Game on Multi-Local-World --- ')
disp('please input the following parameters for simulation ... ')
N     = input('1. Population size (e.g., 500): ');
npLW  = input(['2. Number of nodes per Local-World (in range [3,',int2str(N/10),'], e.g., 6): ']);
Nrate = input('3. Percentage of nodes in initial Local-Worlds (e.g., 0.7): ');
SaveA = input('4. Save MLW network Adjacent Matrix (Y/N)? ', 's');
%disp('Default Speaker-Hearer Selection Strategy is ''Direct''.');
if(N < 1200), MAX_ITER = 1E6;
else MAX_ITER = 1E7;
end
REPT  = 1;  % number of repeated runs
% if strcmp(SaveA,'Y') || strcmp(SaveA,'y')
%     AdjMat = cell(REPT,1);
% end
INTERVAL = 100;
mlw_para.N  = N;
mlw_para.LN = npLW;
mlw_para.LW = floor(N*Nrate / mlw_para.LN);  % #of Local Worlds %

NET_TYPE = 20;  % ALL THE NETWORKS IN THE TEST %
SELECT_STR = 'direct';  %% {'direct', 'inverse'} THE SPEAKER-HEARER PSELECTING STRATEGIES %
TEN = 10;
MAXN = N*10;  %% MAX # OF VOCABULARY, LARGE ENOUGH %
STORE_LENGTH = MAX_ITER / INTERVAL;

% INITIALIZING ... %
nTotl	 = zeros(REPT,STORE_LENGTH);  %% #OF TOTAL NAMES
nDiff    = zeros(REPT,STORE_LENGTH);  %% #OF DIFFERENT NAMES
sRate	 = zeros(REPT,STORE_LENGTH);  %% #OF SUCCESS RATE
maxDiffW = zeros(REPT,1);              %% THE PEAK OF DIFFERENT_NAME CURVE
cTime = zeros(REPT,1);              %% #OF ITERATIONS TO REACH CONVERGENCE

for r = 1:REPT
    ak      = 0;
    apl = 0;
    acc          = 0;
    disp('-- -- -- -- -- -- -- -- -- -- ');
    [ak, apl, acc] = gen_net_mlw(NET_TYPE, ak, apl, acc, mlw_para);
    % SETTING INFORMATIONS SHOWN IN THE SCREEN %
    disp('-- -- -- -- -- -- -- -- -- -- ');
    disp('NAMING GAME ON MLW RUNNING ... ');
    disp(['REPEATED RUN TIME: ',  num2str(r), '/', num2str(REPT)]);
    disp(['POPULATION SIZE: ',    num2str(N)]);
    disp(['MAXIMUM ITERATION: ',  num2str(MAX_ITER)]);
    disp('-- -- -- -- -- -- -- -- -- -- ');

    node         = cell(N,1);   	% NODES IN THE NETWORK, INDIVIDUALS %
    lenW         = zeros(N,1);     % LENGTH OF (STORED) MEMORY PER NODE %
    is_consensus = zeros(N,1);     % FLAG TO INTICATE CONSENSUS %
    suc_cnt      = zeros(TEN,1);	% SUCCESS TIME COUNTER %

    % NAMING GAME PROCESSING ... %
    cnt = 1;        % COUNTER FOR (REAL) ITERATION %
    smp_cnt = 0;    % COUNTER FOR (SAMPLED) ITERATION, IMAGE = REAL_ITER / INTERVAL %
    
    while cnt < MAX_ITER
        switch SELECT_STR
            case 'direct'  %% DEFAULT OPTION
                idx = randi(N);     % RANDOMLY SELECT A SPEAKER %
                neb_arr = find(A(idx,:) == 1);  	% NEB_ARR = "NEIGHTBOR_ARRAY", ONE ROW (IDX-TH ROW) AND N COLUMNS %
                if ~ isempty(neb_arr)
                    jdx = neb_arr(1,randi(length(neb_arr)));       % SELECT ONE HEARER FROM NEIGHBORS %
                else
                    error('Graph Not Connected ...');	% THIS IS IMPOSSIBLE, ONLY IF A BUG %
                end
            case 'inverse'
                jdx = randi(N);     % RANDOMLY SELECT A HEARER %
                neb_arr = find(A(jdx,:) == 1);  	% NEB_ARR = "NEIGHTBOR_ARRAY", ONE ROW (IDX-TH ROW) AND N COLUMNS %
                if ~ isempty(neb_arr)
                    idx = neb_arr(1,randi(length(neb_arr)));       % SELECT ONE SPEAKER FROM NEIGHBORS %
                else
                    error('Graph Not Connected ...');	% THIS IS IMPOSSIBLE, ONLY IF A BUG %
                end
        end
        % --- SPEAKER SENDS THE MESSAGE --- %
        if isempty(node{idx,1})         % IF SPEAKER HAS NOTHING IN MEMORY %
            message = randi(MAXN);
            node{idx,1} = message;
        else  % SPEAKER HAS MEMORY ALREADY %
            pos = randi(length(node{idx,1}));
            message = node{idx,1}(pos);
            lenW(idx,1) = 1;
        end % NODE(IDX) WILL SEND THE MESSAGE} %

        % --- HEARER RECEIVE THE MESSAGE --- %
        suc_cnt(2:TEN,1) = suc_cnt(1:(TEN-1),1);
        if isempty(node{jdx,1})	% IF HEARER HAS NOTHING IN MEMORY %
            % RECEIVED INFORMATION = {RULE_ID, MESSAGE} %
            node{jdx,1} = [message];	% LEARN THE FIRST MESSAGE %
            suc_cnt(1,1) = 0;
            lenW(jdx,1) = 1;
        else
            if isempty(find(node{jdx,1} == message,1))
                node{jdx,1} = [node{jdx,1},message];
                is_consensus(jdx,1) = 0;
                suc_cnt(1,1) = 0;
                lenW(jdx,1) = lenW(jdx,1) + 1;
            else  % CONSENSUS %
                is_consensus(idx,1) = 1;
                is_consensus(jdx,1) = 1;
                node{idx,1} = message;
                node{jdx,1} = message;
                suc_cnt(1,1) = 1;
                lenW(idx,1) = 1;
                lenW(jdx,1) = 1;
            end
        end
        
        % == CALCULATE FEATURES == %
        if ~ mod(cnt - 1,INTERVAL)
            smp_cnt = smp_cnt + 1;      % THE SUBSCRIPT FOR RECORD %
            nTotl(r,smp_cnt) = sum(lenW);
            diff_arr = [];
            for idx = 1:N
                diff_arr = [diff_arr,node{idx,1}];
            end
            nDiff(r,smp_cnt) = length(unique(diff_arr));
            sRate(r,smp_cnt) = sum(suc_cnt) / TEN;
            clear diff_arr;
        end
        % == END of CALCULATE FEATURES == %

        % == TEST CONVERGENCE == %
        conv_flag = 1;
        if sum(is_consensus) ~= N   % IF NOT ALL CONSENSUS, NOT CONSENSUS %
            conv_flag = 0;
        else                        % "SUM(IS_CONSENSUS) == N", ALL CONSENSUS, BUT MAY BE DIFFERENT WORDS %
            for idx = 2:N
                if node{idx-1,1} ~= node{idx,1}
                    conv_flag = 0;
                    break;  % IF ALL %
                end
            end
        end
        if conv_flag == 1  % CONSENSUS OR CONVERGED %
            maxDiffW(r) = max(nDiff(r,:));
            cTime(r) = cnt;
            nTotl(r,smp_cnt+1:end) = nTotl(r,smp_cnt);
            nDiff(r,smp_cnt+1:end) = nDiff(r,smp_cnt);
            sRate(r,smp_cnt+1:end) = sRate(r,smp_cnt);
            break;  % END NAMING GAME %
        end
        % == END of TEST CONVERGENCE == %

        cnt = cnt + 1;
        if mod(cnt,10000) == 0
            disp(['Iteration No.: ',num2str(cnt)]);
        end
    end     % END 'while cnt <= MAX_ITER' %
    if conv_flag
        disp(['Converged Time: ',num2str(cnt)])
    else
        disp(['Not Converged within ',num2str(cnt),' Interarions ...'])
    end
    if strcmp(SaveA,'Y') || strcmp(SaveA,'y')
        filename = ['AdjMat_Run',int2str(r),'.mat'];
        save(filename,'A');
    end
    disp([' ']);

end  % END of REPEAT %

% == SAVE DATA == %
% Convergence Curves can be ploted by the data saved above %
filename = ['MLW_NpLW',num2str(npLW),'_Rho0_',int2str(Nrate*100),'.mat'];
save (filename,'nTotl','nDiff','sRate','maxDiffW','cTime','node',...	%% For Convergence Curves Plot
    'ak','apl','acc',...                                                %% Statistics of Networks
    'mlw_para','INTERVAL','SELECT_STR');                                %% mlw network paras


