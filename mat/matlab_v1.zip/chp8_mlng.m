% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% Ref: J. Zhou, Y. Lou, G.R. Chen, and W.K.S. Tang.
% "Multi-Language Naming Game," Physica A, 496:620-634, 2018.
% doi:10.1016/j.physa.2017.12.124.
% -----  -----  -----  -----  -----  -----  -----  -----  -----
% Chapter 8 Multi-Language Naming Game
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% Matlab code by: Yang (Felix) Lou  (felix.lou@my.cityu.edu.hk)
%                 & Jianfeng Zhou	(jfzhou2-c@my.cityu.edu.hk)
% updated: 01-09-2018
% -----  -----  -----  -----  -----  -----  -----  -----  ----- 

clear;  %clc;

addpath('net');
disp(' --- Running Multi-Language Naming Game --- ')
disp('Please input the following parameters for simulation ... ')
N     = input('1. Population size (e.g., 500): ');
while mod(N,1)
    N = input('should be an integer:');
end
disp('2. Choose the underlying network:')
disp('   (see Table 8.2 for more details of network settings)')
disp('| 1/2. RG/0.1   || 3. SW/25/0.1  || 4. SW/50/0.2  |')
disp('| 5. NW/20/0.02 || 6. NW/40/0.02 || 7. SF/25/     |');
disp('| 8. SF/50/     || 9. TRM/50/13  || 10. TRM/50/27 | ');
netType = input('Input 1~10: ');
while mod(netType,1) || netType<1 || netType>10
    netType = input('should be an integer in 1~10:');
end
% PARAMETERS SETTING %
REPT  = 1;                  % number of repeated runs
MAX_VOCABULARY = 1E5;       % EXTERNAL VOCABULARY
MAX_ITER = 1E6;             % EMPIRICALLY ALL CASES IN THE PAPER WILL CONVERGE BEFORE 1E7 ITERATION %
INTERVAL = 500;             % SAMPLE FREQUENCY, RECORD DATA PER 500 INTERATION %
STORE_LENGTH = MAX_ITER / INTERVAL;
TEN = 10;
M = 100*(N>=100)+N*(N<100);
pair_cnt = zeros(REPT,1);
tri_cnt = zeros(REPT,1);
fail_communication_cnt = zeros(REPT,1);

P_T = 0.5;  %% percentage of Translators

avg_word_in_E       =	zeros (STORE_LENGTH,1);
avg_word_in_C       =	zeros (STORE_LENGTH,1);
avg_word_in_T       =	zeros (STORE_LENGTH,1);
avg_word_in_total   =	zeros (STORE_LENGTH,1);	% AVERAGE WORD IN THE WHOLE POPULATION, WHEN CONSENSUS, IT EQUALS N  %
avg_word_difference =   zeros (STORE_LENGTH,1);    % AVERAGE DIFFERENT WORDS IN POPULATION, WHEN CONSENSUS, IT EQUALS 0 %
nDiff_T =   zeros (STORE_LENGTH,1);
nDiff_E =   zeros (STORE_LENGTH,1);
nDiff_C =   zeros (STORE_LENGTH,1);
sRate        =   zeros (STORE_LENGTH,1);    % CONSENSUS TIMES DURING EVERY TEN TIMES COMMUNICATIONS              %

% LOOP FOR TEST GROUPS OF PARAMETERS %
word_in_total_E     = zeros (REPT,STORE_LENGTH);
word_in_total_C     = zeros (REPT,STORE_LENGTH);
word_in_total_T     = zeros (REPT,STORE_LENGTH);
word_in_total       = zeros (REPT,STORE_LENGTH);        % WORD IN MEMORIES OF ALL agentS %
word_difference    	= zeros (REPT,STORE_LENGTH);        % DIFFERENT WORDS IN ALL agentS %
word_difference_T	= zeros (REPT,STORE_LENGTH);
word_difference_E	= zeros (REPT,STORE_LENGTH);
word_difference_C	= zeros (REPT,STORE_LENGTH);
success             = zeros (REPT,STORE_LENGTH);
converge            = zeros (REPT,1);

    for r = 1:REPT
        disp('-- -- -- -- -- -- -- -- -- -- ');
        disp(['Propotion of Translator: ',num2str(P_T)]);
        disp(['Repeat run time: ',num2str(r),'/',num2str(REPT)]);
     	disp(['Number of nodes: ',num2str(N)]);
      	disp(['Maximum iteration: ',num2str(MAX_ITER)]);
       	disp('-- -- -- -- -- -- -- -- -- -- ');

        vocabulary = 1:MAX_VOCABULARY;   	% NOTE ZERO IS NOT A MEMBER OF VOCABULARY %
       
        is_consensus = zeros(N,1);         % INDICATOR TO DENOTE STATUS OF agentS %
        suc = zeros(TEN,1);              	% SUCCESS TIME COUNTER %
        
        agent = zeros(N,M);
        for i_initial = 1:N
            rand_init = rand;
            if rand_init < P_T
                agent(i_initial,2) = 2; % Translator
            elseif rand_init < (P_T+(1-P_T)/2)
                agent(i_initial,2) = 1; % Chinese agent
            else
                agent(i_initial,2) = 3; % English anget
            end
        end
        
        idxTR = find(agent(:,2)==2)'; % Translators
        idxCH = find(agent(:,2)==1)'; % Chinese
        idxEN = find(agent(:,2)==3)'; % English
        nTR = length(idxTR);
        nCH = length(idxCH);
        nEN = length(idxEN);
        
        switch netType  %% According to Tabel 8.2
            case 1
                [A,dis] = rg(N,0.1);
            case 2
                [A,dis] = rg(N,0.1);
            case 3
                [A,dis] = sw(N,0.2,25);
            case 4
                [A,dis] = sw(N,0.2,50);
            case 5  %% nw_small_world 
                [A,dis] = nw(N,0.02,20);
            case 6  %% nw_small_world 
                [A,dis] = nw(N,0.02,40);
            case 7
                [A,dis] = sf(N,25,24);
            case 8
                [A,dis] = sf(N,50,49);
            case 9
                [A,dis] = trm(N,50,13);
            case 10
                [A,dis] = trm(N,50,27);
        end
        % NAMING GAME PROCESSING... %
        cnt = 1;      % COUNTER FOR ITERATION (THE ACTUAL ITERATION) %
        sub_cnt = 0;  % COUNTER FOR THE_ACTUAL_ITERATION / INTERVAL  %
        while cnt <= MAX_ITER
            if ~mod(cnt,1E4);  disp(['iteration ',int2str(cnt), ' ...']);  end
            idx = randi(N);  % RANDOMLY SELECT THE SPEAKER %
            neb_arr = find(A(idx,:) == 1);  % NEB_ARR = "NEIGHBOR_ARRAY", ONE ROW AND N COLUMNS %
            if ~isempty(neb_arr)
                jdx = neb_arr(1,randi(length(neb_arr)));  % SELECT ONE HEARER FROM SPEAKER'S NEIGHBORS %
            else
                error('Underlying network NOT connected ...');  % ONLY IF THERE IS A BUG %
            end
            if abs(agent(idx,2)-agent(jdx,2)) < 2  % if the speaker and the hearer can communicate
                pair_cnt(r,1) = pair_cnt(r,1) + 1;  % count the number of pair_communication
                if ~agent(idx,1)  % SPEAKER HAS EMPTY MEMOTY %
                    agent(idx,3) = vocabulary(randi(MAX_VOCABULARY));
                    agent(idx,1) = agent(idx,1)+1;  % THE FIRST ELEMENT OF agent STORES THE NUMBER OF WORDS IT HAS %
                    % NOTE: THE FIRST ELEMENT OF AGENT STORES THE NUMBER OF WORDS IT HAS
                    %       THE SECOND ELEMENT STORES THE LANGUAGE TYPE
                    %       THE THIRD ELEMENT IS THE FIRST 'WORD' THE AGENT HAS
                end
                len_idx = agent(idx,1);                 % GET THE SPAEKER'S NUMBER OF WORDS %
                message = agent(idx,randi(len_idx)+2);	% RONDOMLY PICK UP A WORD IN THE SPEAKER'S MEMORY %
                suc_note_flag = 0;
                cons_flag = 0;
                len_jdx = agent(jdx,1);
                if len_jdx
                    for tmp_jdx = 3:(len_jdx+2)
                        if agent(jdx,tmp_jdx) == message  % SUCCEED, OR CONSENSUS
                            agent(jdx,:) = 0;	% CLEAR MEMORY OF HEARER
                            agent(idx,:) = 0;	% CLEAR MEMORY OF SPEAKER
                            agent(jdx,1) = 1;	% RESET HEARER'S NUMBER OF WORD
                            agent(idx,1) = 1;	% RESET SPEAKER'S NUMBER OF WORD
                            agent(jdx,3) = message;
                            agent(idx,3) = message;
                            is_consensus(jdx,1) = 1;
                            is_consensus(idx,1) = 1;
                            if cnt<TEN;  suc(cnt,1) = 1;
                            else
                                suc(1:(TEN-1),1) = suc(2:TEN,1);
                                suc(TEN,1) = 1;  suc_note_flag = 1;
                            end
                            cons_flag = 1;
                            break;
                        end
                    end
                    if ~cons_flag  % (FLAG == 0) means NO CONSENSUS
                        agent(jdx,len_jdx+3) = message;
                        agent(jdx,1) = agent(jdx,1)+1;
                    end
                else  % len_jdx == 0, HEARER HAS NOTHING IN MEMORY %
                    agent(jdx,3) = message;
                    agent(jdx,1) = agent(jdx,1)+1;
                end
                if ~suc_note_flag
                    if cnt<TEN;  suc(cnt,1) = 0;
                    else  suc(1:(TEN-1),1) = suc(2:TEN,1);  suc(TEN,1) = 0;
                    end
                end
            else  %% IF Speaker-Hearer CANNOT communicate directly
                neb_arr_j = find(A(jdx,:) == 1);  % find neighbors of Hearer
                neb_arr_ij_com = intersect(neb_arr_j,neb_arr);  % common neighbors of i(Speaker) & j(Hearer)
                neb_com_T = intersect(idxTR,neb_arr_ij_com);   % common Translator
                if ~isempty(neb_com_T)  % common Translator
                    tri_cnt(r,1) = tri_cnt(r,1)+1;	%% counter: trianglar-coummunication
                    tdx = neb_com_T(randi(length(neb_com_T)));                  %% a rand-common-Translator
                    if ~agent(idx,1)  % SPEAKER HAS EMPTY MEMOTY
                        agent(idx,3) = vocabulary(randi(MAX_VOCABULARY));
                        agent(idx,1) = agent(idx,1)+1;  % THE FIRST ELEMENT OF agent STORES THE NUMBER OF WORDS IT HAS
                    end
                    len_idx = agent(idx,1);
                    message = agent(idx,randi(len_idx)+2);
                    suc_note_flag = 0;
                    translation_flag = 0;
                    cons_flag = 0;
                    len_tdx = agent(tdx,1);
                    len_jdx = agent(jdx,1);
                    if len_tdx
                        for tmp_tdx = 3:(len_tdx+2)
                            if agent(tdx,tmp_tdx) == message  % Translator has message in memory
                                translation_flag = 1;  % (FLAG==1) means Translator has message
                                if len_jdx
                                    for tmp_jdx = 3:(len_jdx+2)
                                        if agent(jdx,tmp_jdx) == message  % translation succeed
                                            agent(jdx,:) = 0;  % CLEAR MEMORY OF HEARER %
                                            agent(idx,:) = 0;  % CLEAR MEMORY OF SPEAKER %
                                            agent(jdx,1) = 1;  % RESET HEARER'S NUMBER OF WORD %
                                            agent(idx,1) = 1;  % RESET SPEAKER'S NUMBER OF WORD %
                                            agent(jdx,3) = message;
                                            agent(idx,3) = message;
                                            is_consensus(jdx,1) = 1;
                                            is_consensus(idx,1) = 1;
                                            if cnt<TEN;  suc(cnt,1) = 1;
                                            else
                                                suc(1:(TEN-1),1) = suc(2:TEN,1);
                                                suc(TEN,1) = 1;  suc_note_flag = 1;
                                            end
                                            cons_flag = 1;  % (FLAG == 1) meanss CONSENSUS
                                            break;
                                        end
                                    end
                                    if ~cons_flag  % NO CONSENSUS
                                        agent(jdx,len_jdx+3) = message;
                                        agent(jdx,1) = agent(jdx,1)+1;
                                    end
                                else  %% Hearer has nothing in memory
                                    agent(jdx,3) = message;
                                    agent(jdx,1) = agent(jdx,1) + 1;
                                end
                                break;
                            end
                        end
                        if ~translation_flag  % Translator does NOT have this word
                            agent(tdx,len_tdx+3) = message;
                            agent(tdx,1) = agent(tdx,1)+1;
                        end
                    else  %% Translator has nothing in memory
                        agent(tdx,3) = message;
                        agent(tdx,1) = agent(tdx,1)+1;
                    end
                else  %% NO commom Translator
                fail_communication_cnt(r,1) = fail_communication_cnt(r,1)+1;
                end
            end
            
            % ----- TEST CONVERGENCE ----- %
            conv_flag = 1;
            if find(agent(:,1) ~= 1)  % IF ANY agent HAS NO WORD OR MORE THAN ONE WORDS, NOT CONVERGED
                conv_flag = 0;
            else
                one_word = unique(agent(:,3));
                if length(one_word)>1;  conv_flag = 0;  end
            end
            if conv_flag
                word_cnt = sum(agent(:,1));
                word_in_total(r,sub_cnt+1:end) = word_cnt;
                word_cnt_T = sum(agent(idxTR,1));  % Total words in Translator
                word_in_total_T(r,sub_cnt+1:end) = word_cnt_T;
                word_cnt_C = sum(agent(idxCH,1));  % Total words in Chn
                word_in_total_C(r,sub_cnt+1:end) = word_cnt_C;
                word_cnt_E = sum(agent(idxEN,1));  % Total words in Eng
                word_in_total_E(r,sub_cnt+1:end) = word_cnt_E;
                success(r,sub_cnt+1:end) = 1;
                disp(['Converged at generation ', num2str(cnt), '...']);
                disp(' ');
                converge(r,1) = cnt;
                break;
            end
            
            % ----- CALCULATE FEATURES ----- %
            if ~mod(cnt-1,INTERVAL)
                sub_cnt = sub_cnt + 1;      % THE SUBSCRIPT FOR RECORD
                word_list   = zeros(1,MAX_VOCABULARY);
                word_list_T = zeros(1,MAX_VOCABULARY);
                word_list_C = zeros(1,MAX_VOCABULARY);
                word_list_E = zeros(1,MAX_VOCABULARY);
                word_cnt = sum(agent(:,1));
                word_cnt_T = sum(agent(idxTR,1));
                word_cnt_C = sum(agent(idxCH,1));
                word_cnt_E = sum(agent(idxEN,1));
                
                for idx = 1:N  % (all) different words
                    len_jdx = agent(idx,1);
                    for jdx = 3:(len_jdx+1)
                        if ~word_list(1,agent(idx,jdx))
                            word_list(1,agent(idx,jdx)) = 1;
                        end
                    end
                end
                N_T = length(idxTR);
                for idx = 1:N_T  % different words
                    len_jdx = agent(idxTR(idx),1);
                    for jdx = 3:(len_jdx+1)
                        if ~word_list_T(1,agent(idxTR(idx),jdx))
                            word_list_T(1,agent(idxTR(idx),jdx)) = 1;
                        end
                    end
                end
                N_C = length(idxCH);
                for idx = 1:N_C
                    len_jdx = agent(idxCH(idx),1);
                    for jdx = 3:(len_jdx+1)
                        if ~word_list_C(1,agent(idxCH(idx),jdx))
                            word_list_C(1,agent(idxCH(idx),jdx)) = 1;
                        end
                    end
                end
                N_E = length(idxEN);
                for idx = 1:N_E
                    len_jdx = agent(idxEN(idx),1);
                    for jdx = 3:(len_jdx+1)
                        if ~word_list_E(1,agent(idxEN(idx),jdx))
                            word_list_E(1,agent(idxEN(idx),jdx)) = 1;
                        end
                    end
                end
                success(r,sub_cnt) = sum(suc)/TEN;
                word_in_total(r,sub_cnt) = word_cnt;
                word_difference(r,sub_cnt) = length(find(word_list == 1));
                word_difference_T(r,sub_cnt) = length(find(word_list_T == 1));
                word_difference_E(r,sub_cnt) = length(find(word_list_E == 1));
                word_difference_C(r,sub_cnt) = length(find(word_list_C == 1));
                
                word_in_total_T(r,sub_cnt) = word_cnt_T;
                word_in_total_C(r,sub_cnt) = word_cnt_C;
                word_in_total_E(r,sub_cnt) = word_cnt_E;
            end
            cnt = cnt+1;
            if cnt>(MAX_ITER-3)
                flag_unconverge = 1;
                break;
            end
        end
    end
    % END of REPT %
    
    for iter = 1:STORE_LENGTH
        for rp = 1:REPT
            avg_word_in_total(iter)     = avg_word_in_total(iter) + word_in_total(rp,iter);
            avg_word_difference(iter)   = avg_word_difference(iter) + word_difference(rp,iter);
            nDiff_T(iter)	= nDiff_T(iter) + word_difference_T(rp,iter);
            nDiff_C(iter)	= nDiff_C(iter) + word_difference_C(rp,iter);
            nDiff_E(iter)	= nDiff_E(iter) + word_difference_E(rp,iter);
          	sRate(iter)	= sRate(iter) + success(rp,iter);
            
            avg_word_in_T(iter)	= avg_word_in_T(iter) + word_in_total_T(rp,iter);
            avg_word_in_C(iter) = avg_word_in_C(iter) + word_in_total_C(rp,iter);
            avg_word_in_E(iter)	= avg_word_in_E(iter) + word_in_total_E(rp,iter);
        end
        avg_word_in_total(iter)     = avg_word_in_total(iter) / REPT;
        avg_word_difference(iter)   = avg_word_difference(iter) / REPT;
        nDiff_T(iter)	= nDiff_T(iter) / REPT;
        nDiff_C(iter)	= nDiff_C(iter) / REPT;
        nDiff_E(iter)	= nDiff_E(iter) / REPT;
       	sRate(iter)          = sRate(iter) / REPT;
        
        avg_word_in_T(iter)         = avg_word_in_T(iter) / REPT;
        avg_word_in_C(iter)         = avg_word_in_C(iter) / REPT;
        avg_word_in_E(iter)         = avg_word_in_E(iter) / REPT;
    end
    
    cTime = mean(converge);
    sRate = sRate(1:length(avg_word_difference));
    nDiff = avg_word_difference(avg_word_difference >= 1);
    nDiff_T = nDiff_T(1:length(avg_word_difference));
    nDiff_C = nDiff_C(1:length(avg_word_difference));
    nDiff_E = nDiff_E(1:length(avg_word_difference));
    
    nTotl	= avg_word_in_total(1:length(avg_word_difference));
    nTotl_T = avg_word_in_T(1:length(avg_word_difference));
    nTotl_C = avg_word_in_C(1:length(avg_word_difference));
    nTotl_E = avg_word_in_E(1:length(avg_word_difference));
    
    netName = {'ER';'WS';'NM';'SF';'TRM';};
    fname = ['MLNG_Net',netName{ceil(netType/2)}];
    save(fname,'N','P_T','nTotl','nTotl_T','nTotl_E','nTotl_C','nDiff','nDiff_T','nDiff_E','nDiff_C', ...    
    'sRate','cTime')
    
    

