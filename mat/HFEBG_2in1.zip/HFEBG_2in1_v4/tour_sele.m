% tour_sele.m
% Tournament Selection
% Updated: 24-09-2020

function [fmin,pos] = tour_sele(f1,f2)

    pos = 1;
    if f1.f<f2.f                                %% (1) Compare .f (p-Valuw)
        fmin=f1;
    elseif f1.f>f2.f
        fmin=f2;  pos=2;
    else  % (1) When .f not work
        if(f1.f~=1||f2.f~=1); error('Check point #1 ... '); end
        if f1.n>f2.n                            %% (2) Greater .n is Better
            fmin = f1;
        elseif f1.n<f2.n
            fmin=f2; pos=2;
        else                                    %% (3) When .n equals
            if(f1.n~=f2.n); error('Check point #2 ... '); end
            if f1.n>0 % (3) When .n equals
                if sum(f1.fi)<sum(f2.fi)        %% (3.1)
                    fmin=f1;
                elseif sum(f1.fi)>sum(f2.fi)	%% (3.2)
                    fmin=f2; pos=2;
                else                            %% (3.3)
                    if(rand<0.5); pos=1; fmin=f1;
                    else;         pos=2; fmin=f2; end
                end
            else % elseif f1.n==f2.n==0 %       %% (4) Compare .delta
                if f1.delta<f2.delta            %% (4.1)  
                    fmin=f1;
                elseif f1.delta>f2.delta        %% (4.2)
                    fmin=f2; pos=2;
                else                            %% (4.3)
                    if(rand<0.5); pos=1; fmin=f1;
                    else;         pos=2; fmin=f2; end
                end
            end
        end
    end
    
end
