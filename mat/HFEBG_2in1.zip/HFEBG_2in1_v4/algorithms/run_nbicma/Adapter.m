

function Adapter()

global settings;
global mystat;

    dim = mystat.D;
    MAX_EVAL = myeval(settings.MaxEvals);
    irest = 0;
    settings.iglobalrun = 0;
    while (mystat.nevals < MAX_EVAL) %% && (mystat.Fbest > 1e-9)%
        settings.iglobalrun  = settings.iglobalrun + 1;
        maxeval_available = MAX_EVAL - mystat.nevals;%fgeneric('evaluations');
        
        xacmes('MyFunc',dim,maxeval_available);
        irest = irest + 1;
    end
%     if (irest > 1)
%         disp([' nrestart:',num2str(irest)]);
%     end
    