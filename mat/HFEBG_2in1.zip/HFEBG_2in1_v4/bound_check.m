% bound_check.m
% Check Boundaries - Only Sigma Not in (0,1); All Others in (0,1)
% Updated: 11-01-2016

function [x] = bound_check(x,nGauss,sig)
% sig = {sig.ub; sig.lb}

    [dd,psDE] = size(x);
    if mod(dd,nGauss)
        error('Check here ... ')
    end
    for idx = 1:psDE
        for jdx = 1:nGauss  %% Check Sigma
            if x(jdx,idx)<sig.lb || x(jdx,idx)>sig.ub
                x(jdx,idx) = sig.lb + rand*(sig.ub-sig.lb);
            end
        end
        for jdx = nGauss+1:dd-1  %% Check Other Paras
            if x(jdx,idx)<0 || x(jdx,idx)>1
                x(jdx,idx) = rand;
            end
        end
        % The Last Dim is the Random Seed Variable %
        x(dd,idx) = randi(2^53-1);
    end
end