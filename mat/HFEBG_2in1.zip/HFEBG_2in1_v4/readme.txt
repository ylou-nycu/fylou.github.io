-----------------------------------------------------------------
HFEBG_2in1_v3
Updated: 25-09-2020
-----------------------------------------------------------------
'HFEBG_U.m' - Source Code for Y. Lou and S.Y. Yuen, "On
Constructing Alternative Benchmark Suite for Evolutionary Algorithms",
Swarm and Evolutionary Computation, 44:287–292;
doi:10.1016/j.swevo.2018.04.005 (2019) 

'HFEBG_H.m' - Source Code for Y. Lou, S.Y. Yuen, and G. Chen,
"Evolving Benchmark Functions Using Kruskal-Wallis Test,"
In: Proc. Genetic and Evolutionary Computation Conference (GECCO 2018)
doi: 10.1145/3205651.3208257 (2018)
-----------------------------------------------------------------
Programmer: Felix Y. Lou (felix.lou@my.cityu.edu.hk)
-----------------------------------------------------------------
_U	has four algorithms = {'ABC'; 'CoDE'; 'SPSO2011'; 'NBiPOP-CMAES';}
	for Uniquely Easy (UE) problems only;
_H	has four algorithms = {'ABC'; 'CoDE'; 'NBiPOP-CMAES';}
	for both UE and Uniquely Difficult (UD) problems. 
-----------------------------------------------------------------
Use Gaussian Landscapes, and CEC 2013 Benchmark Suite
-----------------------------------------------------------------
Copyright (c) 2019 Yang Lou and Shiu Yin Yuen and Guanrong Chen. 
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met: 

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer. 
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in
   the documentation and/or other materials provided with the 
   distribution.

This software is provided by the copyright holders and contributors
"as is" and any express or implied warranties, including, but not 
limited to, the implied warranties of merchantability and fitness
for a particular purpose are disclaimed. In no event shall the
copyright owner or contributors be liable for any direct, indirect,
incidental, special, exemplary, or consequential damages (including,
but not limited to, procurement of substitute goods or services;
loss of use, data, or profits; or business interruption) however
caused and on any theory of liability, whether in contract, strict
liability, or tort (including negligence or otherwise) arising in
any way out of the use of this software, even if advised of the
possibility of such damage.

-----------------------------------------------------------------

run = 'HFEBG_U' for HFEBG
run = 'HFEBG_H' for HFEBG-H

-----------------------------------------------------------------
HFEBG_2in1_v3
Updated: 25-09-2020
-----------------------------------------------------------------
[25-09-2020] 
    1. "tour_sele.m"    - Steps (3.1~3.3) and (4.1~4.3) resorted.
    2. "feval_prob.m"   - a useless 'global TestNrRS' has been removed,
                          which may cause some problem/bug.
    3. folder "Example" - the example has been corrected.
-----------------------------------------------------------------
[27-06-2018]
-----------------------------------------------------------------


