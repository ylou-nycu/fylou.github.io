% bestNselect_h.m
% '_h' for H-test, with both UE and UD
% Sorting and Selection of the Current Population
% Updated: Feb. 2018

function [fmin,xmin,dx] = find_best_h(f,x)
% Input:  f     - 
%         x     - size: d-by-ps
% Output: fmin
%         xmin
%         dx    - position of fmin

    ps = length(f);
    fmin = f{1};
    dx = 1;
    for idx = 2:ps
        if f{idx}.f < fmin.f
            fmin = f{idx};
            dx = idx;
        elseif f{idx}.f == fmin.f || fmin.f == 1  %% (1) .f not work
            if f{idx}.n > fmin.n
                fmin = f{idx};
                dx = idx;
            elseif f{idx}.n == fmin.n
                if fmin.n > 0
                    if sum(f{idx}.fi) < sum(fmin.fi)
                        fmin = f{idx};
                        dx = idx;
                    end
                else%% == elseif fmin.n == 0 && f{idx}.n == 0
                    % .n not work
                    if f{idx}.delta < fmin.delta
                        fmin = f{idx};
                        dx = idx;
                    end
                end
            end
        end
    end
    xmin = x(:,dx);