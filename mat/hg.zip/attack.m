% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% NET={'rt';'rr';'rp';'rh';};
% Node attacks: ATK={'nbet'; 'ndeg'; 'nrnd'; 'ncrir';};
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 12-Dec-2021
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function res=attack(n,m,net,aTk,Rept)
rng('shuffle')
y2u=0; pts=0; lcc=0;
    for r=1:Rept
        disp([' ----- | ',upper(net),' ',upper(aTk),' Attack (n=',int2str(n),' m=',int2str(m),') | ----- '])
        disp(['       .. Rept id: ',int2str(r),'/',int2str(Rept)]);
        switch net
            case'rt';   adj=rt(n,m);
            case'rr';   adj=rr(n,m);
            case'rp';	adj=rp(n,m);
            case'rh';   adj=rh(n,m);
        end
        tmpv=atk_node(n,adj,aTk);
        y2u=y2u+tmpv.y2u;
        pts=pts+tmpv.pts;
        lcc=lcc+tmpv.lcc;
    end
    res.y2u=y2u./Rept;
    res.pts=pts./Rept;
    res.lcc=lcc./Rept;
    %fname=['data_',net,'_n',int2str(n),'m',int2str(m),'_',aTk];
    %save(fname,'res','aTk')
end

