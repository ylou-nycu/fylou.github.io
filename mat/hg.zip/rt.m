% -----  -----  -----  -----  -----  -----  -----  -----  ----- 
% random triangle network
% updated: 12-Dec-2021
% -----  -----  -----  -----  -----  -----  -----  -----  -----
function adj=rt(n,m)
% -----  -----  -----  -----  -----  -----  -----  -----  -----
% input:    n - number of nodes
%           m - number of edges
% output: adj - adjacency matrix
% -----  -----  -----  -----  -----  -----  -----  -----  -----
Tri=3;
% --- Step(1): Generate a basic triangle --- %
    adj=zeros(n,n);
    for idx=1:Tri; adj(idx,mod(idx,Tri)+1)=1; end
% --- Step(2): Add random triangles --- %
    for idx=(Tri+1):1:n
        jdx=randi(idx-1);  % find a node from the already connected part (jdx)
        neb=[find(adj(jdx,:)==1),find(adj(:,jdx)==1)'];  % find all (jdx)'s neighbors
        len_neb=length(neb);
        if length(unique(neb))<len_neb; error('.. check !'); end
        kdx=neb(randi(len_neb));  % (kdx) is a (randomly-selected) neighbor of (jdx)
        if adj(kdx,jdx)  % ensure the direction: jdx -> kdx
            tmpv=kdx; kdx=jdx; jdx=tmpv;
        end
        adj(idx,jdx)=1;  % triangle loop: idx -> jdx -> kdx (-> idx)
        adj(kdx,idx)=1;        
    end
% --- Step(3): Control exact number of edges --- %
    cnt=sum(adj,'all');
    deltaE=cnt-m;
    if deltaE>0
        while cnt>m
            delete_edge
            cnt=sum(adj,'all');
        end
    elseif deltaE<0
        while cnt<m
            add_edge  %% add two edges per step
            cnt=sum(adj,'all');
        end
        while cnt>m
            delete_edge
            cnt=sum(adj,'all');
        end
    end
% % --- Step(4): Check again (DELETE when it is not necessary anymore) --- %
%    if sum(adj,'all')~=m || graphconncomp(sparse(adj),'Directed',true,'Weak',true)>1
%        error('.. check! ')
%    end

% -----| Auxiliary Functions |----- %
% control exact #edges: add 2 or delete 1 edge each time
    function add_edge
        r=randperm(n,2); r1=r(1); r2=r(2);  % find r1 and r2: no edge between them
        while(adj(r1,r2)||adj(r2,r1)); r=randperm(n,2); r1=r(1); r2=r(2); end
        neb1=[find(adj(r2,:)==1),find(adj(:,r2)==1)'];
        len_neb1=length(neb1);
        if length(unique(neb1))<len_neb1; error('.. check !'); end
        r3=neb1(randi(len_neb1));  % (r2) and (r3) are similar to (jdx) and (kdx) above
        if adj(r3,r2) %% r3 -> r2   
            adj(r2,r1)=1;
            if ~adj(r1,r3) && ~adj(r3,r1)
                adj(r1,r3)=1; 
            end
        else %% default r2 -> r3
            adj(r1,r2)=1;
            if ~adj(r1,r3) && ~adj(r3,r1)   
                adj(r3,r1)=1;
            end
        end
    end
    function delete_edge
        r1=randi(n);
        neb1=[find(adj(r1,:)==1),find(adj(:,r1)==1)'];
        len_neb1=length(neb1);
        if length(unique(neb1))<len_neb1; error('.. check !'); end
        r2=neb1(randi(len_neb1));  %% default r2 -> r3
        adj(r1,r2)=0;
        adj(r2,r1)=0;
    end
end

