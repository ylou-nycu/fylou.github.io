% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Node attacks: ATK={'nbet'; 'ndeg'; 'nrnd'; 'ncrir';};
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% node-removal attacks:
% 1) 'nbet'  - betweennness
% 2) 'ndeg'  - degree
% 3) 'nrnd'  - random
% 4) 'ncrir' - critical-random
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 12-Dec-2021
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function res = atk_node(n,adj,aTk)
    y2u=ones(n,1);	% structural controllability
    pts=ones(n,1);  % isolated parts
    lcc=n*ones(n,1);	% largest connected component
    if strcmp(aTk,'nrnd') % RANDOM ATTACK
        cur_N=n;
        i=1;
        y2u(i,1)=max((cur_N-sum(dmperm(adj)>0)),1)/cur_N;
        [pts(i,1),~]=graphconncomp(sparse(adj),'Directed',true,'Weak',true);
        while(cur_N>1)
            j=randperm(cur_N); pos=j(1);
            adj(pos,:)=[];  adj(:,pos)=[];  % node-removal
            cur_N=size(adj,1);
            i=i+1;
            y2u(i,1)=max((cur_N-sum(dmperm(adj)>0)),1)/cur_N;
            % --- lcc --- %
            [ncp,cls]=graphconncomp(sparse(adj),'Directed',true,'Weak',true);
            pts(i,1)=ncp;
            tmpi=max(cls);  tmps=zeros(tmpi,1);
            for ii=1:tmpi;  tmps(ii)=sum(cls==ii);  end
            lcc(i,1)=max(tmps);
        end
    else % TARGETED ATTACK
        cur_N=n;
        i=1;
        y2u(i,1)=max((cur_N-sum(dmperm(adj)>0)),1)/cur_N;
        [pts(i,1),~]=graphconncomp(sparse(adj),'Directed',true,'Weak',true);
        % --- lcc --- %
        [ncp,cls]=graphconncomp(sparse(adj),'Directed',true,'Weak',true);
        pts(i,1)=ncp;
        tmpi=max(cls);  tmps=zeros(tmpi,1);
        for ii=1:tmpi;  tmps(ii)=sum(cls==ii);  end
        lcc(i,1)=max(tmps);
        while cur_N>1
            switch aTk
                case'nbet';     pos=max_bet;
                case'ndeg';     pos=max_deg;
                %case'ncrir';	[pos,~]=cri_rnd('node',bat);
            end
            adj(pos,:)=[];  adj(:,pos)=[];  cur_N=size(adj,1);  % node-removal
            i=i+1;
            y2u(i,1)=max((cur_N-sum(dmperm(adj)>0)),1)/cur_N;
            % --- lcc --- %
            [ncp,cls]=graphconncomp(sparse(adj),'Directed',true,'Weak',true);
            pts(i,1)=ncp;
            tmpi=max(cls);  tmps=zeros(tmpi,1);
            for ii=1:tmpi;  tmps(ii)=sum(cls==ii);  end
            lcc(i,1)=max(tmps);
        end
        y2u=[y2u;1];
        pts=[pts;1];
        lcc=[lcc;1];
    end
    res.y2u=y2u;
    res.pts=pts;
    res.lcc=lcc;

    function pos=max_deg
        k=sum(adj,2);   % consider 'out-degree'
        [~,p]=sort(k,'descend');
        pos=p(1);
    end
    % -----  -----  -----  -----  -----  -----  -----  -----  ----- %
    % function 'betweenness_centrality_mex' is from MatlabBGL: more information:
    % https://www.cs.purdue.edu/homes/dgleich/packages/matlab_bgl/
    % -----  -----  -----  -----  -----  -----  -----  -----  ----- %
   function pos=max_bet
        if ~issparse(adj); adj=sparse(adj); end
        [vc,~]=betweenness_centrality_mex(adj,'matrix');
        [~,p]=sort(vc,'descend');
        pos=p(1);
    end
end

