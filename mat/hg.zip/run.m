

clearvars;
clc;
close all;

NET={'rt';'rr';'rp';'rh';};
COL={'r'; 'b'; 'g'; 'k'; };
n =200;
m =n*5;
aTk='nrnd';  % ={'nbet'; 'ndeg'; 'nrnd';};
Rept=5;

figure(1); hold on; grid on;
for nex=1:length(NET)
    net=NET{nex};
    res=attack(n,m,net,aTk,Rept);
    L{nex}=plot(res.y2u,COL{nex},'linewidth',1);
end
LGD=legend([L{1},L{2},L{3},L{4}],{'RT','RR','RP','RH'},'Location','best','fontsize',12);
legend boxoff %set(LGD,'color','none');
title('Controllability Robustness Comparison')
ylim([0,1]);  xlim([0,n]);  xticks(0:round(n/5):n);  xticklabels({'0','0.2','0.4','0.6','0.8','1'});  yticks(0:.2:1)
ylabel('\it{n_D}')
xlabel('\it{\delta}') %
    