% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Source Code for the paper: Y.Lou, L.Wang, K.F.Tsang & G.Chen,
%   "Towards Optimal Robustness of Network Controllability: An 
%   Empirical Necessary Condition," IEEE Transactions on Circuits
%   and Systems I: Regular Papers, 2020.
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% check: 1) connectivity
%        2) isomorphism
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 05 April 2020 (felix.lou@my.cityu.edu.hk)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function val = check_adj(A_HIST,A)
% if    val==1      ... discard the instance
% else  val==0      ... OK, use this instance
    if isempty(A_HIST) 
        if graphconncomp(sparse(A),'directed',true,'weak',true)>1
            val = 1;
        else
            val = 0;
        end
        return
    end
    if ~issparse(A);  A=sparse(A);  end
    val = 0;
    if graphconncomp(sparse(A),'directed',true,'weak',true)>1
        val = 1;
    else
        G1 = digraph(A);
        LenH = length(A_HIST);
        for idx =1:LenH
            G2 = digraph(A_HIST{idx}.A);
            if ~isempty(isomorphism(G1,G2))  %% G1 and G2 are isomophic
                val = 1;
                return
            end
        end
    end
end
