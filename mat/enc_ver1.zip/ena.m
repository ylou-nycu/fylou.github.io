% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Source Code for the paper: Y.Lou, L.Wang, K.F.Tsang & G.Chen,
%   "Towards Optimal Robustness of Network Controllability: An 
%   Empirical Necessary Condition," IEEE Transactions on Circuits
%   and Systems I: Regular Papers, 2020.
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% ena - Exhaustive Node-removal Attack
%       small-scaled networks with node removal
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 05 April 2020 (felix.lou@my.cityu.edu.hk)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

close all;
clear all;
clc;
% Parameter Settings
N = 4;          % Set N \in [3,6]
M = 6;          % Set M \in [N,N*(N-1)];
flgPlot = 1;	% plot or not
% Default Parameters
if M>N*(N-1);   error('wrong M (M <= N*(N-1) ... ');   end
ind  = 1:N^2;   ind(1:(N+1):N^2) = [];	% possible positions in a Matrix
% {Exhaustive[1]: All possible instances with given N & M are considered.}
% isomorphism will be removed in 'check_adj'
pea  = nchoosek(ind,M);     % [pea] possible edge arrangement
lenp = size(pea,1);         % length of pea
if (false);   pea = pea(randperm(lenp),:);   end   % set [true] if pea need shuffle
% {Exhaustive[2]: All possible node-removal sequences are considered.}
nrs = perms(1:N);  % [nrs] (all) node_removal_sequences
n = size(nrs,1);
disp([' -----  Exhaustive Node Attack (N=',int2str(N),', M=',int2str(M),')  -----'])
adjAll = cell(lenp,6);
cntA = 0;
A_HIST = [];

for edx = 1:lenp
    if ~mod(edx,floor(lenp/1e3));   disp(['  ... ',num2str(edx/lenp*1e3),'/1000 done ...']);   end
    A = zeros(N,N);
    A(pea(edx,:)) = 1;
    cur_m = sum(A,'all'); if cur_m~=M; error('  --> edge sum error here ... '); end
    if ~check_adj(A_HIST,A)	% check isomorphism
        cntA = cntA+1;
        A_HIST{cntA}.A = A;
        y2uA = zeros(n,N-1);
        for idx = 1:n       % all n attack sequences
            AA = A;
            % structural controllability 
            y2uA(idx,1) = max((N-sum(dmperm(AA)~=0)),1)/N;
            for jdx=2:N
                kdx = nrs(idx,jdx);
                AA(kdx,:)=0;  AA(:,kdx)=0;
                y2uA(idx,jdx) = max((N-sum(dmperm(AA)~=0)),1)/N;
            end
        end
        adjAll{cntA,1} = sparse(A);             % the adjacency matrix
        adjAll{cntA,2} = y2uA;                  % all controllability curves
        adjAll{cntA,3} = mean(y2uA,1);          % average controllability curve
        adjAll{cntA,4} = mean(adjAll{cntA,3});  % average controllability score
        acs(cntA,1)    = adjAll{cntA,4};        % all average controllability scores
    end
end
adjAll(cntA+1:end,:) = [];
rk = rktb(acs,cntA,1);
for idx = 1:cntA
    adjAll{idx,5} = rk(idx);
end
ub = ceil (M/N);
lb = floor(M/N);
cntEnc = 0;
lstEnc = [];
for idx = 1:cntA
    A = full(adjAll{idx,1});
    a = sum(A,1);
    b = sum(A,2);
    if any(a>ub) || any(a<lb) || any(b>ub) || any(b<lb)
        % ... does not satisfy ENC
        adjAll{idx,6} = [];
    else
        cntEnc = cntEnc+1;
        adjAll{idx,6} = cntEnc;
        lstEnc = [lstEnc;idx];
    end
end

disp(['Result: Given N=',int2str(N),', M=',int2str(M),', there are ',int2str(cntA),' possible instances.'])
disp(['        Number of instances satisfying ENC: ',int2str(cntEnc),'.'])
disp(['        Number of optimal instances: ',int2str(length(find(rk == min(rk)))),'.'])

if flgPlot
    disp('plotting ... ')
    disp('  >>  Figure#1  Optimal Instances (OI)')
    disp('  >>  Figure#2  ENC-satisfied Instances (ENC, inclueding OI)')
    figure(1)  %title(['Optimal Instance (N=',int2str(N),' M=',int2str(M),')'])
    oidx = find(rk == min(rk));
    lenx = length(oidx);
    W = min(5,lenx);
    H = ceil(lenx/W);
    for idx = 1:lenx
        sbp(H,W,idx)
        G = digraph(adjAll{oidx(idx),1});
        plot(G,'layout','circle','NodeColor','k','EdgeColor','b','NodeLabel',{})
        text(0.75,0.75,'OI')
        set(gca,'visible','off')
    end
    figure(2)
    lenx = length(lstEnc);
    W = min(5,lenx);
    H = ceil(lenx/W);
    for idx = 1:lenx
        sbp(H,W,idx)
        G = digraph(adjAll{lstEnc(idx),1});
        if any(oidx==lstEnc(idx)) 
            plot(G,'layout','circle','NodeColor','k','EdgeColor','b','NodeLabel',{})
            text(0.75,0.75,'OI')
        else
            plot(G,'layout','circle','NodeColor','k','EdgeColor','k','NodeLabel',{})
            text(0.75,0.75,'ENC')
        end
        set(gca,'visible','off')
    end
end
fname = ['exhAtk_N',int2str(N),'M',int2str(M)];
line1 = {'Adj Mat', 'All Ctrl Cvs', 'Avg Ctrl Cv', 'Ave Ctrl Val', 'Ctrl Rank', 'ENC'};
Res = [line1;adjAll];
readme = {'Adj Mat = adjacency matrix';
          'All Ctrl Cvs = all controllability curves';
          'Avg Ctrl Cv = mean controllability curve';
          'Ave Ctrl Val = mean controllability value';
          'Ctrl Rank = contrllability rank';
          'ENC = integer: an ENC instance (numbered 1,2,3, ...); []: a non-ENC instance'};
save(fname,'Res','readme')

% in 'adjAll'
% column[1] - adjacency matrix of the natwork instance
% column[2] - results of exhaustive node-removals (all controllability curves)
% column[3] - mean controllability curve
% column[4] - mean of mean controllability curve
% column[5] - contrllability rank
% column[6] - integer: an ENC instance (numbered 1,2,3, ...); []: a non-ENC instance

