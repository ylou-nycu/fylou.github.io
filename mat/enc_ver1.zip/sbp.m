% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Source Code for the paper: Y.Lou, L.Wang, K.F.Tsang & G.Chen,
%       "Towards Optimal Robustness of Network Controllability:
%       An Empirical Necessary Condition," IEEE Transactions on
%       Circuits and Systems I: Regular Papers,
%       doi:10.1109/TCSI.2020.2986215, (2020).
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% sbp - subplot
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 29 April 2020 (felix.lou@my.cityu.edu.hk)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function h = sbp(n,m,i,L,B,W,H)
    if nargin==3
        L=0;  B=0.01;  W=0.9;  H=0.9;
    end
    [c,r] = ind2sub([m n], i);
    ax = subplot('Position', [(c-1)/m+L,1-(r)/n+B,1/m*W,1/n*H]);
    if nargout>0
        h = ax;
    end    
end