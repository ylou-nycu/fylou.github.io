% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Source Code for the paper: Y.Lou, N.Wang, K.F.Tsang & G.Chen,
% "Towards Optimal Robustness of Network Controllability: An Empirical
% Necessary Condition," in arXiv:1912.12416 (Preprint 2019).
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% sfn - directed Scale-Free network
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Updated: 25 Mar 2020 (felix.lou@my.cityu.edu.hk)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function A = sfn(N,nlink,sfpara)
% Input:  N - # of nodes
%     nlink - # of links
%    sfpara - parameter of SF-network (default setting is given here)
% Output: A -

    if nargin==2
        sfpara.theta = 0;
        sfpara.mu    = 0.999;
    elseif nargin==3
        sfpara.theta = 0;
        sfpara.mu    = 0.999;
    end
    A = zeros(N,N);
    w = ((1:N)+sfpara.theta).^(-sfpara.mu);
    ransec = cumsum(w);
    cnt = 0;
    
    while cnt < nlink
        r = rand*ransec(end);
        for i=1:N
            if r<=ransec(i)
                break;
            end
        end
        r = rand*ransec(end);
        for j=1:N
            if r<=ransec(j)
                break;
            end
        end
        if i~=j && (~A(i,j)) && (~A(j,i))
            A(i,j) = 1;
        end
        cnt = sum(sum(A==1));
    end
%     if graphconncomp(sparse(A),'Directed',true,'Weak',true)>1
%         disc = 1;
%     else
%         disc = 0;
%     end    
end

