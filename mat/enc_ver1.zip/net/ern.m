% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Source Code for the paper: Y.Lou, N.Wang, K.F.Tsang & G.Chen,
% "Towards Optimal Robustness of Network Controllability: An Empirical
% Necessary Condition," in arXiv:1912.12416 (Preprint 2019).
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% ern - directed ER Random-Graph Network
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Updated: 25 Mar 2020 (felix.lou@my.cityu.edu.hk)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function A = ern(N,nlink)
% Input:  N - # of nodes
%     nlink - # of links
    A = zeros(N,N);
    cnt = 0;  % link counter
    while cnt < nlink
        i = randi(N);
        j = randi(N);
        while (j==i) || A(i,j)
            i = randi(N);
            j = randi(N);
        end
        A(i,j) = 1;
        cnt = cnt+1;
    end
    if sum(A,'all')~=cnt;  error('Link Sum Error ...');  end
    
end

