% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Source Code for the paper: Y.Lou, L.Wang, K.F.Tsang & G.Chen,
%       "Towards Optimal Robustness of Network Controllability:
%       An Empirical Necessary Condition," IEEE Transactions on
%       Circuits and Systems I: Regular Papers,
%       doi:10.1109/TCSI.2020.2986215, (2020).
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% ern - directed ER Random-Graph Network
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 29 April 2020 (felix.lou@my.cityu.edu.hk)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function A = ern(N,nlink)
% Input:  N - # of nodes
%     nlink - # of links
    A = zeros(N,N);
    cnt = 0;  % link counter
    while cnt < nlink
        i = randi(N);
        j = randi(N);
        while (j==i) || A(i,j)
            i = randi(N);
            j = randi(N);
        end
        A(i,j) = 1;
        cnt = cnt+1;
    end
    if sum(A,'all')~=cnt;  error('Link Sum Error ...');  end
    
end

