% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Source Code for the paper: Y.Lou, L.Wang, K.F.Tsang & G.Chen,
%       "Towards Optimal Robustness of Network Controllability:
%       An Empirical Necessary Condition," IEEE Transactions on
%       Circuits and Systems I: Regular Papers,
%       doi:10.1109/TCSI.2020.2986215, (2020).
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% enc - empirical necessary conditions
%     - floor(M/N) <= in-/out-degree <= ceil(M/N)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 29 April 2020 (felix.lou@my.cityu.edu.hk)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function [A,t] = rectify(A,N,M,T)
% input  A - adjacency matrix
%        N - # nodes
%        M - # edges
%        T - max # of rectifications
    if (nargin==3);  T = inf;  end  % no limitation, rectify until ENC is satisfied
    ub = ceil (M/N);
    lb = floor(M/N);
    ko = sum(A,2);  % out-degree
    ki = sum(A,1);  % in-degree
    t = 0;
    if T == inf
        while (~isempty(find(ko<lb,1)) || ~isempty(find(ko>ub,1)) || ~isempty(find(ki<lb,1)) || ~isempty(find(ki>ub,1))) && t<T
            opr = randi(4);
            switch opr
                case 1  % --- 1.[lb] out-degree --- %
                    ki = sum(A,1);  % in-degree
                    ko = sum(A,2);  % out-degree
                    idx = find(ko<lb);
                    while ~isempty(idx) && t<T  % get from max(ko)
                        t = t+1;
                        jdx = find(ko == max(ko));
                        node_i = idx(randi(length(idx)));
                        node_j = jdx(randi(length(jdx)));
                        edge_to_add_i = find(A(node_i,:)==0);  edge_to_add_i(edge_to_add_i==node_i) = [];
                        edge_to_del_j = find(A(node_j,:)==1);
                        if isempty(edge_to_add_i) || isempty(edge_to_del_j)
                            error('bad instance ...');  A = 'bad_instance';  return;
                        else
                            i = edge_to_add_i(randi(length(edge_to_add_i)));
                            j = edge_to_del_j(randi(length(edge_to_del_j)));
                        end
                        A(node_i,i) = 1;
                        A(node_j,j) = 0;
                        ki = sum(A,1);  % update in-degree
                        ko = sum(A,2);  % update out-degree
                        idx = find(ko<lb);
                    end
                case 2  % --- 2.[lb] in-degree --- %
                    ki = sum(A,1);  % in-degree
                    ko = sum(A,2);  % out-degree
                    idx = find(ki<lb);
                    while ~isempty(idx) && t<T
                        t = t+1;
                        jdx = find(ki == max(ki));
                        node_i = idx(randi(length(idx)));
                        node_j = jdx(randi(length(jdx)));
                        edge_to_add_i = find(A(:,node_i)==0);  edge_to_add_i(edge_to_add_i==node_i) = [];
                        edge_to_del_j = find(A(:,node_j)==1);
                        if isempty(edge_to_add_i) || isempty(edge_to_del_j)
                            error('bad instance ...');  A = 'bad_instance';  return;
                        else
                            i = edge_to_add_i(randi(length(edge_to_add_i)));
                            j = edge_to_del_j(randi(length(edge_to_del_j)));
                        end
                        A(i,node_i) = 1;
                        A(j,node_j) = 0;
                        ki = sum(A,1);  % update in-degree
                        ko = sum(A,2);  % update out-degree
                        idx = find(ki<lb);
                    end
                case 3  % --- 3.[ub] out-degree --- %
                    ki = sum(A,1);  % in-degree
                    ko = sum(A,2);  % out-degree
                    idx = find(ko>ub);
                    while ~isempty(idx) && t<T
                        t = t+1;
                        jdx = find(ko == min(ko));
                        node_i = idx(randi(length(idx)));
                        node_j = jdx(randi(length(jdx)));
                        edge_to_del_i = find(A(node_i,:)==1);
                        edge_to_add_j = find(A(node_j,:)==0);  edge_to_add_j(edge_to_add_j==node_j) = [];
                        if isempty(edge_to_del_i) || isempty(edge_to_add_j)
                            error('bad instance ...');  A = 'bad_instance';  return;
                        else
                            i = edge_to_del_i(randi(length(edge_to_del_i)));
                            j = edge_to_add_j(randi(length(edge_to_add_j)));
                        end
                        A(node_i,i) = 0;
                        A(node_j,j) = 1;
                        ki = sum(A,1);  % update in-degree
                        ko = sum(A,2);  % update out-degree
                        idx = find(ko>ub);
                    end
                case 4  % --- 4.[ub] in-degree --- %
                    ki = sum(A,1);  % in-degree
                    ko = sum(A,2);  % out-degree
                    idx = find(ki>ub);
                    while ~isempty(idx) && t<T
                        t = t+1;
                        jdx = find(ki == min(ki));
                        node_i = idx(randi(length(idx)));
                        node_j = jdx(randi(length(jdx)));
                        edge_to_del_i = find(A(:,node_i)==1);
                        edge_to_add_j = find(A(:,node_j)==0);  edge_to_add_j(edge_to_add_j==node_i) = [];
                        if isempty(edge_to_del_i) || isempty(edge_to_add_j)
                            error('bad instance ...');  A = 'bad_instance';  return;
                        else
                            i = edge_to_del_i(randi(length(edge_to_del_i)));
                            j = edge_to_add_j(randi(length(edge_to_add_j)));
                        end
                        A(i,node_i) = 0;
                        A(j,node_j) = 1;
                        ki = sum(A,1);  % update in-degree
                        ko = sum(A,2);  % update out-degree
                        idx = find(ki>ub);
                    end
            end
        end
    else  % ----- rectify one edge each step ----- %
        while (~isempty(find(ko<lb,1)) || ~isempty(find(ko>ub,1)) || ~isempty(find(ki<lb,1)) || ~isempty(find(ki>ub,1))) && t<T
            opr = randi(4);
            switch opr
                case 1  % --- 1.[lb] out-degree --- %
                    ki = sum(A,1);  % in-degree
                    ko = sum(A,2);  % out-degree
                    idx = find(ko<lb);
                    if ~isempty(idx) && t<T  % get from max(ko)
                        t = t+1;
                        jdx = find(ko == max(ko));
                        node_i = idx(randi(length(idx)));
                        node_j = jdx(randi(length(jdx)));
                        edge_to_add_i = find(A(node_i,:)==0);  edge_to_add_i(edge_to_add_i==node_i) = [];
                        edge_to_del_j = find(A(node_j,:)==1);
                        if isempty(edge_to_add_i) || isempty(edge_to_del_j)
                            error('bad instance ...');  A = 'bad_instance';  return;
                        else
                            i = edge_to_add_i(randi(length(edge_to_add_i)));
                            j = edge_to_del_j(randi(length(edge_to_del_j)));
                        end
                        A(node_i,i) = 1;
                        A(node_j,j) = 0;
                    end
                case 2  % --- 2.[lb] in-degree --- %
                    ki = sum(A,1);  % in-degree
                    ko = sum(A,2);  % out-degree
                    idx = find(ki<lb);
                    if ~isempty(idx) && t<T
                        t = t+1;
                        jdx = find(ki == max(ki));
                        node_i = idx(randi(length(idx)));
                        node_j = jdx(randi(length(jdx)));
                        edge_to_add_i = find(A(:,node_i)==0);  edge_to_add_i(edge_to_add_i==node_i) = [];
                        edge_to_del_j = find(A(:,node_j)==1);
                        if isempty(edge_to_add_i) || isempty(edge_to_del_j)
                            error('bad instance ...');  A = 'bad_instance';  return;
                        else
                            i = edge_to_add_i(randi(length(edge_to_add_i)));
                            j = edge_to_del_j(randi(length(edge_to_del_j)));
                        end
                        A(i,node_i) = 1;
                        A(j,node_j) = 0;
                    end
                case 3  % --- 3.[ub] out-degree --- %
                    ki = sum(A,1);  % in-degree
                    ko = sum(A,2);  % out-degree
                    idx = find(ko>ub);
                    if ~isempty(idx) && t<T
                        t = t+1;
                        jdx = find(ko == min(ko));
                        node_i = idx(randi(length(idx)));
                        node_j = jdx(randi(length(jdx)));
                        edge_to_del_i = find(A(node_i,:)==1);
                        edge_to_add_j = find(A(node_j,:)==0);  edge_to_add_j(edge_to_add_j==node_j) = [];
                        if isempty(edge_to_del_i) || isempty(edge_to_add_j)
                            error('bad instance ...');  A = 'bad_instance';  return;
                        else
                            i = edge_to_del_i(randi(length(edge_to_del_i)));
                            j = edge_to_add_j(randi(length(edge_to_add_j)));
                        end
                        A(node_i,i) = 0;
                        A(node_j,j) = 1;
                    end
                case 4  % --- 4.[ub] in-degree --- %
                    ki = sum(A,1);  % in-degree
                    ko = sum(A,2);  % out-degree
                    idx = find(ki>ub);
                    if ~isempty(idx) && t<T
                        t = t+1;
                        jdx = find(ki == min(ki));
                        node_i = idx(randi(length(idx)));
                        node_j = jdx(randi(length(jdx)));
                        edge_to_del_i = find(A(:,node_i)==1);
                        edge_to_add_j = find(A(:,node_j)==0);  edge_to_add_j(edge_to_add_j==node_i) = [];
                        if isempty(edge_to_del_i) || isempty(edge_to_add_j)
                            error('bad instance ...');  A = 'bad_instance';  return;
                        else
                            i = edge_to_del_i(randi(length(edge_to_del_i)));
                            j = edge_to_add_j(randi(length(edge_to_add_j)));
                        end
                        A(i,node_i) = 0;
                        A(j,node_j) = 1;
                    end
            end
        end
    end
    
end



