% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Source Code for the paper: Y.Lou, L.Wang, K.F.Tsang & G.Chen,
%       "Towards Optimal Robustness of Network Controllability:
%       An Empirical Necessary Condition," IEEE Transactions on
%       Circuits and Systems I: Regular Papers,
%       doi:10.1109/TCSI.2020.2986215, (2020).
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% rtn - Randome Triangle Network
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 29 April 2020 (felix.lou@my.cityu.edu.hk)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function A = rtn(N,nlink,str)
ShowNLink = 0;
Tri = 3;

    MODIFY_LINK = 1;
    if nargin==1
        MODIFY_LINK = 0;  str = 'loop';  %% pure triangles 
    elseif nargin==2
        str = 'loop';
    end
    A = zeros(N,N);
    for idx=1:Tri
        A(idx,mod(idx,Tri)+1) = 1;  %% form a Loop
    end
    for idx = Tri+1:1:N
        jdx = randi(idx-1);
        neb = [find(A(jdx,:)==1),find(A(:,jdx)==1)'];
        len_neb = length(neb);
        if length(unique(neb)) < len_neb;  error('check the A matrix ... ');  end
        kdx = neb(randi(len_neb));
        if A(kdx,jdx)
            tmpv = kdx;  kdx = jdx;  jdx = tmpv;
        end
        A(idx,jdx) = 1;  %% idx -> jdx -> kdx (-> idx)
        A(kdx,idx) = 1;
        if ~strcmp(str,'loop')
            if rand < 0.5  % destroy the loop
                A(idx,jdx) = 0;  A(jdx,idx) = 1;
            end
            if rand < 0.5
                A(kdx,idx) = 0;  A(idx,kdx) = 1;
            end
        end
    end
    
    % -----| Control Exact Number of Links |----- %
    if MODIFY_LINK
        cnt = sum(sum(A==1));  %% # links counter
        deltaE = cnt - nlink;
        if deltaE > 0
            if ShowNLink;  disp(['  deleting ',int2str(deltaE),' links ...']);  end
            while cnt > nlink
                delete_alink
                cnt = sum(sum(A==1));  %% # links counter
            end
        elseif deltaE < 0
            deltaE = abs(deltaE);
            if ShowNLink;  disp(['  adding ',int2str(deltaE),' links ...']);  end
            while cnt < nlink
                add_alink  %% add 2 links each time
                cnt = sum(sum(A==1));  %% # links counter
            end
            while cnt > nlink
                delete_alink  %% delete 1 link each time
                cnt = sum(sum(A==1));  %% # links counter
            end
        end
    end
    
% -----| control exact number of links |----- %
% -----| add 2 edges each time         |----- %
% -----| delete 1 edges each time      |----- %
    function add_alink
        r = randperm(N,2);
        r1 = r(1);  r2 = r(2);
        while A(r1,r2) || A(r2,r1);  r = randperm(N,2);  r1 = r(1);  r2 = r(2);  end
        neb1 = [find(A(r2,:)==1),find(A(:,r2)==1)'];
        len_neb1 = length(neb1);
        if length(unique(neb1)) < len_neb1
            error('check the A matrix ... ');
        end
        r3 = neb1(randi(len_neb1));
        if A(r3,r2)	%% r3 -> r2
            A(r2,r1) = 1;
            if ~A(r1,r3) && ~A(r3,r1);  A(r1,r3) = 1;  end
        else        %% default r2 -> r3
            A(r1,r2) = 1;
            if ~A(r1,r3) && ~A(r3,r1);  A(r3,r1) = 1;  end
        end
        if ~strcmp(str,'loop')
            if rand < 0.5
                A(r1,r2) = ~A(r1,r2);
                A(r2,r1) = ~A(r2,r1);
            end
            if rand < 0.5
                A(r1,r3) = ~A(r1,r3);
                A(r3,r1) = ~A(r3,r1);
            end
        end
    end

    function delete_alink
        r1 = randi(N);
        neb1 = [find(A(r1,:)==1),find(A(:,r1)==1)'];
        len_neb1 = length(neb1);
        if length(unique(neb1)) < len_neb1;  error('check the A matrix ... ');  end
        r2 = neb1(randi(len_neb1));  %% default r2 -> r3
        A(r1,r2) = 0;
        A(r2,r1) = 0;
    end

end

