% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Source Code for the paper: Y.Lou, N.Wang, K.F.Tsang & G.Chen,
% "Towards Optimal Robustness of Network Controllability: An Empirical
% Necessary Condition," in arXiv:1912.12416 (Preprint 2019).
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% rrn - Randome Rectangle Network
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Updated: 25 Mar 2020 (felix.lou@my.cityu.edu.hk)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function A = rrn(N,nlink,str)
ShowNLink = 1;
Rec = 4;

    if N<5;  error('too small network ...');  end
    MODIFY_LINK = 1;
    if nargin==1;      MODIFY_LINK = 0;  str = 'loop';
    elseif nargin==2;  str = 'loop';
    end
    % 'r-loop' = rectangle-loop
    A = zeros(N,N);
    for idx=1:Rec
        A(idx,mod(idx,Rec)+1) = 1;  %% form a Loop first
    end
    
    for idx = Rec+1:2:N  %% add 2 links each time
        jdx = randi(idx-1);
        neb = [find(A(jdx,:)==1),find(A(:,jdx)==1)'];
        len_neb = length(neb);
        if length(unique(neb)) < len_neb;  error('check the A matrix ... ');  end
        kdx = neb(randi(len_neb));
        if A(kdx,jdx)
            tmpv = kdx;  kdx = jdx;  jdx = tmpv;
        end
        A(idx,jdx) = 1;  % idx -> jdx
        % (jdx -> kdx) already existing in the network
        A(kdx,idx+1) = 1;  % kdx -> idx+1
        A(idx+1,idx) = 1;  % idx+1 -> idx
        % Loop: idx -> jdx -> kdx -> idx+1 -> idx
        if ~strcmp(str,'loop')  % then, break the loops, if needed
            if rand < 0.5
                A(idx,jdx)=~A(idx,jdx);  A(jdx,idx)=~A(jdx,idx);
            end
            if rand < 0.5
                A(kdx,idx+1)=~A(kdx,idx+1);  A(idx+1,kdx)=~A(idx+1,kdx);
            end
            if rand < 0.5
                A(idx+1,idx)=~A(idx+1,idx);  A(idx,idx+1)=~A(idx,idx+1);
            end
        end
    end
    if (N-idx)~=0 && (N-idx)~=1;  error('wrong links sum ...');  end
    if (N-idx)==1  %% add just one more link, and form a triangle
        idx = N;
        jdx = randi(N-1);
        neb = [find(A(jdx,:)==1),find(A(:,jdx)==1)'];
        len_neb = length(neb);
        if length(unique(neb)) < len_neb;  error('check the A matrix ... ');  end
        kdx = neb(randi(len_neb));
        if A(kdx,jdx)
            tmpv = kdx;  kdx = jdx;  jdx = tmpv;
        end
        A(idx,jdx) = 1;  %% idx -> jdx -> kdx (-> idx)
        A(kdx,idx) = 1;
        if ~strcmp(str,'loop')
            if rand < 0.5  % destroy the loop
                A(idx,jdx) = 0;  A(jdx,idx) = 1;
            end
            if rand < 0.5
                A(kdx,idx) = 0;  A(idx,kdx) = 1;
            end
        end
    end
    if ShowNLink
        disp(['Initial RRN with ',int2str(sum(sum(A==1))),' Edges.'])
    end
    if MODIFY_LINK
        % -----| Control Exact Number of Links |----- %
        cnt = sum(sum(A==1));  %% # links counter
        deltaE = cnt-nlink;
        if deltaE > 0
            if ShowNLink;  disp(['  deleting ',int2str(deltaE),' links ...']);  end
            while cnt > nlink
                delete_alink  %% delete 1 link each time
                cnt = sum(sum(A==1));  %% # links counter
            end
        elseif deltaE < 0
            if ShowNLink;  disp(['  adding ',int2str(abs(deltaE)),' links ...']);  end
            while deltaE < -3
                add_alink  %% add 3 links each time
                cnt = sum(sum(A==1));  %% # links counter
                deltaE = cnt-nlink;
            end
            if deltaE  %% deltaE <= 3
                while cnt < nlink
                    add_one_alink
                    cnt = sum(sum(A==1));  %% # links counter
                end
            end
        end
    end
    ak = sum(sum(A==1))/(N);
    if ShowNLink
        disp(['Generated Random Rectangular Network (RRN) with ',int2str(sum(sum(A==1))),' Edges.'])
    end
    disc = 0;
    % as long as a node has no in-/out-degree
    for i = 1:N
        if all(A(i,:)==0) && all(A(:,i)==0);  disc=1;  break;  end
    end
    
% -----| control exact number of links |----- %
% -----| add 3 edges each time         |----- %
% -----| delete 1 edges each time      |----- %
    function add_alink
        r1 = randi(N);
        neb1 = find(A(r1,:)==0);
        neb1(neb1==r1) = [];
        len_neb1 = length(neb1);
        while ~len_neb1
            r1 = randi(N);  neb1 = find(A(r1,:)==0);  neb1(neb1==r1) = [];
        end
        r2 = neb1(randi(len_neb1));
        if ~A(r2,r1)  %% r1 -> r2
            A(r1,r2) = 1;
            if ~strcmp(str,'loop') && rand < 0.5
                A(r1,r2) = ~A(r1,r2);
                A(r2,r1) = ~A(r2,r1);
            end
        end
        neb1 = find(A(r2,:)==0);
        neb1(neb1==r2) = [];
        len_neb1 = length(neb1);
        if length(unique(neb1)) < len_neb1;  error('check the A matrix ... ');  end
        if ~len_neb1
            return
        end
        r3 = neb1(randi(len_neb1));
        if ~A(r3,r2)  %% r2 -> r3
            A(r2,r3) = 1;
            if ~strcmp(str,'loop') && rand < 0.5
                A(r2,r3) = ~A(r2,r3);
                A(r3,r2) = ~A(r3,r2);
            end
        end
        neb1 = find(A(r3,:)==0);
        neb1(neb1==r3) = [];
        len_neb1 = length(neb1);
        if length(unique(neb1)) < len_neb1;  error('check the A matrix ... ');  end
        if ~len_neb1
            return
        end
        r4 = neb1(randi(len_neb1));
        if ~A(r4,r3)  %% r3 -> r4
            A(r3,r4) = 1;
            if ~strcmp(str,'loop') && rand < 0.5
                A(r3,r4) = ~A(r3,r4);
                A(r4,r3) = ~A(r4,r3);
            end
        end
        if ~A(r1,r4)  %% r4 -> r1
            A(r4,r1) = 1;
            if ~strcmp(str,'loop') && rand < 0.5
                A(r1,r4) = ~A(r1,r4);
                A(r4,r1) = ~A(r4,r1);
            end
        end
    end

    function delete_alink
        r1 = randi(N);
        neb1 = [find(A(r1,:)==1),find(A(:,r1)==1)'];
        len_neb1 = length(neb1);
        if length(unique(neb1)) < len_neb1;  error('check the A matrix ... ');  end
        r2 = neb1(randi(len_neb1));  %% default r2 -> r3
        A(r1,r2) = 0;
        A(r2,r1) = 0;
    end

    function add_one_alink
        r1 = randi(N);
        neb1 = find(A(r1,:)==0);
        neb1(neb1==r1) = [];
        len_neb1 = length(neb1);
        while ~len_neb1
            r1 = randi(N);  neb1 = find(A(r1,:)==0);  neb1(neb1==r1) = [];
        end
        r2 = neb1(randi(len_neb1));
        if ~A(r2,r1)  %% r1 -> r2
            A(r1,r2) = 1;
        end
    end

end

