% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Source Code for the paper: Y.Lou, N.Wang, K.F.Tsang & G.Chen,
% "Towards Optimal Robustness of Network Controllability: An Empirical
% Necessary Condition," in arXiv:1912.12416 (Preprint 2019).
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% swm - directed Small-World Network
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Updated: 25 Mar 2020 (felix.lou@my.cityu.edu.hk)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function A = swn(N,K,nlink)
% Input: N - number of nodes
%        K - # of connected neighbours
%    nlink - the total number of links
% -----  -----  -----  -----  -----  -----  -----
ShowNLink = 1;
    if K>floor(N/2);  error('K should NOT be grater than N/2 ...');  end
    switch K
        case 0  % a single ring only
            A = diag(ones(1,N-1),1) + diag(ones(1,N-N+1),-N+1);  % just a ring
        case 1  % one jumping-back, local 3-rings
            A = diag(ones(1,N-1),1) + diag(ones(1,N-N+1),-N+1);  % just a ring
            A = A + diag(ones(1,N-2),-2) + diag(ones(N-N+2,1),N-2);
        otherwise  % K>=2
            A = diag(ones(1,N-1),1) + diag(ones(1,N-N+1),-N+1);  % just a ring
            for i=1:(K+1)
                if ~A(i,i-K-1+N) && ~A(i-K-1+N,i)
                    A(i,i-K-1+N) = 1;
                else
                    if rand<0.5
                        A(i,i-K-1+N)=0;
                        A(i-K-1+N,i)=1;
                    else
                        A(i,i-K-1+N)=1;
                        A(i-K-1+N,i)=0;
                    end
                end
            end
            for i = K+2:N
                if ~A(i,i-K-1) && ~A(i-K-1,i)
                    A(i,i-K-1) = 1;
                else
                    if rand<0.5
                        A(i,i-K-1)=0;
                        A(i-K-1,i)=1;
                    else
                        A(i,i-K-1)=1;
                        A(i-K-1,i)=0;
                    end
                end
                A(i,i-K-1) = 1;
            end
            %error('To be designed ... ')
    end
    if ShowNLink;  disp(['Initial SW with ',int2str(sum(sum(A==1))),' Edges.']);  end
    cur_N = sum(sum(A==1));
    while cur_N > nlink
        deltaE = abs(cur_N - nlink);
        for i=1:deltaE
            delete_alink
        end
        cur_N = sum(sum(A==1));
    end
    while cur_N < nlink
        deltaE = abs(cur_N - nlink);
        for i=1:deltaE
            add_alink
        end
        cur_N = sum(sum(A==1));
    end

    if sum(sum(A==1))~=nlink;  error('wrong link number sum ...');  end
    if ShowNLink
        disp(['  -> Generated SW with ',int2str(sum(sum(A==1))),' links.'])
    end
    
% ----- Functions ----- %
    function add_alink
        idx = randi(N);
        list = intersect(find(~A(idx,:)),find(~A(:,idx)));  % no connection to idx
        list(list==idx) = [];  % exclude itself
        while isempty(list)
            idx = randi(N);
            list = intersect(find(~A(idx,:)),find(~A(:,idx)));
            list(list==idx) = [];
        end
        jdx = list(randi(length(list)));
        A(idx,jdx) = 1;
    end

    function delete_alink
        idx = randi(N);
        list = intersect(find(A(idx,:)),find(A(:,idx)));  % connected to idx
        while isempty(list)
            idx = randi(N);
            list = intersect(find(A(idx,:)),find(A(:,idx)));  % connected to idx
        end
        jdx = list(randi(length(list)));
        A(idx,jdx) = 0;
    end

end

