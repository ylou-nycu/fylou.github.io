% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Source Code for the paper: Y.Lou, L.Wang, K.F.Tsang & G.Chen,
%       "Towards Optimal Robustness of Network Controllability:
%       An Empirical Necessary Condition," IEEE Transactions on
%       Circuits and Systems I: Regular Papers,
%       doi:10.1109/TCSI.2020.2986215, (2020).
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 29 April 2020 (felix.lou@my.cityu.edu.hk)
% Version: ver 1.0
% for Random_Node_Attack only
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% RUN THE CODE:
%
% 'ena.m' == exhaustive node-removal attack  (for small-scaled networks)
% 'rer.m' == randome edge rectification      (for large-scaled networks)
%
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
