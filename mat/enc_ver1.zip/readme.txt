% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Source Code for the paper: Y.Lou, L.Wang, K.F.Tsang & G.Chen,
% "Towards Optimal Robustness of Network Controllability: An 
% Empirical Necessary Condition," IEEE Transactions on Circuits
% and Systems I: Regular Papers, 2020.
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 05 April 2020 (felix.lou@my.cityu.edu.hk)
% Version: ver 1.0
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% RUN THE CODE:
%
% 'ena.m' == exhaustive node-removal attack (for small-scaled networks)
% 'rer.m' == randome edge rectification (for large-scaled networks)
%
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
