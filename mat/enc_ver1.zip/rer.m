% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Source Code for the paper: Y.Lou, L.Wang, K.F.Tsang & G.Chen,
% "Towards Optimal Robustness of Network Controllability: An Empirical
% Necessary Condition," in arXiv:1912.12416 (Preprint 2019).
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% rer - random edge rectification
% large-scaled network simulation
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Updated: 25 Mar 2020 (felix.lou@my.cityu.edu.hk)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

close all;
clear all;
clc;

net = 'sf';     % net == {'er'; 'sf'; 'mcn'; 'qsn'; 'rtn'; 'rrn'};
Rept = 10;      % number of repeated runs for random attack
max_rdx = 5;	% number of random instances with given N and M
N = 500;        % network size
AK = 10;        % average degree
M = AK*N;
flgPlot = 1;	% plot or not
NMarkers = 25;  % number of marker in plot
NRer = [0;100;1000;inf];    % compare 4 RER settings
lent = length(NRer);
disp([net,', N = ',int2str(N),', <k> = ',int2str(AK)])

res = cell(Rept,1);
tmpv = zeros(Rept,N);
cv = zeros(lent,N);
for tdx = 1:lent        % different RER operations
    max_t = NRer(tdx);
    disp(['> RER = ',int2str(max_t), '...'])
    for rdx = 1:max_rdx	% random repeat
        %disp(['    >> Rept: Generating ',int2str(rdx),'/',int2str(max_rdx),' instance for attack ...'])
        res{rdx} = atk(net,N,M,Rept,max_t);
        tmpv(rdx,:) = res{rdx}.y;
    end
    cv(tdx,:) = mean(tmpv,1);
end
len = size(cv,2);
Itv = floor(len/NMarkers);
i = 0;
for idx = 1:len
    if ~mod(idx,Itv)
        i = i+1;
        sp_cv(:,i) = cv(:,idx);
    end
end

if flgPlot
    figure(1);  hold on;  grid on
    L1 = plot(sp_cv(1,:),'rs');
    L2 = plot(sp_cv(2,:),'bd');
    L3 = plot(sp_cv(3,:),'g^');
    L4 = plot(sp_cv(4,:),'ko');
    legend([L1 L2 L3 L4], {'RER = 0', 'RER = 100', 'RER = 1000', 'RER = Inf'},'Location','southeast')
    xlabel('\it{n_D}')
    ylabel('\it{P_N}')
    t = title(net,'FontName','Verdana','FontSize',14,'FontWeight','bold','Units','normalized','Position',[0.05,0.95,0],'horizontalAlignment','left');
    set(gca,'YScale','log')
end


              