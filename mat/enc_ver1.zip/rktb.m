% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Source Code for the paper: Y.Lou, L.Wang, K.F.Tsang & G.Chen,
%   "Towards Optimal Robustness of Network Controllability: An 
%   Empirical Necessary Condition," IEEE Transactions on Circuits
%   and Systems I: Regular Papers, 2020.
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% rktb - rank table ver2.0
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 05 April 2020 (felix.lou@my.cityu.edu.hk)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function rk = rktb(v,N,L)
    [n,len] = size(v);
    if n~=N || len~=L
        if n==L && len==N
            v = v';
        else
            error('Wrong size of input ... ')
        end
    end
    rk = zeros(size(v));    
    for idx=1:L
        tmpv = v(:,idx);        % a temp vector
        tmprk = zeros(size(tmpv));
        sdk = 1;
        while ~all(tmpv==inf)	% not all values are 'inf'
            min_pos = find(tmpv==min(tmpv));
            len_mp = length(min_pos);
            for jdx = 1:len_mp
                tmprk(min_pos(jdx)) = sum(sdk:(sdk+len_mp-1))/len_mp;
                tmpv(min_pos(jdx)) = inf;  % 'inf' means the position has been ranked
            end
            sdk = sdk+len_mp;
        end
        rk(:,idx) = tmprk;
    end
end

