% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Source Code for the paper: Y.Lou, L.Wang, K.F.Tsang & G.Chen,
%   "Towards Optimal Robustness of Network Controllability: An 
%   Empirical Necessary Condition," IEEE Transactions on Circuits
%   and Systems I: Regular Papers, 2020.
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% atk - attack
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 05 April 2020 (felix.lou@my.cityu.edu.hk)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function res = atk(net,N,M,Rept,max_t)
% Input:  net - type of network
%           N - network size
%           M - number of edges
%        Rept - number of repeated runs, given the same A
%       max_t - max number of rectifications
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
    addpath('net')
    % ----- check some input variables ----- %
    if ~exist('max_t','var');   max_t = inf;   end
    r_qs  = 2;	%% r for q-snapback network
    switch net
        case 'er'  % ER
            A = ern(N,M);
        case 'sf'  % SF
            A = sfn(N,M);
        case 'sw'  % default K=2
            A = swn(N,2,M);
        case 'qsn' % QSN
            itop = 'chain';  %% initial topology
            q = q_nlink(r_qs,N,'e2q',M);
            A = qsn(r_qs,N,q,M,itop);
        case 'rtn' % Randome Triangle Network
            str = 'loop';
            A = rtn(N,M,str);
        case 'rrn' % Randome Rectangle Network
            str = 'loop';
            A = rrn(N,M,str);
        otherwise
            error('   more network types in the future ...')
    end
    A = rectify(A,N,M,max_t);
    res = rnr(A,N,Rept);
end

