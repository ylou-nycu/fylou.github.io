% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Source Code for the paper: Y.Lou, L.Wang, K.F.Tsang & G.Chen,
%   "Towards Optimal Robustness of Network Controllability: An 
%   Empirical Necessary Condition," IEEE Transactions on Circuits
%   and Systems I: Regular Papers, 2020.
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% rnr - random node removal
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 05 April 2020 (felix.lou@my.cityu.edu.hk)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

function res = rnr(A,N,Rept)
    AA = A;  % backup A
    tmpv = zeros(N,Rept);
    gcp = zeros(Rept,1);	% generation when the graph disconnected
    for t = 1:Rept
        % disp(['    rnr - ',int2str(t),'/',int2str(Rept),' ..'])
        A = AA;	%% get original A
        cur_N = N;      % do not change N, change cur_N
        i = 1;
        brd = 0;        % brd = break into 2(or+) pieces
        while cur_N>1
            j = randi(cur_N);  % Revove a random node
            A(j,:) = [];  A(:,j) = [];
            cur_N = size(A,1);
            tmpv(i,t) = max((cur_N-sum(dmperm(A)~=0)),1)/cur_N;
            if (~brd) && (graphconncomp(sparse(A),'Directed',true,'Weak',true)>1)
                gcp(t,1) = i;
                brd = 1;
            end
            i = i+1;
        end 
    end
    y = mean(tmpv,2);
    res.y = y;
    res.g = gcp;
    % -----  ----- | RANDOM ATTACK | -----  ----- %
end


