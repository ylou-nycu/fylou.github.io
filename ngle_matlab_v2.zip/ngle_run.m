% ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====	* =====     %
% ARTICLE: YANG LOU & GUANRONG CHEN, "ANALYSIS OF THE "NAMING GAME" WITH	%
%          LEARNING ERRORS IN COMMUNICATIONS". SCIENTIFIC REPORTS. 5.12191.	%
% ONLINE AVAILABLE: http://www.nature.com/articles/srep12191                %
% PROGRAMMER: YANG LOU (http://www.ee.cityu.edu.hk/~ylou/)               	%
% ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====	* =====     %
% LAST UPDATED: 11-JULY-2015.
% ===== * ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====     %
% % Copyright (c) 2015 Yang Lou and Guanrong Chen. 
% % All rights reserved.
% % 
% % Redistribution and use in source and binary forms, with or without
% % modification, are permitted provided that the following conditions are met: 
% % 
% % 1. Redistributions of source code must retain the above copyright notice, this
% %    list of conditions and the following disclaimer. 
% % 2. Redistributions in binary form must reproduce the above copyright notice,
% %    this list of conditions and the following disclaimer in the documentation
% %    and/or other materials provided with the distribution. 
% % 
% % THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
% % ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
% % WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
% % DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
% % ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
% % (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
% % LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
% % ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
% % (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
% % SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
% ===== * ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====     %

clear all;
close all;

%% PARAMETERS SETTING %
REPEAT_TIME = input('Input the repeat time of simulations: ');
MAX_VOCABULARY = 1E5;       % EXTERNAL VOCABULARY: 1 ~ 1E5 %
MAX_ITER = 1E7;             % EMPIRICALLY ALL CASES IN THE PAPER WILL CONVERGE BEFORE 1E7 ITERATION %
INTERVAL = 500;             % SAMPLE FREQUENCY, RECORD DATA PER 500 INTERATION %
STORE_LENGTH = MAX_ITER / INTERVAL;
disp('1. RG/0.03;  2. RG/0.05;  3. RG/0.1;  4. SW/20/0.1;  5. SW/20/0.2;  6. SW/20/0.3; ');
disp('7. SW/40/0.1;  8. SW/40/0.2;  9. SW/40/0.3;  10. SF/25;  11. SF/50;  12. SF/75.');
ALL_NET_TYPE = input('Input the type of network: ');
N = input('Input the number of nodes (200 ~ 2000): ');
M = 800 * (N >= 800) + N * (N < 800);
TEN = 10;  % FOR CALCULATION OF SUCCESSFUL RATE: SR = SUCCEED_TIME / TEN % 
MIS_RATE = input('Input the rate of Learning error (0 ~ 0.5): ');
FIG_FLAG = input('Generate the Figures of features? (Y/N): ', 's');
% END of PARAMETER SETTING %

%% STATISTIC FEATURES %
avg_word_in_total   =	zeros (STORE_LENGTH, 1);	% AVERAGE WORD IN THE WHOLE POPULATION, WHEN CONSENSUS, IT EQUALS N  %
avg_word_difference =   zeros (STORE_LENGTH, 1);    % AVERAGE DIFFERENT WORDS IN POPULATION, WHEN CONSENSUS, IT EQUALS 0 %
success_rate        =   zeros (STORE_LENGTH, 1);    % CONSENSUS TIMES DURING EVERY TEN TIMES COMMUNICATIONS              %
avg_max_difference  =   zeros (1, 1);               % MAX NUMBER OF DIFFERENT WORDS EVER HELD BY THE POPULATION          %
converge_time       =   zeros (1, 1);               % THE TIME (NUMBER OF ITERATION) WHEN CONSENSUS                      %
% END of STATISTIC FEATURES %

%% LOOP FOR TEST GROUPS OF PARAMETERS %
for net_type = ALL_NET_TYPE : ALL_NET_TYPE
    switch net_type
        case 1
            RAND_GRAPH_P = 0.03;
            disp(['~ Random_Graph_Network, P = ', num2str(RAND_GRAPH_P)]);
            NET_TYPE = 1;  % NET_TYPE 1 IS RANDOM GRAPH %
        case 2
            RAND_GRAPH_P = 0.05;
            disp(['~ Random_Graph_Network, P = ', num2str(RAND_GRAPH_P)]);
            NET_TYPE = 1;
        case 3
            RAND_GRAPH_P = 0.1;
            disp(['~ Random_Graph_Network, P = ', num2str(RAND_GRAPH_P)]);
            NET_TYPE = 1;
        case 4
            SMALL_WORD_RP = 0.1;
            SMALL_WORD_K = 20;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
            NET_TYPE = 2;  % NET_TYPE 2 IS SMALL WORLD %
        case 5
            SMALL_WORD_RP = 0.2;
            SMALL_WORD_K = 20;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
            NET_TYPE = 2;
        case 6
            SMALL_WORD_RP = 0.3;
            SMALL_WORD_K = 20;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
            NET_TYPE = 2;
        case 7
            SMALL_WORD_RP = 0.1;
            SMALL_WORD_K = 40;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
            NET_TYPE = 2;
        case 8
            SMALL_WORD_RP = 0.2;
            SMALL_WORD_K = 40;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
            NET_TYPE = 2;
        case 9
            SMALL_WORD_RP = 0.3;
            SMALL_WORD_K = 40;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
            NET_TYPE = 2;
        case 10
            SCALE_FREE_INIT_NODE = 26;
            SCALE_FREE_NEW_EDGE = SCALE_FREE_INIT_NODE - 1;
            disp(['~ BA_Scale_Free_Network, Initial Nodes = ', num2str(SCALE_FREE_INIT_NODE), ...
                ', and New Edges Each Step = ', num2str(SCALE_FREE_NEW_EDGE)]);
            NET_TYPE = 3;  % NET_TYPE 3 IS SCALE FREE %
        case 11
            SCALE_FREE_INIT_NODE = 51;
            SCALE_FREE_NEW_EDGE = SCALE_FREE_INIT_NODE - 1;
            disp(['~ BA_Scale_Free_Network, Initial Nodes = ', num2str(SCALE_FREE_INIT_NODE), ...
                ', and New Edges Each Step = ', num2str(SCALE_FREE_NEW_EDGE)]);
            NET_TYPE = 3;
        case 12
            SCALE_FREE_INIT_NODE = 76;
            SCALE_FREE_NEW_EDGE = SCALE_FREE_INIT_NODE - 1;
            disp(['~ BA_Scale_Free_Network, Initial Nodes = ', num2str(SCALE_FREE_INIT_NODE), ...
                ', and New Edges Each Step = ', num2str(SCALE_FREE_NEW_EDGE)]);
            NET_TYPE = 3;
    end
    
    word_in_total       = zeros (REPEAT_TIME, STORE_LENGTH);        % WORD IN MEMORIES OF ALL INDIVIDUALS %
    word_difference    	= zeros (REPEAT_TIME, STORE_LENGTH);        % DIFFERENT WORDS IN ALL INDIVIDUALS %
    success             = zeros (REPEAT_TIME, STORE_LENGTH);
       
    max_word_difference = zeros (REPEAT_TIME, 1);                   % MAX_WORD_DIFFERENCE = MAX (WORD_DIFFERENCE (R, :)) %
    converge            = zeros (REPEAT_TIME, 1);
       
    for r = 1 : REPEAT_TIME  
        % E.G., REPEAT_TIME = 10 OR 20, THE RESULT IS AVERAGED IN 10 OR 20 SETS OF DATA %
    	% DISPLY SOME INFORMATION IN SCREEN FOR REFERENCE %
     	disp('-- -- -- -- -- -- -- -- -- -- ');
        disp(['Repeat run time: ', num2str(r), '/', num2str(REPEAT_TIME)]);
     	disp(['Number of nodes: ', num2str(N)]);
      	disp(['Length of memory: ', num2str(M)]);
       	disp(['Maximum iteration: ', num2str(MAX_ITER)]);
       	disp('-- -- -- -- -- -- -- -- -- -- ');

        vocabulary = 1 : MAX_VOCABULARY;   	% NOTE ZERO IS NOT A MEMBER OF VOCABULARY %
        individual = zeros(N, M);           % INDIVIDUALS ARE N-BY-? SIZED %
        is_consensus = zeros(N, 1);         % INDICATOR TO DENOTE STATUS OF INDIVIDUALS %
        is_speaker = zeros(N, 1);           % HAS BEEN A SPEAKER OR NOT %
        suc = zeros(TEN, 1);              	% SUCCESS TIME COUNTER %
        % GEBERATING THE NETWORKS %
        if NET_TYPE == 1
            [A, dis] = random_graph(N, RAND_GRAPH_P);
            % A IS THE ADJACENCY MATRIX OF NETWORK %
            % DIS IS SHORT FOR DISCONNECTED, AND THEN THE NETWORK WILL BE RE-GENERATED %
            while dis == 1
                disp('a trial of random_graph failed, re-generating ...');
               	[A, dis] = random_graph(N, RAND_GRAPH_P);
            end
        elseif NET_TYPE == 2
          	[A, dis] = ws_small_world(N, SMALL_WORD_RP, SMALL_WORD_K);
           	while dis == 1
                disp('a trial of ws_small_world failed, re-generating ...');
                [A, dis] = ws_small_world(N, SMALL_WORD_RP, SMALL_WORD_K);
            end
        elseif NET_TYPE == 3
            [A, dis] = scale_free(N, SCALE_FREE_INIT_NODE, SCALE_FREE_NEW_EDGE);
            while dis == 1
                disp('a trial of ba_scale_free failed, re-generating ...');
                [A, dis] = scale_free(N, SCALE_FREE_INIT_NODE, SCALE_FREE_NEW_EDGE);
            end
        else
            error('wrong network type (NET_TYPE) ...');
        end
%         disp('graph is construced ...');  % FOR TEST %

        %% NAMING GAME PROCESSING... %
        cnt = 1;      % COUNTER FOR ITERATION (THE ACTUAL ITERATION) %
        sub_cnt = 0;  % COUNTER FOR THE_ACTUAL_ITERATION / INTERVAL  %
        while cnt <= MAX_ITER
            idx = floor(rand * N) + 1;  % RANDOMLY SELECT THE SPEAKER %
            is_speaker(idx, 1) = 1;     % CHECK IF IT'S BEEN A SPEAKER %
            
            neb_arr = find (A (idx, :) == 1);  % NEB_ARR = "NEIGHBOR_ARRAY", ONE ROW AND N COLUMNS %
            if ~ isempty (neb_arr)
                jdx = neb_arr(1, floor(rand * size(neb_arr, 2) + 1));  % SELECT ONE HEARER FROM SPEAKER'S NEIGHBORS %
            else
                error('the graph is not a connected one ...');  % USUALLY IMPOSSIBLE, ONLY IF THERE IS A BUG %
            end
            
            if individual(idx, 1) == 0  % SPEAKER HAS EMPTY MEMOTY %
                individual(idx, 2) = vocabulary(1, floor(rand * MAX_VOCABULARY) + 1);
                individual(idx, 1) = individual(idx, 1) + 1;  % THE FIRST ELEMENT OF INDIVIDUAL STORES THE NUMBER OF WORDS IT HAS %
                % NOTE: THE FIRST ELEMENT OF INDIVIDUAL STORES THE NUMBER OF WORDS IT HAS,  %
                % WHILE THE SECOND ELEMENT STORES THE FIRST WORD IT HAS                     % 
            end
            len_idx = individual(idx, 1);   % GET THE SPAEKER'S NUMBER OF WORDS %
            message = individual(idx, floor(rand * len_idx) + 2);   % RONDOMLY PICK UP A WORD IN THE SPEAKER'S MEMORY %
            old_message = message;          % SAVE IT, IN CASE LEARNING ERROR OCCURS %
            MIS_FLAG = 0;
            if ~ is_speaker(jdx, 1)  % THE HEARER HAS NOT BEEN A SPEAKER YET %
                tmpl = rand;
                if tmpl < MIS_RATE
                    MIS_FLAG = 1;   % RECORD LEARNING ERROR HAS OCCURED IN COMMUNICATION %
                    message = vocabulary(1, floor(rand * MAX_VOCABULARY) + 1);
                    while message == old_message    % ERROR IS ERROR, ERROR MAKES DIFFERENCE %
                        message = vocabulary(1, floor(rand * MAX_VOCABULARY) + 1);
                    end
                end
            end
            suc_note_flag = 0;
            learning_flag = 0;
            len_jdx = individual(jdx, 1);
            if len_jdx
                for tmp_jdx = 2 : (len_jdx + 1)
                    if individual(jdx, tmp_jdx) == message  % SUCCEED, OR CONSENSUS %
                        individual(jdx, :) = 0;  % CLEAR MEMORY OF HEARER %
                        individual(idx, :) = 0;  % CLEAR MEMORY OF SPEAKER %
                        individual(jdx, 1) = 1;  % RESET HEARER'S NUMBER OF WORD %
                        individual(idx, 1) = 1;  % RESET SPEAKER'S NUMBER OF WORD %
                        individual(jdx, 2) = message;
                        if MIS_FLAG == 0
                            individual(idx, 2) = message;
                        else
                            % IF LEARNING ERROR HAPPENS, SPEAKER CONVERGE TO OLD WORD %
                            individual(idx, 2) = old_message;
                        end
                        is_consensus(jdx, 1) = 1;
                        is_consensus(idx, 1) = 1;
                        % UPDATE THE NUMBER OF SUCCESS TIME DURING THE LAST TEN INTERATION %
                        if cnt < TEN
                            suc(cnt, 1) = 1;
                        else
                            suc(1 : (TEN - 1), 1) = suc(2 : TEN, 1);
                            suc(TEN, 1) = 1;
                            suc_note_flag = 1;
                        end
                        learning_flag = 1;  % (FLAG == 1) INDICATING CONSENSUS / PSEUDO-CONSENSUS %
                        break;
                    end
                end
                
                if ~ learning_flag  % (IF FLAG == 0) NO CONSENSUS / PSEUDO-CONSENSUS HAPPENED %
                    individual(jdx, len_jdx + 2) = message;
                    individual(jdx, 1) = individual(jdx, 1) + 1;
                end
            else  % len_jdx == 0, THE HEARER HAS NOTHING IN MEMORY %
                individual(jdx, 2) = message;
                individual(jdx, 1) = individual(jdx, 1) + 1;
            end
            % CALCULATE THE SUCCESS RATE %
            if ~ suc_note_flag
                if cnt < TEN
                    suc(cnt, 1) = 0;
                else
                    suc(1 : (TEN - 1), 1) = suc(2 : TEN, 1);
                    suc(TEN, 1) = 0;
                end
            end
            
            %% == TEST CONVERGENCE == %
         	conv_flag = 1;
            if find(individual(:, 1) ~= 1)  % IF ANY INDIVIDUAL HAS NO WORD OR MORE THAN ONE WORDS, NOT CONVERGED %
             	conv_flag = 0;
            else
                one_word = unique(individual(:, 2));
                if length(one_word) > 1  % IF CURRENT POPULATION HAS MORE THAN ONE DIFFERENT WORDS, NOT CONVERGED %
                  	conv_flag = 0;
                end
            end
            if conv_flag 	% CONVERGED %
                word_cnt = sum(individual(:, 1));
                word_in_total(r, sub_cnt + 1 : end) = word_cnt;
                success(r, sub_cnt + 1 : end) = 1;
                disp(['converged at generation ', num2str(cnt), '...']);
                disp(' ');
                converge(r, 1) = cnt;
                break;
            end
            % == END of TEST CONVERGENCE == %

            %% == CALCULATE FEATURES == %
            if ~ mod(cnt - 1, INTERVAL)
                sub_cnt = sub_cnt + 1;      % THE SUBSCRIPT FOR RECORD %
                word_list = zeros(1, MAX_VOCABULARY);
                 
                word_cnt = sum(individual(:, 1));
             	for idx = 1 : N
                   	len_jdx = individual(idx, 1);  
                    for jdx = 2 : (len_jdx + 1)
                        if ~ word_list(1, individual(idx, jdx))
                            word_list(1, individual(idx, jdx)) = 1;
                        end
                    end
                end
                success(r, sub_cnt) = sum(suc) / TEN;
                word_in_total(r, sub_cnt) = word_cnt;
                word_difference(r, sub_cnt) = length(find(word_list == 1));
            end
            % == END of CALCULATE FEATURES == %
            cnt = cnt + 1;

        end
        % END 'while cnt <= MAX_ITER' %
        
        max_word_difference(r, 1) = max(word_difference(r, :));
    end
    % END of REPEAT_TIME %

    for iter = 1 : STORE_LENGTH
        for rp = 1 : REPEAT_TIME
            avg_word_in_total(iter)     = avg_word_in_total(iter) + word_in_total(rp, iter);
            avg_word_difference(iter)   = avg_word_difference(iter) + word_difference(rp, iter);
          	success_rate(iter)          = success_rate(iter) + success(rp, iter);
        end
        avg_word_in_total(iter)     = avg_word_in_total(iter) / REPEAT_TIME;
        avg_word_difference(iter)   = avg_word_difference(iter) / REPEAT_TIME;
       	success_rate(iter)          = success_rate(iter) / REPEAT_TIME;
    end
    
    avg_max_difference	= sum(max_word_difference(:, 1)) / REPEAT_TIME;
    converge_time       = mean(converge);
    
    avg_word_difference = avg_word_difference(avg_word_difference >= 1);
    success_rate = success_rate(1 : length(avg_word_difference));
    avg_word_in_total = avg_word_in_total(1 : length(avg_word_difference));

    filename = ['Net_type', num2str(ALL_NET_TYPE), '.mat'];
    save (filename, 'avg_word_in_total', 'avg_word_difference', 'avg_max_difference', 'success_rate', 'converge_time');
    if strcmp(FIG_FLAG, 'y') || strcmp(FIG_FLAG, 'Y')
        ngle_figs(filename, INTERVAL);
    end
    % ALL THE AVERAGED DATA WOULD BE SAVED %                                 
    % FOR DETAILED DATA OF EACH RUN, PLEASE REFER TO THE SAME VARIABLE WITHOUT PREFIX 'AVG_' %

end
% END of ALL_NET_TYPE FOR LOOP %