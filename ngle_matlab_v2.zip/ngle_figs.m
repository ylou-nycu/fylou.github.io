% ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====	* =====     %
% ARTICLE: YANG LOU & GUANRONG CHEN, "ANALYSIS OF THE "NAMING GAME" WITH	%
%          LEARNING ERRORS IN COMMUNICATIONS". SCIENTIFIC REPORTS. 5.12191.	%
% ONLINE AVAILABLE: http://www.nature.com/articles/srep12191                %
% ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====	* =====     %
% LAST UPDATED: 12-JULY-2015.
% ===== * ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====     %

function [ output_args ] = ngle_figs(fname, itv)

load(fname);

%% PLOT AVERAGE TOTAL WORDS
subplot(3,1,1)
n = length(avg_word_in_total);
N = n * itv;
cnte = ceil(log10(N));
MAX_ITER = 10^cnte;
hold on;
ndx = 1;
for i = 1 : MAX_ITER
    if ndx > n && ~ mod(i, itv)
        plot(i, avg_word_in_total(n), 'b*');
    end
    if ndx <= n && ~ mod(i, itv)
        plot(i, avg_word_in_total(ndx), 'b*');
        ndx = ndx + 1;
    end
end
title('AVERAGE TOTAL WORDS');
xlabel('iteration');
ylabel('total');
set(gca, 'XScale', 'log');

%% PLOT AVERAGE DIFFERENT WORDS
subplot(3,1,2)
% n = length(avg_word_difference);
% N = n * itv;
hold on;
ndx = 1;
for i = 1 : MAX_ITER
    if ndx > n && ~ mod(i, itv)
        plot(i, avg_word_difference(n), 'r*');
    end
    if ndx <= n && ~ mod(i, itv)
        plot(i, avg_word_difference(ndx), 'r*');
        ndx = ndx + 1;
    end
end
title('AVERAGE DIFFERENT WORDS');
xlabel('iteration');
ylabel('difference');
set(gca, 'XScale', 'log');

%% PLOT SUCCESS RATE 
subplot(3,1,3)
% n = length(success_rate);
% N = n * itv;
hold on;
ndx = 1;
for i = 1 : MAX_ITER
    if ndx > n && ~ mod(i, itv)
        plot(i, success_rate(n), 'g+');
    end
    if ndx <= n && ~ mod(i, itv)
        plot(i, success_rate(ndx), 'g+');
        ndx = ndx + 1;
    end
end
title('SUCCESS RATE');
xlabel('iteration');
ylabel('success');
set(gca, 'XScale', 'log');

end

