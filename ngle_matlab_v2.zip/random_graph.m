% ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====	* =====     %
% ARTICLE: YANG LOU & GUANRONG CHEN, "ANALYSIS OF THE "NAMING GAME" WITH	%
%          LEARNING ERRORS IN COMMUNICATIONS". SCIENTIFIC REPORTS. 5.12191.	%
% ONLINE AVAILABLE: http://www.nature.com/articles/srep12191                %
% ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====	* =====     %
% LAST UPDATED: 12-JULY-2015.
% ===== * ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====     %
% RANDOM GRAPH NETWORK GENERATOR %

function [A, disc] = random_graph (number_of_node, connecting_probability, fig_or_not)
% INPUT:  AS ITS NAME MEANS
% OUTPUT: A: THE ADJACENCY MATRIX
%         disc: disc == 1, disconnected (NO GOOD); disc == 0, connected (OK)

    if nargin == 2 || number_of_node > 150
        fig_or_not = 0;  % DEFAULT: DO NOT DRAW THE FIGURE OP NETWORK %
    end

    A = zeros(number_of_node, number_of_node);
    disc = 0;

    if fig_or_not
        randData = rand(2, number_of_node) * 1000;
        x = randData(1, :);     % size_x = 1-by-number_of_node %
        y = randData(2, :);     % size_y = 1-by-number_of_node %
    end

    for i = 1 : (number_of_node - 1)
        for j = (i + 1) : number_of_node
            if rand <= connecting_probability && A(i, j) == 0
                A(i, j) = 1; 
                A(j, i) = 1;
            end
        end
    end

    for i = 1 : number_of_node
        if sum(A(i, :)) == 0
            disc = 1;
            break;
        end
    end
    
    if fig_or_not
        plot(x, y, 'r.', 'Markersize', 18);
        hold on;
        for i = 1 : number_of_node 
            for j = i+1 : number_of_node
                if A(i,j) ~= 0
                    plot ([x(i),x(j)], [y(i),y(j)], 'linewidth', 1);        % connet x and y with line of linewidth 1 %
                    hold on;
                end
            end
        end
        hold off;
     end

end