RUN = 'ngle_run'

--

[EXAMPLE:]

Input the repeat time of simulations: 
20	(ANY INTEGER)

1. RG/0.03;  2. RG/0.05;  3. RG/0.1;  4. SW/20/0.1;  5. SW/20/0.2;  6. SW/20/0.3; 
7. SW/40/0.1;  8. SW/40/0.2;  9. SW/40/0.3;  10. SF/25;  11. SF/50;  12. SF/75.
Input the type of network: 
4   (ANY INTEGER FROM 1 TO 12)

Input the number of nodes (200 ~ 2000): 
500 (ANY INTEGER FROM 200 TO 2000)

Input the rate of Learning error (0 ~ 0.5): 
0.1 (ANY FLOAT FROM 0 TO 0.5)

Generate the Figures of features? (Y/N): 
Y   (BOTH 'y/n' AND 'Y/N' ARE OK)

--

THE SIMULATION RESULTS ARE STORED IN "Net_type4.mat". THE STOREDVARIABLES ARE:

    -> avg_word_in_total    - THE AVERRAGE NUMBER OF TOTAL WORDS IN THE POPULATION
                              DURING THE PROPAGATION OF LEXICON.
    -> avg_word_difference  - THE AVERRAGE NUMBER OF DIFFERENT WORDS IN THE POPULATION 
                              DURING THE PROPAGATION OF LEXICON.
    -> avg_max_difference   - THE AVERRAGE MAXIMUM NUMBER OF DIFFERENT WORDS THE 
                              POPULATION EVER REACHED.
    -> success_rate         - THE AVERRAGE 'SUCCESS' COMMUNICATIONS IN LAST 10 
                              COMMUNICATIONS DURING THE PROPAGATION OF LEXICON
                              (PLEASE FIND MORE DETAILS IN THE PAPER).
    -> converge_time        - THE AVERRAGE NUMBER OF ITERATION NEEDED FOR THE 
                              POPULATION TO GET CONSENSUS.

IF INPUT 'Y/y' TO DISPLAY FEATURES, FIGURES ARE PRINTED IN SCREEN.

--

ACKNOWLEDGEMENT:

THE AUTHORS WOULD LIKE TO THANK DR. XIN ZHANG FOR CHECKING AND TESTING THE SOURCE CODE.
