% ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====	* =====     %
% ARTICLE: YANG LOU & GUANRONG CHEN, "ANALYSIS OF THE "NAMING GAME" WITH	%
%          LEARNING ERRORS IN COMMUNICATIONS". SCIENTIFIC REPORTS. 5.12191.	%
% ONLINE AVAILABLE: http://www.nature.com/articles/srep12191                %
% ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====	* =====     %
% LAST UPDATED: 14-JULY-2018.
% [14 July 2018] Felix would like to thank Mr. Jianfeng Zhou for detecting a bug here.
% ===== * ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====     %
% SCALE FREE NETWORK GENERATOR %

function [A, disc] = scale_free(number_of_node, n_initial, m_link)
% INPUT:  AS ITS NAME MEANS
% OUTPUT: A, THE ADJACENCY MATRIX
%         disc, disc == 1, disconnected (NO GOOD); disc == 0, connected (OK)

    seed = ones(n_initial, n_initial);
    pos = length(seed);    
    d_seed = eye(n_initial);
    seed = seed - d_seed;
    A = zeros(number_of_node, number_of_node, 'single');
    A(1:pos, 1:pos) = seed;
    sumlinks = sum(sum(A));

    while pos < number_of_node
        pos = pos + 1;
        linkage = 0;
        while linkage ~= m_link
            rnode = ceil(rand * (pos-1));  %% a bug "rnode = ceil(rand*pos)" was reported by Mr. Zhou
            deg = sum(A(:,rnode)) * 2;
            rlink = rand * 1;
            if rlink < deg / sumlinks && A(pos,rnode) ~= 1 && A(rnode,pos) ~= 1
                A(pos,rnode) = 1;
                A(rnode,pos) = 1;
                linkage = linkage + 1;
                sumlinks = sumlinks + 2;
            end
        end
    end

    disc = 0;
    for i = 1 : number_of_node
        if sum(A(i, :)) == 0
            disc = 1;
            break;
        end
    end

end