% ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====	* =====     %
% ARTICLE: YANG LOU & GUANRONG CHEN, "ANALYSIS OF THE "NAMING GAME" WITH	%
%          LEARNING ERRORS IN COMMUNICATIONS". SCIENTIFIC REPORTS. 5.12191.	%
% ONLINE AVAILABLE: http://www.nature.com/articles/srep12191                %
% ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====	* =====     %
% LAST UPDATED: 12-JULY-2015.
% ===== * ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====     %
% W-S SMALL WORLD NETWORK GENERATOR

function [A, disc] = ws_small_world (number_of_node, rewiring_probability, neighborhood, fig_or_not)
% INPUT:  AS ITS NAME MEANS
% OUTPUT: A, THE ADJACENCY MATRIX
%         disc, disc == 1, disconnected (NO GOOD); disc == 0, connected (OK)

    if nargin == 3
        fig_or_not = 0;  % DEFAULT: DO NOT DRAW THE FIGURE OP NETWORK %
    end
    
    A = zeros(number_of_node, number_of_node);
    disc = 0;

    if neighborhood > floor(number_of_node/2)
        error('Illegal input of neighborhood ... ');
    end

    if fig_or_not
        angle = 0: 2*pi/N : 2*pi - 2*pi/number_of_node;  % generating of coordinates of the nodes %
        x=100*sin(angle);
        y=100*cos(angle);
        plot(x,y,'ro','MarkerEdgeColor','g','MarkerFaceColor','r','markersize',8);
        hold on;
    end

% STEP1: TO BUILD THE RING SHAPED NETWORK %
    for idx = 1 : number_of_node
        for jdx = (idx+1) : (idx+neighborhood)
            jj = jdx;
            if jdx > number_of_node
                jj = mod(jdx, number_of_node);
            end
            A(idx, jj) = 1;
            A(jj, idx) = 1;  % GENERATE ADJACENT MATRIX OF THE RING-SHAPED NETWORK %
        end
    end
    
% STEP2: REWIRING ... %
    for idx = 1 : number_of_node
        for jdx = (idx+1) : (idx+neighborhood)
            jj = jdx;
            if jdx > number_of_node
                jj = mod(jdx, number_of_node);
            end
            % p1 = rand(1, 1);
            if rand < rewiring_probability  % RE-WIRING IN PROBABILITY OF REWIRING_PROBABILITY %
                A(idx, jj) = 0;
                A(jj, idx) = 0;  % TO DISCONNECT THE OLD CONNECTION %
                A(idx, idx) = inf;
                
                a = find(A(idx, :) == 0);
                rand_data = randi([1,length(a)]);
                jjj = a(rand_data);
                A(idx, jjj) = 1;
                A(jjj, idx) = 1;  % REWIRING ... %
                A(idx, idx) = 0;
            end
        end
    end
    
    for i = 1 : number_of_node
        if sum(A(i, :)) == 0
            disc = 1;
            break;
        end
    end

    if fig_or_not
        for i=1:number_of_node 
            for j=i+1:number_of_node
                if A(i,j)~=0
                    plot([x(i),x(j)],[y(i),y(j)],'linewidth',1.2); 
                    hold on; 
                end
            end
        end
        axis equal;
        hold off;
    end
end