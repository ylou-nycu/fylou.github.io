% ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====	* =====     %
% ARTICLE: Yang Lou, Guanrong Chen, and Jianwei Hu,                         %
%          "Communicating with Sentences: A Multi-Word Naming Game Model",  %
%          Physica A: Statistical Mechanics and its Applications,           %
%          https://doi.org/10.1016/j.physa.2017.08.066. (2017)              %
% ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====	* =====     %
% ONLINE AVAILABLE: https://doi.org/10.1016/j.physa.2017.08.066             %
% PROGRAMMER: YANG LOU (http://www.ee.cityu.edu.hk/~ylou/)               	%
% ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====	* =====     %
% LAST UPDATED:  20-09-2017.
% ===== * ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====     %
% % Copyright (c) 2017 Yang Lou. 
% % All rights reserved.
% % 
% % Redistribution and use in source and binary forms, with or without
% % modification, are permitted provided that the following conditions are met: 
% % 
% % 1. Redistributions of source code must retain the above copyright notice, this
% %    list of conditions and the following disclaimer. 
% % 2. Redistributions in binary form must reproduce the above copyright notice,
% %    this list of conditions and the following disclaimer in the documentation
% %    and/or other materials provided with the distribution. 
% % 
% % THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
% % ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
% % WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
% % DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
% % ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
% % (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
% % LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
% % ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
% % (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
% % SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
% ===== * ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====     %

clear;
clc;
global IN;

disp('Please choose pattern first: ')
disp('(Choose ''1'' for the five basic English pattern, ''2'' for the six man-designed pattern) ')
IN.pattern = input('Input 1 or 2? ');
while IN.pattern ~= 1 && IN.pattern ~= 2
    IN.pattern = input('Input 1 or 2? (Choose a correct number!)');
end
if IN.pattern == 2
    disp('See Figure 11 of the paper for more information about the five man-designed patterns ... ')
    IN.ptid = input('Input 1~5 to choose a man-designed pattern:');
    while IN.ptid < 1 || IN.ptid > 5
        IN.ptid = input('Input a correct number within 1~5:');
    end
else
    IN.ptid = 0;
end

IN.n = input('Input the number of nodes (e.g. 500): ');
IN.r = input('Input number of repeated runs (e.g. 30): ');

disp('Input network type: ')
disp('1. RG/0.03;  2. RG/0.05;  3. RG/0.1;  4. SW/20/0.1;  5. SW/20/0.2;  6. SW/20/0.3; ');
disp('7. SW/40/0.1;  8. SW/40/0.2;  9. SW/40/0.3;  10. SF/25;  11. SF/50;  12. SF/75.');
IN.net = input('Choose the network: ');
while IN.net > 12 || IN.net < 1 || mod(IN.net,1)
    IN.net = input('Choose a correct network ID (1~12): ');
end

% disp('Plot the converging curves or not? ')
% s = input('Y/N?  ','s');
% % while ~strcmp(s,'Y')&&~strcmp(s,'N')&&~strcmp(s,'y')&&~strcmp(s,'n')
% %     s = input('Input ''Y''/''N''?  ','s');
% % end
% switch s
%     case {'Y','y'}
%         IN.plot_flag = 1;
%     otherwise  %%case {'N','n'}
%         IN.plot_flag = 0;
% end

if IN.pattern == 1
    basic;      %% Basic Patterns
elseif IN.pattern == 2
    designed;	%% Man-Designed Patterns
else
    error('Choose a correct pattern ID, 1 or 2?')
end