% FOR CONSENSUS CHECK 
% UPDATE(DD-MM-YYYY): 28-04-2015

function [cnt_cons, len, cons_word, pos_msg, pos_hearer] = consensus_check(message, hearer)
% HEARER SHOULD NOT BE THE REAL NODE, BUT THE VECOTOR OF HEARER'S MEMORY %
% INPUT:  MESSAGE    - A VECTOR
%         HEARER     - HEARER'S MEMORY
% OUTPUT: CNT_CONS   - NUMBER OF CONSENSUS IN TOTAL
%         LEN        - LENGTH OF MESSAGE
%         CONS_WORD  - A VECTOR OF CONSENSUS WORDS
%         POS_MSG    - A VECTOR OF CONSENSUS WORD POSITION IN MESSAGE
%         POS_HEARER - A VECTOR OF CONSENSUS WORD POSITION IN HEARER'S MEMORY

    len = length(message);  % USUALLY, LEN >= 2 %
    cons = zeros(1, len);
    cons_word = [];
    pos_msg = [];
    pos_hearer = [];

    for idx = 1 : len
        pos = find(message(idx) == hearer);
        if ~ isempty(pos)
            cons_word   = [cons_word, message(idx)];
            pos_msg     = [pos_msg, idx];
            pos_hearer  = [pos_hearer, pos];
            cons(1, idx) = sum(message(idx) == hearer);
            if cons(1,idx) > 1
                error('TWO IDENTICAL WORD IN HEARER''S MEMORY ...');
            end
        else
% % %             cons(1idx) = 0;
        end
    end
    cnt_cons = sum(cons);
end