




function [total, diff, sucrate, maxdiff, total_sum, diff_sum, sucrate_mean, ...
          maxdiff_sum, conv_time] ...
          = initialization1(NUM_WCLASS, REPEAT_TIME, STORE_LENGTH)


        total   = zeros(NUM_WCLASS, REPEAT_TIME, STORE_LENGTH);  % TOTAL %
        diff    = zeros(NUM_WCLASS, REPEAT_TIME, STORE_LENGTH);  % DIFFERENT %
        sucrate = zeros(NUM_WCLASS, REPEAT_TIME, STORE_LENGTH);  % SUC RATE %
        maxdiff = zeros(NUM_WCLASS, REPEAT_TIME);                % MAX DIFFERENT %
        
        total_sum 	 = zeros(REPEAT_TIME, STORE_LENGTH);  % TOTAL %
        diff_sum	 = zeros(REPEAT_TIME, STORE_LENGTH);  % DIFFERENT %
        sucrate_mean = zeros(REPEAT_TIME, STORE_LENGTH);  % SUC RATE %
        maxdiff_sum	 = zeros(REPEAT_TIME, 1);             % MAX DIFFERENT %
        
        conv_time    = zeros(REPEAT_TIME, 1);
% %         num_rule     = zeros(REPEAT_TIME, STORE_LENGTH);  % NUMBER OF RULES IN POPULATION %

end

