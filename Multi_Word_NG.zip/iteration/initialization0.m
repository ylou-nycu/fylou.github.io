

function [avg_total, avg_total_sum, avg_diff, avg_diff_sum, avg_maxdiff,    ...
         avg_conv_time, avg_sucrate, avg_sucrate_mean,                      ...
         final_stc, final_rule, avg_degree, avg_path_length, avg_cc ] = initialization0 ...
         (NUM_WCLASS, STORE_LENGTH, REPEAT_TIME)

%% STATISTIC FEATURES %
avg_total       = zeros(NUM_WCLASS, STORE_LENGTH);   % AVERAGE TOTAL WORDS, AVERAGE FROM REPEATED RUNS %
avg_total_sum	= zeros(1, STORE_LENGTH);

avg_diff        = zeros(NUM_WCLASS, STORE_LENGTH);   % AVERAGE WORDS DIFFERENCE %
avg_diff_sum	= zeros(1, STORE_LENGTH);

avg_maxdiff     = zeros(NUM_WCLASS, 1);                 % MAX NUMBER OF TOTAL WORDS, ON AVERAGE %

avg_conv_time   = zeros(1,1);     % CONVERGENCE NOT BASED ON A SINGLE TYPE OF WORD %

avg_sucrate     = zeros(NUM_WCLASS, STORE_LENGTH);
avg_sucrate_mean= zeros(1, STORE_LENGTH);

final_stc  = cell(1, REPEAT_TIME);   
final_rule = zeros(1, REPEAT_TIME); 
% END OF STATISTIC FEATURES %

%% NETWORK STATISTIC FEATURES %
avg_degree      = zeros(1, 1);
avg_path_length = zeros(1, 1);
avg_cc          = zeros(1, 1);
% END OF NETWORK STATISTIC FEATURES %

end

