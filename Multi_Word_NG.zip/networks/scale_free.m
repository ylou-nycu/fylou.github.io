

function [SFNet, avg_deg, avg_pl, avg_cc, disc] = scale_free(Nodes, n_initial, m_link)

seed = ones(n_initial, n_initial);
pos = length(seed);
d_seed = diag(ones(1,pos),0);

seed = seed - d_seed;

%if (Nodes < pos) || (m_link > pos) || (pos < 1) || (size(size(seed)) ~= 2) || (m_link < 1) || (seed ~= seed') || (sum(diag(seed)) ~= 0)
%    error('invalid parameter value(s)');
%end

%if m_link > 5 || Nodes > 15000 || pos > 15000
%    warning('Abnormally large value(s) may cause long processing time');
%end

rand('state',sum(100*clock));

Net = zeros(Nodes, Nodes, 'single');
Net(1:pos,1:pos) = seed;
sumlinks = sum(sum(Net));

while pos < Nodes
    pos = pos + 1;
    linkage = 0;
    while linkage ~= m_link
        rnode = ceil(rand * (pos-1));
        deg = sum(Net(:,rnode)) * 2;
        rlink = rand * 1;
        if rlink < deg / sumlinks && Net(pos,rnode) ~= 1 && Net(rnode,pos) ~= 1
            Net(pos,rnode) = 1;
            Net(rnode,pos) = 1;
            linkage = linkage + 1;
            sumlinks = sumlinks + 2;
        end
    end
end

SFNet = Net;

    disc = 0;
    for i = 1 : Nodes
        if sum(SFNet(i, :)) == 0
            disc = 1;
            break;
        end
    end
    
    
    avg_deg = degree_distribution (SFNet);
    avg_pl = average_path_length (SFNet);
    avg_cc = clustering_coefficient (SFNet);
% % % % 
% % % % avg_deg = 1;
% % % % avg_pl = 1;
% % % % avg_cc = 1;

%     clk = clock;
%     fname = ['network_info/ws_small_world_[(',num2str(clk(1, 2)), '-', num2str(clk(1, 3)), ')', ...
%         num2str(clk(1, 4)), '-', num2str(clk(1, 5)), '-', num2str(floor(clk(1, 6))), ']'];
%     save(fname, 'SFNet', 'disc', 'clst_coef', 'dgr_dstb', 'avg_path_lgth');
    
clear Nodes deg linkage pos rlink rnode sumlinks m_link