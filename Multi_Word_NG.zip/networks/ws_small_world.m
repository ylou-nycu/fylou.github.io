% return A, the adjacency matrix %
% return disc, disc == 1, disconnected; disc == 0, connected (OK) %

function [A, avg_deg, avg_pl, avg_cc, disc] = ws_small_world (number_of_node, rewiring_probability, neighborhood, fig_or_not)
% generate a WS_network with N nodes and 2K neighbours  %
% small world %

if nargin == 3
    fig_or_not = 0;     % default: do not draw the figure op network %
end

N = number_of_node;
K = neighborhood;
p = rewiring_probability;

disc = 0;

if K > floor(N/2)
    error('Illegal input of K ... ');
end

if fig_or_not
    angle = 0: 2*pi/N : 2*pi - 2*pi/N;  % generating of coordinates of the nodes %
    x=100*sin(angle);
    y=100*cos(angle);
    plot(x,y,'ro','MarkerEdgeColor','g','MarkerFaceColor','r','markersize',8);
    hold on;
end

A = zeros(N, N);

% step1: to build the ring shaped network %
    for idx = 1 : N
        for jdx = (idx+1) : (idx+K)
            jj = jdx;
            if jdx > N
                jj = mod(jdx, N);
            end
            A(idx, jj) = 1;
            A(jj, idx) = 1;         % generate adjacent matrix of the ring-shaped network %
        end
    end
    
% step2: rewiring ... %
    for idx = 1 : N
        for jdx = (idx+1) : (idx+K)
            jj = jdx;
            if jdx > N
                jj = mod(jdx, N);
            end
            % p1 = rand(1, 1);
            if rand < p                 % re-wiring in probability of p %
                A(idx, jj) = 0;
                A(jj, idx) = 0;         % to disconnect the old connection %
                A(idx, idx) = inf;
                
                a = find(A(idx, :) == 0);
                rand_data = randi([1,length(a)]);
                jjj = a(rand_data);
                A(idx, jjj) = 1;
                A(jjj, idx) = 1;        % rewiring ... %
                A(idx, idx) = 0;
            end
        end
    end
    
    for i = 1 : N
        if sum(A(i, :)) == 0
            disc = 1;
            break;
        end
    end

    if fig_or_not
        for i=1:N 
            for j=i+1:N
                if A(i,j)~=0
                    plot([x(i),x(j)],[y(i),y(j)],'linewidth',1.2); 
                    hold on; 
                end
            end
        end
        axis equal;
        hold off;
    end
    
% % %      avg_deg = 0;
% % %      avg_pl = 0;
% % %      avg_cc = 0;

     avg_deg = degree_distribution (A);
     avg_pl = average_path_length (A);
     avg_cc = clustering_coefficient (A);


%     clk = clock;
%     fname = ['network_info/ws_small_world_[(',num2str(clk(1, 2)), '-', num2str(clk(1, 3)), ')', ...
%         num2str(clk(1, 4)), '-', num2str(clk(1, 5)), '-', num2str(floor(clk(1, 6))), ']'];
%     save(fname, 'A', 'disc', 'clst_coef', 'dgr_dstb', 'avg_path_lgth');
 
end