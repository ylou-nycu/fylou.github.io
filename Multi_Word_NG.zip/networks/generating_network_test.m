
function [avg_degree, avg_path_length, avg_cc] = generating_network_test(net_class, net_para, avg_degree, avg_path_length, avg_cc, N)

global A;

% RECOMMEND: net_para = 1:10
% net_class = ___;
    
    switch net_class
        case 1  % RG %
            NET_TYPE = 1;   % NET_TYPE = net_class;
            RAND_GRAPH_P = 0.02 * net_para;
            disp(['~ Random_Graph_Network, P = ', num2str(RAND_GRAPH_P)]);
        case 2
            NET_TYPE = 2;
            SMALL_WORD_RP = 0.1 * net_para;
            SMALL_WORD_K = 50;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
        case 3
            NET_TYPE = 2;
            SMALL_WORD_RP = 0.1 * net_para;
            SMALL_WORD_K = 60;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
        case 4
            NET_TYPE = 2;
            SMALL_WORD_RP = 0.1 * net_para;
            SMALL_WORD_K = 70;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
        case 5
            NET_TYPE = 2;
            SMALL_WORD_RP = 0.1 * net_para;
            SMALL_WORD_K = 80;
            disp(['~ WS_Small_World_Network, RP = ', num2str(SMALL_WORD_RP), ', and K = ', num2str(SMALL_WORD_K)]);
        case 6
            NET_TYPE = 3;
            SCALE_FREE_INIT_NODE = 20 * net_para + 1;
            SCALE_FREE_NEW_EDGE = SCALE_FREE_INIT_NODE - 1;
            disp(['~ BA_Scale_Free_Network, Initial Nodes = ', num2str(SCALE_FREE_INIT_NODE), ...
                ', and New Edges Each Step = ', num2str(SCALE_FREE_NEW_EDGE)]);
    end
    
    % GENERATING OF NETWORKS %
            if NET_TYPE == 1
                [A, avg_deg, avg_pl, avg_cce, dis] = random_graph(N, RAND_GRAPH_P);
                if dis
                    tmp_cnt = 10;
                    while dis == 1 && tmp_cnt  % AT THE MOST RE-GENERATE NETWORK TEN TIMES %
                        [A, avg_deg, avg_pl, avg_cce, dis] = random_graph(N, RAND_GRAPH_P);
                        tmp_cnt = tmp_cnt - 1;
                    end
                end
                avg_degree (net_class, 1) = avg_degree (net_class, 1) + avg_deg;
                avg_path_length (net_class, 1) = avg_path_length (net_class, 1) + avg_pl;
                avg_cc (net_class, 1) = avg_cc (net_class, 1) + avg_cce;
            elseif NET_TYPE == 2
                [A, avg_deg, avg_pl, avg_cce, dis] = ws_small_world(N, SMALL_WORD_RP, SMALL_WORD_K);
                if dis
                    tmp_cnt = 10;
                    while dis == 1 && tmp_cnt  % AT THE MOST RE-GENERATE NETWORK TEN TIMES %
                        [A, avg_deg, avg_pl, avg_cce, dis] = ws_small_world(N, SMALL_WORD_RP, SMALL_WORD_K);
                        tmp_cnt = tmp_cnt - 1;
                    end
                end
                avg_degree(net_class, 1) = avg_degree(net_class, 1) + avg_deg;
                avg_path_length(net_class, 1) = avg_path_length(net_class, 1) + avg_pl;
                avg_cc (net_class, 1) = avg_cc (net_class, 1) + avg_cce;
            elseif NET_TYPE == 3
                [A, avg_deg, avg_pl, avg_cce, dis] = scale_free(N, SCALE_FREE_INIT_NODE, SCALE_FREE_NEW_EDGE);
                if dis
                    tmp_cnt = 10;
                    while dis == 1 && tmp_cnt  % AT THE MOST RE-GENERATE NETWORK TEN TIMES %
                        [A, avg_deg, avg_pl, avg_cce, dis] = scale_free(N, SCALE_FREE_INIT_NODE, SCALE_FREE_NEW_EDGE);
                        tmp_cnt = tmp_cnt - 1;
                    end
                end
                avg_degree (net_class, 1) = avg_degree (net_class, 1) + avg_deg;
                avg_path_length (net_class, 1) = avg_path_length (net_class, 1) + avg_pl;
                avg_cc (net_class, 1) = avg_cc (net_class, 1) + avg_cce;
            else
                error('wrong network type (NET_TYPE) ...');
            end
            disp('graph is construced ...');

% % 	fname = ['Net', int2str(net_class), 'Para', int2str(net_para) ];
% %     save(fname, 'A');
            
end