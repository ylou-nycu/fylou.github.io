function aver_D = average_path_length (A)

% Input : the adjacent matrix
% Get the distances of any pair of nodes using 'Floyd algorithm', and get it averaged %

N = size(A, 2);
D = A;
D(D == 0) = inf;    % transform the adjacent matrix to adjacent distance matrix, self-distance is 0, and unconnected infinity %

for i = 1 : N           
    D(i, i) = 0;       
end

for k = 1 : N           % Floyd algorithm, to calculate the minimal distances between any two nodes %
    for i = 1 : N
        for j = 1 : N
            if D(i, j) > D(i, k) + D(k, j)
                D(i, j) = D(i, k) + D(k, j);
            end
        end
    end
end

aver_D = sum( sum( D )) / (N * (N - 1));  % averaged path length %

% % if aver_D == inf
% %      error('It is not a connected graph ... ');
% % end

end