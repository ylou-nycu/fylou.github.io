% version updated: 20/09/2017
% any comments, suggestions, bug report, please send e-mail to felix.lou@my.cityu.edu.hk
% many thanks for you attention of our work !!!

Run = 'MWNG.m'


