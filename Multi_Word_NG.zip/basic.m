% -----  -----  -----  -----  -----  -----  -----  -----  -----  -----      %
% ARTICLE: Yang Lou, Guanrong Chen, and Jianwei Hu,                         %
%          "Communicating with Sentences: A Multi-Word Naming Game Model",  %
%          Physica A: Statistical Mechanics and its Applications,           %
%          https://doi.org/10.1016/j.physa.2017.08.066. (2017)              %
% -----  -----  -----  -----  -----  -----  -----  -----  -----  -----      %
% ONLINE AVAILABLE: https://doi.org/10.1016/j.physa.2017.08.066             %
% PROGRAMMER: YANG LOU (http://www.ee.cityu.edu.hk/~ylou/)               	%
% -----  -----  -----  -----  -----  -----  -----  -----  -----  -----      %
% LAST UPDATED:  16-09-2017.
% -----  -----  -----  -----  -----  -----  -----  -----  -----  -----      %
% % Copyright (c) 2017 Yang Lou, Guanrong Chen, and Jianwei Hu.
% % All rights reserved.
% % 
% % Redistribution and use in source and binary forms, with or without
% % modification, are permitted provided that the following conditions are met: 
% % 
% % 1. Redistributions of source code must retain the above copyright notice, this
% %    list of conditions and the following disclaimer. 
% % 2. Redistributions in binary form must reproduce the above copyright notice,
% %    this list of conditions and the following disclaimer in the documentation
% %    and/or other materials provided with the distribution. 
% % 
% % THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
% % ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
% % WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
% % DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
% % ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
% % (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
% % LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
% % ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
% % (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
% % SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
% ===== * ===== * ===== * ===== * ===== * ===== * ===== * ===== * =====     %
% Note that 'Rule' == 'Pattern' in this code %


function basic
global A;   % ADJACENCY MATRIX OF NETWORKS %
global IN;

% --- PARAMETERS SETTING % CAPITAL VARIABLES == CONST / GLOBAL VARIABLES %
NETTYPE = IN.net;
N = IN.n;  % Reviewer requires larger population size
REPEAT_TIME = IN.r;

if IN.pattern == 1
    RULE_OPR  = {'12', '126', '123', '1245', '1263'};
    NUM_WCLASS    = 6;  % {'S', 'V', 'C', 'O1', 'O2', 'O'} %
    % [1] '12'   = S + V;                   %
    % [2] '126'  = S + V + O;               %
    % [3] '123'  = S + V + C;               %
    % [4] '1245' = S + V + O(1) + O(2);     %
    % [5] '1263' = S + V + O + C;           %
else
    error('Basic Patter ...')
end
NUM_RULES = length(RULE_OPR);
RULE  = 1:NUM_RULES;
addpath('iteration');
addpath('networks');
nname = {'RG003'; 'RG005';'RG01'; 'SW20_01'; 'SW20_02'; 'SW20_03'; ...
         'SW40_01'; 'SW40_02'; 'SW40_03'; 'SF25'; 'SF50'; 'SF75' };

    [TEN, MAXN,MAX_ITER,INTERVAL] = para_setting(NUM_WCLASS,N);
    STORE_LENGTH = MAX_ITER/INTERVAL;

    % INITIALIZING #0 %
    [avg_total,avg_total_sum,avg_diff,avg_diff_sum,avg_maxdiff,~,avg_sucrate,...
     avg_sucrate_mean,final_stc,final_rule,avg_degree,avg_path_length,avg_cc ] = initialization0 ...
    (NUM_WCLASS,STORE_LENGTH,REPEAT_TIME);
    avg_rule_total = zeros(1,STORE_LENGTH);
    avg_rule_diff  = zeros(1,STORE_LENGTH);

    % --- MAIN LOOP --- %
    sent_suc = ones(REPEAT_TIME,STORE_LENGTH);  %% Indicator: Sentence Consensus
    % INITIALIZING #1 %
    [total,dif,sucrate,maxdiff,total_sum,diff_sum,~,~,conv_time] ...
        = initialization1(NUM_WCLASS,REPEAT_TIME,STORE_LENGTH);
    rule_total = zeros(REPEAT_TIME,STORE_LENGTH);  % TOTAL RULES IN THE POPULATION     %
    rule_diff  = zeros(REPEAT_TIME,STORE_LENGTH);  % DIFFERENT RULES IN THE POPULATION %

    for r = 1:REPEAT_TIME
        [avg_degree,avg_path_length,avg_cc] = generating_network(NETTYPE,avg_degree,avg_path_length,avg_cc,N);
        disp('-- -- -- -- -- -- -- -- -- -- ');
        disp(['Nomber of Word Classes: ',	num2str(NUM_WCLASS)]);
        disp(['Network Type: ',             nname{NETTYPE}]);
        disp(['Repeated Run: ',             num2str(r), '/', num2str(REPEAT_TIME)]);
        disp(['Number of Nodes: ',          num2str(N)]);
        disp(['Max Number of Iteration: ',	num2str(MAX_ITER)]);
        disp('-- -- -- -- -- -- -- -- -- -- ');
        node         = cell(N,NUM_WCLASS);      % NODE IN THE NETWORK, INDIVIDUAL %
        learnt_rule  = cell(N,1);               % RECORD THE RULES A NODE HAS LEARNT %
        is_consensus = zeros(N,1);              % FLAG TO INTICATE CONSENSUS %
        scnt = zeros(NUM_WCLASS,TEN);           % SUCCESS TIME COUNTER %
        sent_scnt = zeros(1,TEN);               % SENTENCE SUCCESS TIME COUNTER %
        
        % --- NAMING GAME PROCESSING --- %
        cnt = 1;        % COUNTER FOR (REAL) ITERATION %
        sub_cnt = 0;    % COUNTER FOR (IMAGE) ITERATION, IMAGE = REAL_ITER/INTERVAL %

        while cnt <= MAX_ITER
            idx = randi(N);                     % RANDOMLY SELECT A SPEAKER %
            neb_arr = find(A(idx,:)==1);  	% NEB_ARR = "NEIGHTBOR_ARRAY", ONE ROW (IDX-TH ROW) AND N COLUMNS %
            if ~ isempty(neb_arr)
                jdx = neb_arr(1, randi(length(neb_arr)));               % SELECT ONE HEARER FROM NEIGHBORS %
            else
                error('The graph is not a connected one ...');          % THIS IS IMPOSSIBLE, ONLY IF A BUG %
            end
            % --- SPEAKER SENDS THE MESSAGE --- %
            message = inf*ones(NUM_WCLASS,1);       % AT THE MOST, ONE WORD FROM EACH TYPE %
            if isempty(learnt_rule{idx,1})         	% IF SPEAKER HAS NO RULE, THUS NOTHING IN MEMORY %
                rule_id = RULE(randi(NUM_RULES));  	% RANDLY FIND A RULE FROM {RULE_OPR} %
                learnt_rule{idx,1} = rule_id;      	% LEARN THIS RULE %
                rule_str = RULE_OPR{1,rule_id};
                for rdx = 1:length(rule_str)
                    tdx = str2double(rule_str(rdx));
                    word = randi(MAXN(tdx));
                    node{idx,tdx} = word;
                    message(tdx,1) = word;
                end  %% SENT INFORMATION = {RULE_ID, MESSAGE} %
            else  % SPEAKER HAS RULE(S) ALREADY %
                rule_id = learnt_rule{idx,1}(randi(length(learnt_rule{idx,1})));
                rule_str = RULE_OPR{1,rule_id};
                for rdx = 1:length(rule_str)
                    tdx = str2double(rule_str(rdx));
                    kdx = randi(length(node{idx,tdx}));
                    message(tdx,1) = node{idx,tdx}(kdx);
                end  %% SENT INFORMATION = {RULE_ID, MESSAGE} %
            end % NODE(IDX) SENDS {RULE_ID, MESSAGE} %

            % --- HEARER RECEIVES THE MESSAGE --- %
            suc_note_flag = zeros(NUM_WCLASS,1);
            if isempty(learnt_rule{jdx,1})  %% IF HEARER HAS NO RULE, THUS NOTHING IN MEMORY %
                % RECEIVED INFORMATION = {RULE_ID, MESSAGE} %
                learnt_rule{jdx,1} = rule_id;  %% LEARN THE RULE AS ITS FIRST RULE %
                rule_str = RULE_OPR{1,rule_id};
                for rdx = 1:length(rule_str)
                    tdx = str2double(rule_str(rdx));
                    node{jdx,tdx} = message(tdx,1);
                    if message(tdx,1) == inf,  error('inf ...');  end
                end
                % == {'O1', 'O2', 'O'} SHARING %
                for tdx = [idx,jdx]
                    if (~ isempty(node{tdx,4})) % && (~ isempty(node{tdx, 5}))
                        if ~ isempty(node{tdx,6})
                            tmp_set = union(node{tdx,4},node{tdx,5});
                            node{tdx,6} = union(node{tdx,6},tmp_set);
                            node{tdx,4} = node{tdx,6};
                            node{tdx,5} = node{tdx,6};
                        else %% isempty(node{tdx, 6}) == 1
                            node{tdx,4} = union(node{tdx,4},node{tdx,5});
                            node{tdx,5} = node{tdx,4};
                        end
                    end
                end
                % == {'O1', 'O2', 'O'} SHARING %
            else  % HEARER HAS RULE(S) ALREADY %
                % RECEIVED INFORMATION = {RULE_ID, MESSAGE} %
                is_consensus(jdx,1) = 0;  %% ANYWAY, NODE(JDX) IS NOT CONSENSUS AFTER THIS LEARNING STEP %
                rule_exist = find(learnt_rule{jdx,1} == rule_id);
                if isempty(rule_exist)  %% THE HEARER HAS NO THIS RULE %
                    learnt_rule{jdx,1} = sort(unique([learnt_rule{jdx,1},rule_id]));  % LEARN THE RULE AND SORT THEM %
                end
                rule_str = RULE_OPR{1,rule_id};
                kons = length(rule_str);
                cons_cnt = 0;  % COUNTER FOR CONSENSUS, IF "CONS_CNT == KONS", CONSENSUS %
                for rdx = 1:kons
                    tdx = str2double(rule_str(rdx));
                    if message(tdx,1) == inf,  error('inf ...');  end
                    if isempty(node{jdx,tdx}) || ~sum(node{jdx,tdx} == message(tdx,1))
                        % IF HEARER HAS NO WORD OF THIS TYPE || HAS NO WORD OF THE SAME %
                        node{jdx,tdx} = [node{jdx,tdx}, message(tdx,1)];
                    else
                        cons_cnt = cons_cnt+1;
                        suc_note_flag(tdx,1) = 1;
                        if cnt < TEN
                            scnt(tdx,cnt) = 1;
                        else
                            scnt(tdx,1:(TEN-1)) = scnt(tdx,2:TEN);
                            scnt(tdx,TEN) = 1;
                            suc_note_flag(tdx,1) = 1;
                        end
                    end
                end
                
                % == {'O1', 'O2', 'O'} SHARING %
                for tdx = [idx,jdx]
                    if (~ isempty(node{tdx,4}))  %% && (~ isempty(node{tdx, 5}))
                        if ~ isempty(node{tdx,6})
                            tmp_set = union(node{tdx,4},node{tdx,5});
                            node{tdx,6} = union(node{tdx,6},tmp_set);
                            node{tdx,4} = node{tdx,6};
                            node{tdx,5} = node{tdx,6};
                        else %% isempty(node{tdx, 6}) == 1
                            node{tdx,4} = union(node{tdx,4},node{tdx,5});
                            node{tdx,5} = node{tdx,4};
                        end
                    end
                end
                % == {'O1', 'O2', 'O'} SHARING %
                
                for kdx = 1:NUM_WCLASS
                    if cnt >= TEN && (~suc_note_flag(kdx,1))
                        scnt(kdx,1:(TEN-1)) = scnt(kdx,2:TEN);
                        scnt(kdx,TEN) = 0;
                    end
                end
                
                if cons_cnt == kons && (~ isempty(rule_exist))  %% SENTENCE CONSENSUS %
                    is_consensus(idx,1) = 1;
                    is_consensus(jdx,1) = 1;
                    learnt_rule{idx,1} = rule_id;	% THE SPEAKER KEEPS ONE RULE ONLY       %
                    learnt_rule{jdx,1} = rule_id;	% THE HEARER  KEEPS ONE RULE ONLY       %
                    for rdx = 1:NUM_WCLASS          % CLERA ALL THEIR MEMORIES          	%
                        node{idx,rdx} = [];
                        node{jdx,rdx} = [];
                    end
                    for rdx = 1:kons      % KEEP ONLY THE "MESSAGE" AND THE "RULE" ABOVE	%
                        tdx = str2double(rule_str(rdx));
                        node{idx,tdx} = message(tdx,1);
                        node{jdx,tdx} = message(tdx,1);
                    end
                    if cnt < TEN
                        sent_scnt(cnt) = 1;
                    else
                        sent_scnt(1:(TEN-1)) = sent_scnt(2:TEN);
                        sent_scnt(TEN) = 1;
                    end
                else
                    if cnt >= TEN
                        sent_scnt(1:(TEN-1)) = sent_scnt(2:TEN);
                        sent_scnt(TEN) = 0;
                    end
                end
            end
            
            % --- CALCULATE FEATURES --- %
            if ~ mod(cnt-1,INTERVAL)
                sub_cnt = sub_cnt+1;      % THE SUBSCRIPT FOR RECORD %
                diff_arr = cell(NUM_WCLASS,1);
                for sdx = 1:NUM_WCLASS
                    for idx = 1:N
                        total(sdx,r,sub_cnt) = total(sdx,r,sub_cnt) + length(node{idx,sdx});
                        diff_arr{sdx,1} = [diff_arr{sdx,1},node{idx,sdx}];
                    end
                    dif(sdx,r,sub_cnt)	= length(unique(diff_arr{sdx,1}));
                    total_sum(r,sub_cnt)= sum(total(:,r,sub_cnt));
                    diff_sum(r,sub_cnt)	= sum(dif(:,r,sub_cnt));
                    sucrate(sdx,r,sub_cnt)  = sum(scnt(sdx,:))/TEN;
                    %%sucrate_mean(r,sub_cnt) = mean(sucrate(:,r,sub_cnt));
                end
                diff_r = [];  %% Different rules
                for idx = 1:N
                    rule_total(r,sub_cnt) = rule_total(r,sub_cnt) + length(learnt_rule{idx,1});
                    diff_r = [diff_r,learnt_rule{idx,1}];
                end
                rule_diff(r,sub_cnt) = length(unique(diff_r));
                clear diff_arr diff_r;
                sent_suc(r,sub_cnt) = sum(sent_scnt)/TEN;
            end
            % == END of CALCULATE FEATURES == %

            % --- TEST CONVERGENCE --- %
            conv_flag = 1;
            if sum(is_consensus) ~= N   % IF NOT ALL CONSENSUS, NOT CONSENSUS %
                conv_flag = 0;
            else
                for idx = 1:NUM_WCLASS
                    if length(unique([node{:,idx}])) > 1  % IF HAVE DIFFERENT WORDS, NOT CONSENSUS %
                        conv_flag = 0;
                        break;  % IF ALL %
                    end
                end
            end
            if conv_flag == 1  % CONSENSUS OR CONVERGED %
                final_rule(1,r) = rule_id;
                sl = 0;
                for sdx = 1:NUM_WCLASS
                    final_stc{1,r} = [final_stc{1,r}, node(1,sdx)];
                    sl = sl+length(node(:,sdx));
                end
                rule_str = RULE_OPR{1,rule_id};
                flag = zeros(1,NUM_WCLASS);
                for rdx = 1:length(rule_str)
                    tdx = str2double(rule_str(rdx));
                    flag(1,tdx) = 1;
                end
                
                for sdx = 1:NUM_WCLASS
                    total(sdx,r,sub_cnt+1:end)	 = N*flag(1,sdx);
                    dif(sdx,r,sub_cnt+1:end)	 = flag(1,sdx);
                    sucrate(sdx,r,sub_cnt+1:end) = sucrate(sdx,r,sub_cnt);
                end
                total_sum(r,sub_cnt+1:end) = sum(N*flag);
                diff_sum(r,sub_cnt+1:end) = sum(flag);
                %%sucrate_mean(r,sub_cnt+1:end) = 1;
                rule_total(r,sub_cnt+1:end) = rule_total(r,sub_cnt);
                rule_diff(r,sub_cnt+1:end) = 1;
                disp(['converged at generation ', num2str(cnt), '...']);
                conv_time(r,1) = cnt;
                break;
            end
            % == END of TEST CONVERGENCE == %
            cnt = cnt + 1;
            if mod(cnt,1E4) == 0
                disp(['current iteration: ', num2str(cnt)]);
            end
        end
        % END 'while cnt <= MAX_ITER' %
        
        for sdx = 1 : NUM_WCLASS
            maxdiff(sdx, r) = max(dif(sdx, r, :));
        end
    end
    
    % --- CALCULATING AVERAGED DATA --- %
    for sdx = 1:NUM_WCLASS
        clear tmp_val;
        tmp_val(1,:)     = mean(total(sdx,:,:),2);
        avg_total(sdx,:) = tmp_val(1,:);
        tmp_val(1,:)	 = mean(dif(sdx,:,:),2);
        avg_diff(sdx,:)	 = tmp_val(1,:);
        tmp_val(1,:)	 = mean(sucrate(sdx,:,:),2);
        avg_sucrate(sdx,:) = tmp_val(1,:);
        avg_maxdiff(sdx,1) = mean(maxdiff(sdx,:));
    end
    avg_total_sum(1,:)    = mean(total_sum,1);
    avg_diff_sum(1,:)     = mean(diff_sum,1);
    %%avg_sucrate_mean(1,:) = mean(sucrate_mean, 1);
    avg_conv_time = mean(conv_time,1);
    avg_rule_total(1,:)   = mean(rule_total,1);
    avg_rule_diff(1,:)    = mean(rule_diff,1);
    filename = ['B_N',int2str(N),'_NT',nname{NETTYPE},'.mat'];
    % B  - man-designed
    % N  - population size
    % P  - pattern type
    % NT - network type
    save(filename, 'avg_total',         ... % # of total words in different word categories
                   'avg_diff',          ... % # of different words in different word categories
                   'avg_sucrate',       ... % success rate
                   'avg_rule_total',    ... % # of total patterns in population
                   'avg_rule_diff',     ... % # of different patterns in population
                   'conv_time',         ... % convergence time 
                   'avg_degree','avg_path_length','avg_cc');  % statistics on networks
    clear total dif sucrate maxdiff total_sum diff_sum sucrate_mean maxdiff_sum conv_time rule_total rule_diff;
    
end

