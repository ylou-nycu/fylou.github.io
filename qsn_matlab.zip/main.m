% [Source Code]:
% Y.Lou, L.Wang, and G.Chen, "Toward Stronger Robustness of Network
% Controllability: A Snapback Network Model", IEEE Transactions on
% Circuits and Systems I: Regular Papers, 65(9): 2983�2991;
% doi:10.1109/TCSI.2018.2821124 (2018)
% -----------------------------------------------------------------
% Copyright (c) 2018 Yang Lou and Lin Wang and Guanrong Chen
% All rights reserved.
% -----------------------------------------------------------------
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions
% are met: 
% 1. Redistributions of source code must retain the above copyright
%    notice, this list of conditions and the following disclaimer. 
% 2. Redistributions in binary form must reproduce the above copyright
%    notice, this list of conditions and the following disclaimer in
%    the documentation and/or other materials provided with the 
%    distribution.
% This software is provided by the copyright holders and contributors
% "as is" and any express or implied warranties, including, but not 
% limited to, the implied warranties of merchantability and fitness
% for a particular purpose are disclaimed. In no event shall the
% copyright owner or contributors be liable for any direct, indirect,
% incidental, special, exemplary, or consequential damages (including,
% but not limited to, procurement of substitute goods or services;
% loss of use, data, or profits; or business interruption) however
% caused and on any theory of liability, whether in contract, strict
% liability, or tort (including negligence or otherwise) arising in
% any way out of the use of this software, even if advised of the
% possibility of such damage.
% -----------------------------------------------------------------
% Updated: 06-08-2018 by Felix Y.Lou (felix.lou@my.cityu.edu.hk)
% Further update (if any) can be found in:
%     http://www.ee.cityu.edu.hk/~ylou/
% -----------------------------------------------------------------
clear all; clc;
close all;

NET = {'qsn'; 'mcn'; 'sf'; 'er'};
ntN = {'Q-SNAPBACK'; 'MULTIPLEX CONGRUENCE NETWORK'; 'SCALE-FREE'; 'RANDOM-GRAPH'};
NXE = {'node'; 'edge';};
TXR = {'target'; 'rand'};
EXT = {'degree'; 'betweenness';''};

disp('Controllability simulation of')
disp('{q-snapback; mcn; scale-free; random-graph} networks: ')
disp('-----  -----  -----  -----  -----  -----  ----- ')
disp('Please choose network: ')
net_i = input('(1)q-snapback; (2)mcn; (3)scale-free; (4)random-graph}: ');
while (net_i~=1 && net_i~=2 && net_i~=3 && net_i~=4) || ~isnumeric(net_i) || mod(net_i,1)
    disp('input 1, 2, 3, or 4:')
    net_i = input('(1)q-snapback; (2)mcn; (3)scale-free; (4)random-graph}: ');
end
nXe_i = input('Attack: (1)node_removal; (2)edge_removal: ');
while (nXe_i~=1 && nXe_i~=2) || ~isnumeric(nXe_i) || mod(nXe_i,1)
    disp('input 1 or 2:')
    nXe_i = input('Attack: (1)node_removal; (2)edge_removal: ');
end
tXr_i = input('Targeted or Random? (1)target; (2)rand: ');
while (tXr_i~=1 && tXr_i~=2) || ~isnumeric(tXr_i) || mod(tXr_i,1)
    disp('input 1 or 2:')
    tXr_i = input('Targeted or Random? (1)target; (2)rand: ');
end

if nXe_i==1 && tXr_i==1
    disp('For Targeted-Node attack, please specify: ')
    ext_i = input('(1)degree_based; (2)betweenness_based: ');
    while (ext_i~=1 && ext_i~=2) || ~isnumeric(ext_i) || mod(ext_i,1)
        disp('input 1 or 2:')
        ext_i = input('(1)degree_based; (2)betweenness_based: ');
    end
else
    ext_i = 3;
end
N = input('Finally, input the size of network:');
while N<0 || ~isnumeric(N) || mod(N,1)
    N = input('Input an integer for network size:');
end

c_res = attack(NET{net_i},NXE{nXe_i},TXR{tXr_i},N,EXT{ext_i});

figure
hold on
L1 = plot(c_res.x,c_res.y1a,'k+');
L2 = plot(c_res.x,c_res.y2u,'r.');
lgd = legend([L1,L2],'exact ctrl.','structural ctrl.','Location','northwest');
lgd.FontSize = 12;
xlabel('p_N','fontsize',12,'fontangle','italic')  %% percentage of nodes/edges removed
ylabel('n_D','fontsize',12,'fontangle','italic')  %% percentage of controller needed
title(ntN{net_i})




