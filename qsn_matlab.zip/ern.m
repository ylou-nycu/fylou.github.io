% To construct a directed ER Random-Graph Network
% optinal: with a backbone chain
% updated: 02-08-2018

function [A,ak,disc] = ern(N,nlink,str)
% Input:  N - # of nodes
%     nlink - # of links
%       str - {'no_chain'; 'chain'}
% Output: A -
%        ak -
%      disc - (disconnected == 1); (OK == 0)

    if nargin<3
        str = 'no_chain';
    end
    A = zeros(N,N);
    cnt = 0;  %% link counter
    
% -----| if a backbone is needed |----- %    
    switch str
        case 'chain'
            for i = 1:N-1
                A(i,i+1) = 1;
            end
            A(N,1) = 1;
            cnt = N;
        case 'tree'
            for i = 1:N-1
                j = i+randi(N-i);
                A(i,j) = 1;
            end
            A(N,1) = 1;
            cnt = N;
    end
% -----| if a backbone is needed |----- %
    
    while cnt < nlink
        i = randi(N);
        j = randi(N);
        while (j==i) || A(i,j)
            i = randi(N);
            j = randi(N);
        end
        A(i,j) = 1;  % A(j,i) = -1;
        cnt = cnt+1;
    end
    if sum(sum(A==1))~=cnt;  error('Link Sum Error ...');  end
    disc = 0;
    % Some nodes may have not out-degree, but only in-degree
    for i = 1:N
        if all(A(i,:)==0)
            disc = 1;
            break;
        end
    end
    ak = cnt/N;

end

