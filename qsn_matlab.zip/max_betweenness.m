% The function 'betweenness_centrality_mex' is from MatlabBGL
% MatlabBGL is a Matlab package for working with graphs.
% It uses the Boost Graph Library to efficiently implement the graph algorithms.
% MatlabBGL is designed to work with large sparse graphs with hundreds of thousands of nodes.
% For more information, please visit:
% https://www.cs.purdue.edu/homes/dgleich/packages/matlab_bgl/

function pos = max_betweenness(A,type)

    if ~issparse(A), A = sparse(A);  end
    switch type
        case 'node'
            % Get the betweenness of every node
            [vc,~] = betweenness_centrality_mex(A,'matrix');
            bcMax = max(vc);
            bc = vc;
        case 'edge'
            % Get the betweenness of every edge
            [~,ec] = betweenness_centrality_mex(A,'matrix');
            bcMax = max(ec);
            bc = ec;
    end
    pos = find(bc == bcMax);
    pos = pos(randi(length(pos)));
    
end

