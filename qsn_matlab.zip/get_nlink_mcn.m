% get sum of the number of links in MCN
% updated 01-08-2018

function nlink = get_nlink_mcn(N,r_mcn)
% Output: nlink - number of MCN's total link
% r_mcn = 1;  %% for simulation, only this layer
    if nargin<2
        r_mcn = 1;
    end
    [nlink,~] = mcn_ak(r_mcn,N);
end


% Details can be found in:
% https://www.nature.com/articles/srep23714
function [allk,ak] = mcn_ak(r,N)
    eq9x10 = 0;  %% Do not set (1), when set (1), it uses Eqs.9 and 10 of the paper.
    if eq9x10
        ec = 0.57721566490153286060651209008240;  %% Euler's constant 
        if r>0
            ak = log(N-1-r) + 2*ec - 1 - sum(floor((N-1-r)./(1:r)))/(N-1-r);
        elseif ~r
            ak = log(N-1) + 2*ec - 2;
        end
    else
        A = mcn(r,N);
        allk = sum(sum(A>0));
        ak = allk/(N-1);
    end
end

