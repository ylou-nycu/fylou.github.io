% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% node_removal based attacks
% including {'rand'; 'target->degree'; 'target->betweenness'}
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 05-08-2018
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
function res = node_removal(A,N,s)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Output:
% y1a = state  controllability
% y2u = struct controllability
% Input:
% A - net matrix
% N - net size
% s - {'rand'; 't_deg'; 't_bet'}
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
drct = 'out';

    res.x = (1:N-1)./(N-1);
    res.y1a = ones(N-1,1);  %% state/exact controllability
    res.y2u = ones(N-1,1);	%% structural controllability
    
    if strcmp(s.name,'rand')||strcmp(s.name,'rnd')
        y1a = zeros(s.rept,N-1);
        y2u = zeros(s.rept,N-1);
        for t = 1:s.rept  %% Repeat
            A1 = A;
            for idx = 1:N-1
                j = randi(N-idx);
                % Revove a random node
                A1(j,:) = [];
                A1(:,j) = [];
                % Calculate the maximum matching ...
                dm = dmperm(A1);
                m = sum(dm~=0);
                % Calculate the rank ...
                Rk = rank(A1);
                % Append data ...
                y1a(t,idx) = max((size(A1,1)-Rk),1)/size(A1,1);
                y2u(t,idx) = max((size(A1,1)-m) ,1)/size(A1,1);
            end
        end
        res.x = (1:N-1)./(N-1);
        res.y1a = mean(y1a,1);
        res.y2u = mean(y2u,1);
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
    else  % Targeted Attacks :: 't_deg' - targeted degree based
          %                     't_bet' - targeted betweenness based
          for idx = 1:N-1
              if size(A,1)>1
                  switch s.name
                      case 't_deg'  %% targeted degree based
                          pos = max_degree(A,drct,'rnd');
                      case 't_bet'  %% targeted betweenness based
                          pos = max_betweenness(A,'node');
                          % all about node-removal in this function
                  end
                  A(pos,:) = [];
                  A(:,pos) = [];
                  % Calculate the maximum matching ...
                  dm = dmperm(A);
                  m = sum(dm~=0);
                  % Calculate the rank ...
                  Rk = rank(A);
                  % Append data ...
                  res.y1a(idx,1) = max((size(A,1)-Rk),1)/size(A,1);
                  res.y2u(idx,1) = max((size(A,1)-m) ,1)/size(A,1);
              end
          end
          res.x = (1:N-1)./(N-1);
    end  %% End-if-else{'rand'; 'target'}
end

