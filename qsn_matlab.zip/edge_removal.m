% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% edge_removal based attacks
% including {'rand'; 'target->betweenness'}
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% updated: 06-08-2018

function res = edge_removal(A,s)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Output:
% res.y1a = state  controllability
% res.y2u = struct controllability
% Input:
% A - net matrix
% s - {'rand'; 'te_bet'}
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
    M = sum(sum(A));        %% total number of edges
    res.x = (1:M-1)./(M-1);
    res.y1a = ones(M-1,1);  %% state/exact controllability
    res.y2u = ones(M-1,1);	%% structural controllability
    
    if strcmp(s.name,'rand')||strcmp(s.name,'rnd')
        y1a = zeros(s.rept,M-1);
        y2u = zeros(s.rept,M-1);
        for t = 1:s.rept  %% Repeat
            A1 = A;
            P = randperm(M);
            for i=1:M-1
                j=P(i);
                pos = locate_edge(j);
                % Revove an edge
                if ~A1(pos);  error('This is not an edge ... ');  end
                A1(pos) = 0;  %% only out-degree cleared
                % Calculate the maximum matching ...
                dm = dmperm(A1);
                m = sum(dm~=0);
                % Calculate the rank ...
                Rk = rank(A1);
                % Append data ...
                y1a(t,i) = max((size(A1,1)-Rk),1)/size(A1,1);
                y2u(t,i) = max((size(A1,1)-m),1)/size(A1,1);
            end
        end
        res.y1a = mean(y1a,1);
        res.y2u = mean(y2u,1);
        
    elseif strcmp(s.name,'te_bet')
        for i=1:M-1
            % Revove the edge with max-betwenness
            pos = max_betweenness(A,'edge');            
            pos = locate_edge(pos);
            if ~A(pos);  error('This is not an edge ... ');  end
            A(pos) = 0;
            % Calculate the maximum matching ...
            dm = dmperm(A);
            m = sum(dm~=0);
            % Calculate the rank ...
            Rk = rank(A);
            % Append data ...
            res.y1a(i,1) = max((size(A,1)-Rk),1)/size(A,1);
            res.y2u(i,1) = max((size(A,1)-m),1)/size(A,1);
        end
        
    elseif strcmp(s.name,'te_deg')
        % To be added ...
    end
    
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% To find the idx-th non-zero element in a 0-1 sdjacency matrix,
% and return its location.
% updated: 24-02-2018.
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
function pos = locate_edge(idx)
% A - network
% pos - position
    pos=find(A==1,idx,'first');
    pos=pos(end);
end

end

