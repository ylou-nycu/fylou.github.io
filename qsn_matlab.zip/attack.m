% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% [Source Code]:
%	Yang Lou, Lin Wang, and Guanrong Chen, "Toward Stronger
%   Robustness of Network Controllability: A Snapback Network
%   Model", IEEE Transactions on Circuits and Systems I:
%   Regular Papers, 65(9): 2983�2991;
%   doi:10.1109/TCSI.2018.2821124 (2018)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Attack Strategies:
% 1.node-targeted-degree;  2.node-targeted-betweenness; 3.node-rand
% 4.edge-targeted-between; 5.edge-rand;
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Updated: 05-08-2018
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
function c_res = attack(net,nXe,tXr,N,ext_para)
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% Output: Structural and State Controllability
%    res.y1a - state  controllability
%    res.y2u - struct controllability
% Input: tXr - target or rand
%        nXe - node or edge
%        net - nettype 
%          N - network size
%	ext_para - [only if node-targeted] {'degree';'betweenness'}
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% nXe = {'node'; 'edge';};
% tXr = {'target'; 'rand'};
% net = {'sf'; 'mcn'; 'qsn'; 'er'};
% ext_para = {'degree'; 'betweenness'}
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %

    r_qs  = 2;	%% r for q-snapback network
    r_mcn = 1;	%% r for multiplex congruence network
    BACKBONE = 'chain';     %% {'chain'; 'tree'; 'no'}    
    n_link = get_nlink_mcn(N,r_mcn);
    
    switch net
        case 'er'
            str = BACKBONE;  %% set 'chain' to avoid disconnected initially
            [A,~,disc] = ern(N,n_link,str);
            tmp = 0;
            while disc && (tmp<TRY_DISC)
                tmp = tmp+1;
                [A,~,disc] = ern(N,n_link,str);
            end
            if disc;  error('Cannot generate connected ER ...');  end
        case 'sf'
            str = BACKBONE;
            [A,~,disc] = sfn(N,n_link,str);
            tmp = 0;
            while disc && (tmp<TRY_DISC)
                tmp = tmp+1;
                [A,~,disc] = sfn(N,n_link,str);
            end
            if disc;  error('Cannot generate connected SF ...');  end
        case 'mcn'
            % 1.MCN has a backbone chain if (r_mcn==1)
            % 2.cannot required MCN with a specific number of links
            A = mcn(r_mcn,N);
        case 'qsn'
            itop = 'chain';
            q = q_nlink(r_qs,N,'e2q',n_link);
            [A,~] = qsn(r_qs,N,q,n_link,itop);
        otherwise
            error('wrong network type ...')
    end
    % -----| above A is constructed |----- %
    
    % -----| below attack A ...     |----- %
    switch nXe
        % ----- | Node Removal + {1.bet_target; 2.deg_target; 3.rand} | -----  ----- %
        case {'node';'n';}
            switch tXr
                case {'tar';'target';}
                    if strcmp(ext_para,'betweenness')
                        s.name = 't_bet';
                    elseif strcmp(ext_para,'degree')
                        s.name = 't_deg';
                    end
                case {'rand';'rnd';}  %% Rand-Node-Attack
                    s.name = 'rand';
                    s.rept = 30;
                otherwise
                    error('...')
            end
            c_res = node_removal(A,N,s);
        % ----- | Edge Removal + {1.bet_tar; 2.rand} | -----  ----- %
        case {'edge';'e';}
            switch tXr
                case {'tar';'target';}
                    s.name = 'te_bet';
                case {'rand';'rnd'}
                    s.name = 'rand';
                    s.rept = 10;  %% Set as small as possible for Edge-Removal
                otherwise
                    error('...')
            end
            c_res = edge_removal(A,s);
        otherwise
            error('wrong nXe input ...')
    end
    
    fname = [net,'_',nXe,'_',tXr,ext_para,'_',int2str(N)];
    save(fname);
    
end


