% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% a simple implementation, which returns the max-degree index (position)
% 06-08-2018
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
% -----  -----  -----  -----  -----  -----  -----  -----  ----- %
function pos = max_degree(A,drct,S)
% A - adj matrix
% drct - direction {'in';'out'}
% S - when degree value equals

    if nargin==1;  drct='out';  S='rnd';	end
    if nargin==2;  S='rnd';                 end
    
    switch drct
        case 'out'
            % get out-degree of every node
            k = sum(A,2);
        case 'in'
            % get in-degree of every node
            k = sum(A,1);
    end
    kMax = max(k);
    % and pick the max k one
    pos = find(k == kMax);
    switch S
        case 'min'
            [~,kpos] = min(pos);
        case 'max'
            [~,kpos] = max(pos);
        case {'rand';'rnd'}
            kpos = randi(length(pos));
    end
    pos = pos(kpos);
    
end



