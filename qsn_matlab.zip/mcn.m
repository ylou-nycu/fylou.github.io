% Generate the Multiplex Congruence Network in Sci Rept
% https://www.nature.com/articles/srep23714

function [A] = mcn(r,N)
% A - the r-th layer only

    A = zeros(N,N);
    for idx = r
        for i = 1:N-1
            for j = i+1:N-2
                if mod(j+1,i+1) == idx
                    A(i,j) = 1;
                end
            end
        end
    end
    
end

